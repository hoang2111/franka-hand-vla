"""
Vision-Language-Action (VLA) Model for Robotic Manipulation.

Architecture Overview:
  1. Vision Tokenizer: Convolutional feature backbone extracting spatial tokens from camera RGB images.
  2. Language Tokenizer: Learned instruction embeddings for natural language commands.
  3. Multimodal Cross-Attention: Spatial visual tokens attend to language tokens to ground
     robot attention directly to target objects (e.g. red cube vs green tray).
  4. Action Decoder: Predicts continuous 4-DoF robot actions [dx, dy, dz, gripper_cmd].
  5. Attention Extractor: Computes live spatial heatmaps for visual interpretability.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import cv2


class SpatialPositionalEncoding(nn.Module):
    def __init__(self, embed_dim: int, grid_h: int = 8, grid_w: int = 8):
        super().__init__()
        self.pos_embed = nn.Parameter(torch.randn(1, grid_h * grid_w, embed_dim) * 0.02)

    def forward(self, x):
        return x + self.pos_embed


class VisionTokenizer(nn.Module):
    """
    Downsamples RGB (B, 3, 128, 128) into 64 spatial visual tokens of dimension D=128.
    """
    def __init__(self, in_channels: int = 3, embed_dim: int = 128):
        super().__init__()
        self.conv_net = nn.Sequential(
            # Stage 1: 128x128 -> 64x64
            nn.Conv2d(in_channels, 32, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(4, 32),
            nn.GELU(),
            # Stage 2: 64x64 -> 32x32
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            # Stage 3: 32x32 -> 16x16
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            # Stage 4: 16x16 -> 8x8
            nn.Conv2d(128, embed_dim, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, embed_dim),
            nn.GELU(),
        )
        self.pos_enc = SpatialPositionalEncoding(embed_dim, 8, 8)

    def forward(self, x):
        feat = self.conv_net(x)  # (B, embed_dim, 8, 8)
        B, C, H, W = feat.shape
        tokens = feat.flatten(2).transpose(1, 2)  # (B, 64, embed_dim)
        tokens = self.pos_enc(tokens)
        return tokens, (H, W)


class VLAPolicy(nn.Module):
    """
    End-to-End Vision-Language-Action Policy.
    """
    PROMPTS = [
        "pick up the red box",
        "place in the green tray"
    ]

    def __init__(
        self,
        embed_dim: int = 128,
        num_heads: int = 4,
        action_dim: int = 4,
        proprio_dim: int = 3,
        num_instructions: int = 2,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.action_dim = action_dim

        # 1. Vision Tokenizer
        self.vision_encoder = VisionTokenizer(in_channels=3, embed_dim=embed_dim)

        # 2. Language Embedding
        self.lang_embeddings = nn.Embedding(num_instructions, embed_dim)

        # 3. Proprioception Projector
        self.proprio_proj = nn.Linear(proprio_dim, embed_dim)

        # 4. Multimodal Cross-Attention Layer: Visual tokens attend to language
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            batch_first=True
        )
        self.norm1 = nn.LayerNorm(embed_dim)

        # 5. Self-Attention Transformer Encoder Layer
        self.self_attn = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            batch_first=True
        )
        self.norm2 = nn.LayerNorm(embed_dim)

        # Feed Forward Network
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.GELU(),
            nn.Linear(embed_dim * 2, embed_dim),
            nn.LayerNorm(embed_dim),
        )

        # 6. Action Head
        # Predicts: [dx, dy, dz, gripper_cmd]
        self.action_head = nn.Sequential(
            nn.Linear(embed_dim * 2, 128),
            nn.GELU(),
            nn.Linear(128, 64),
            nn.GELU(),
            nn.Linear(64, action_dim)
        )

    def forward(self, img, lang_id, proprio=None, return_attention=False):
        """
        img: (B, 3, H, W) normalized [0, 1]
        lang_id: (B,) int64
        proprio: (B, 3) float32 (ee_pos)
        """
        B = img.shape[0]

        # Vision tokens: (B, 64, D)
        vis_tokens, (grid_h, grid_w) = self.vision_encoder(img)

        # Language tokens: (B, 1, D)
        lang_tokens = self.lang_embeddings(lang_id).unsqueeze(1)

        # Cross attention: Queries = Visual Tokens, Keys/Values = Language Tokens
        fused_vis, attn_weights = self.cross_attn(
            query=vis_tokens,
            key=lang_tokens,
            value=lang_tokens,
            need_weights=True,
            average_attn_weights=False  # (B, num_heads, 64, 1)
        )
        vis_tokens = self.norm1(vis_tokens + fused_vis)

        # Self-attention across spatial tokens
        sa_tokens, _ = self.self_attn(vis_tokens, vis_tokens, vis_tokens)
        vis_tokens = self.norm2(vis_tokens + sa_tokens)
        vis_tokens = vis_tokens + self.ffn(vis_tokens)

        # Global average pooling of visual tokens
        vis_pool = vis_tokens.mean(dim=1)  # (B, D)

        # Incorporate proprioception
        if proprio is not None:
            proprio_feat = F.gelu(self.proprio_proj(proprio))
        else:
            proprio_feat = torch.zeros_like(vis_pool)

        multimodal_repr = torch.cat([vis_pool, proprio_feat], dim=-1)  # (B, 2*D)

        # Predict actions
        actions = self.action_head(multimodal_repr)

        if return_attention:
            # Average attention over heads: (B, 64) -> reshape to (B, grid_h, grid_w)
            mean_attn = attn_weights.mean(dim=1).squeeze(-1)  # (B, 64)
            attn_map = mean_attn.view(B, grid_h, grid_w)
            return actions, attn_map

        return actions

    @torch.no_grad()
    def predict_action(self, image_rgb: np.ndarray, prompt: str, ee_pos: np.ndarray, device: str = "cpu"):
        """
        High-level inference API for live robot control.
        image_rgb: (H, W, 3) uint8 [0, 255]
        prompt: "pick up the red box" or "place in the green tray"
        ee_pos: (3,) float32
        """
        self.eval()
        if "pick" in prompt.lower() or "red" in prompt.lower():
            lang_id = 0
        else:
            lang_id = 1

        img_resized = cv2.resize(image_rgb, (128, 128))
        img_t = torch.from_numpy(img_resized).permute(2, 0, 1).float().unsqueeze(0) / 255.0
        img_t = img_t.to(device)

        lang_t = torch.tensor([lang_id], dtype=torch.long, device=device)
        prop_t = torch.from_numpy(ee_pos).float().unsqueeze(0).to(device)

        actions, attn_map = self.forward(img_t, lang_t, prop_t, return_attention=True)

        action_np = actions.squeeze(0).cpu().numpy()
        attn_np = attn_map.squeeze(0).cpu().numpy()

        attn_resized = cv2.resize(attn_np, (image_rgb.shape[1], image_rgb.shape[0]))
        attn_norm = (attn_resized - attn_resized.min()) / (attn_resized.max() - attn_resized.min() + 1e-8)

        return action_np, attn_norm
