"""
Randomized mobile pick-and-place in full MuJoCo physics, driven by the trained RL policy.

Every episode the pick table (with the red box) and the drop table (with the
green tray) are placed at random spots on the map, the box gets a random offset
and yaw on its table, and the tray a random offset on its table. A small task
FSM hands the RL policy a sequence of hand targets; the policy drives the base
and the hand there; the FSM closes/opens the gripper.

    GO_PREGRASP -> DESCEND -> GRASP -> LIFT -> GO_TRAY -> RELEASE -> RETREAT -> DONE
                                         \\-- box not lifted? re-open and retry (max 2)

Usage:
    .venv/bin/python3 rl_pick_and_place.py --episodes 30            # success-rate evaluation
    .venv/bin/python3 rl_pick_and_place.py --episodes 30 --video 3  # + record first 3 episodes
    .venv/bin/mjpython rl_pick_and_place.py --viewer                # watch live (macOS)
"""

import argparse
import json
import os
import pickle
import subprocess
import time

import cv2
import mujoco
import numpy as np

from rl_reach_env import (
    ACTION_SMOOTH, BLOCK_REST_Z, CTRL_DT, GRASP_DZ, LIFT_DZ, PREDROP_DZ, PREGRASP_DZ,
    STATIC_OBSTACLES, TCP_HI, TCP_LO, TRAY_FLOOR_Z, V_BASE, V_EE, W_BASE, XML_PATH,
    ArmIK, SceneIds, apply_layout, make_obs, place_block, rot2, sample_layout, wrap_quarter,
)

HERE = os.path.dirname(os.path.abspath(__file__))
GRIP_OPEN, GRIP_CLOSE = 255.0, 0.0
PHASE_TIMEOUT = 30.0
TOL = {"GO_PREGRASP": 0.045, "DESCEND": 0.015, "LIFT": 0.035, "GO_TRAY": 0.045, "RETREAT": 0.05}


class Policy:
    """PPO policy + the observation normalisation it was trained with."""

    def __init__(self, model_dir: str):
        from stable_baselines3 import PPO
        self.model = PPO.load(os.path.join(model_dir, "reach_policy.zip"), device="cpu")
        with open(os.path.join(model_dir, "vecnormalize.pkl"), "rb") as f:
            vn = pickle.load(f)
        self.mean, self.var = vn.obs_rms.mean, vn.obs_rms.var
        self.clip, self.eps = vn.clip_obs, vn.epsilon

    def __call__(self, obs: np.ndarray) -> np.ndarray:
        o = np.clip((obs - self.mean) / np.sqrt(self.var + self.eps), -self.clip, self.clip)
        a, _ = self.model.predict(o.astype(np.float32), deterministic=True)
        return np.clip(a, -1.0, 1.0)


class Runner:
    def __init__(self, policy: Policy, record: bool = False, viewer=None, size=(640, 480)):
        self.m = mujoco.MjModel.from_xml_path(XML_PATH)
        yaw_act = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_ACTUATOR, "actuator_base_yaw")
        self.m.actuator_ctrlrange[yaw_act] = [-50.0, 50.0]   # allow continuous base rotation
        self.d = mujoco.MjData(self.m)
        self.ids = SceneIds(self.m)
        self.ik = ArmIK(self.m)
        self.policy = policy
        self.substeps = int(round(CTRL_DT / self.m.opt.timestep))
        self.viewer = viewer
        self.frames = [] if record else None
        self.hud = {}
        if record:
            w, h = size
            self.r_over = mujoco.Renderer(self.m, h, w)
            self.r_hand = mujoco.Renderer(self.m, h, w)
            self.cam_hand = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_CAMERA, "hand_camera_down")
            self.cam_over = mujoco.MjvCamera()
            self.render_every = int(round(1.0 / (30.0 * self.m.opt.timestep)))
        self.nstep = 0

    # ------------------------------------------------------------ helpers
    def _robot_env_contact(self) -> bool:
        ids = self.ids
        for i in range(self.d.ncon):
            c = self.d.contact[i]
            if ids.ignore_geom[c.geom1] or ids.ignore_geom[c.geom2]:
                continue
            if ids.robot_geom[c.geom1] != ids.robot_geom[c.geom2]:
                return True
        return False

    def _render(self):
        d = self.d
        self.r_over.update_scene(d, camera=self.cam_over)
        goal = self.hud.get("goal")
        scn = self.r_over.scene
        if goal is not None and scn.ngeom < scn.maxgeom:
            mujoco.mjv_initGeom(scn.geoms[scn.ngeom], mujoco.mjtGeom.mjGEOM_SPHERE,
                                np.array([0.03, 0, 0]), np.asarray(goal, float), np.eye(3).flatten(),
                                np.array([1.0, 0.85, 0.1, 0.7], dtype=np.float32))
            scn.ngeom += 1
        left = cv2.cvtColor(self.r_over.render(), cv2.COLOR_RGB2BGR)
        self.r_hand.update_scene(d, camera=self.cam_hand)
        right = cv2.cvtColor(self.r_hand.render(), cv2.COLOR_RGB2BGR)
        for img, title in ((left, "MAP VIEW (yellow dot = current hand target)"), (right, "HAND CAMERA")):
            cv2.rectangle(img, (0, 0), (img.shape[1], 34), (20, 20, 24), -1)
            cv2.putText(img, title, (10, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 255), 1, cv2.LINE_AA)
        h = self.hud
        lines = [f"Episode {h.get('ep', 0)}   t = {d.time:5.1f} s",
                 f"Phase: {h.get('phase', '')}",
                 f"Hand-to-target: {h.get('dist', 0) * 100:5.1f} cm"]
        if h.get("result"):
            lines.append(h["result"])
        y = left.shape[0] - 18 * len(lines) - 10
        cv2.rectangle(left, (0, y - 18), (360, left.shape[0]), (20, 20, 24), -1)
        for i, s in enumerate(lines):
            col = (120, 255, 120) if s.startswith("SUCCESS") else ((90, 90, 255) if s.startswith("FAIL") else (235, 235, 235))
            cv2.putText(left, s, (10, y + 18 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.52, col, 1, cv2.LINE_AA)
        self.frames.append(np.hstack([left, right]))

    def _physics(self, base_cmd, q_cmd, grip):
        d = self.d
        b0, q0 = d.ctrl[8:11].copy(), d.ctrl[:7].copy()
        for k in range(self.substeps):
            s = (k + 1) / self.substeps
            d.ctrl[:7] = q0 + s * (q_cmd - q0)
            d.ctrl[8:11] = b0 + s * (base_cmd - b0)
            d.ctrl[7] = grip
            t0 = time.perf_counter()
            mujoco.mj_step(self.m, d)
            self.nstep += 1
            if self.frames is not None and self.nstep % self.render_every == 0:
                self._render()
            if self.viewer is not None:
                self.viewer.sync()
                dt = self.m.opt.timestep - (time.perf_counter() - t0)
                if dt > 0:
                    time.sleep(dt)

    # ------------------------------------------------------------ one episode
    def run_episode(self, L, ep: int) -> dict:
        m, d, ids, ik = self.m, self.d, self.ids, self.ik
        apply_layout(m, ids, L)
        mujoco.mj_resetDataKeyframe(m, d, 0)
        place_block(d, ids, L)
        d.qpos[0:3] = 0.0
        mujoco.mj_forward(m, d)

        if self.frames is not None:   # frame the whole layout from above
            pts = np.array([[0.0, 0.0], L.pick_rect[:2], L.drop_rect[:2]])
            c = pts.mean(axis=0)
            spread = np.max(np.linalg.norm(pts - c, axis=1))
            self.cam_over.lookat[:] = [c[0], c[1], 0.3]
            self.cam_over.distance = float(np.clip(2.4 * spread + 2.0, 3.5, 9.0))
            self.cam_over.elevation = -55.0
            self.cam_over.azimuth = 135.0

        base_cmd = d.qpos[0:3].copy()
        q_cmd = d.qpos[3:10].copy()
        tcp_cmd = ik.fk(q_cmd)
        psi, grip = 0.0, GRIP_OPEN
        a_prev = np.zeros(6)
        d.ctrl[:7], d.ctrl[7], d.ctrl[8:11] = q_cmd, grip, base_cmd
        self.hud = {"ep": ep, "phase": "SETTLE", "dist": 0.0, "goal": None}
        for _ in range(5):
            self._physics(base_cmd, q_cmd, grip)

        obst = {"pick": np.vstack([STATIC_OBSTACLES, L.drop_rect]),
                "drop": np.vstack([STATIC_OBSTACLES, L.pick_rect])}
        rects = {"pick": L.pick_rect, "drop": L.drop_rect}
        phase, t_phase = "GO_PREGRASP", d.time
        grasp_xyz = None
        retries, contact_steps, result = 0, 0, None
        tray_xy = L.tray_xy

        while result is None:
            bxy, yaw, q = d.qpos[0:2].copy(), float(d.qpos[2]), d.qpos[3:10].copy()
            tcp_w = d.site_xpos[ids.site].copy()
            block = d.xpos[ids.block].copy()
            Rb = d.xmat[ids.block].reshape(3, 3)
            block_yaw = float(np.arctan2(Rb[1, 0], Rb[0, 0]))
            hold, goal, table = False, None, "pick"
            t_in = d.time - t_phase

            if phase == "GO_PREGRASP":
                goal, grip = block + [0, 0, PREGRASP_DZ], GRIP_OPEN
            elif phase == "DESCEND":
                goal, grip = grasp_xyz + [0, 0, GRASP_DZ], GRIP_OPEN
            elif phase == "GRASP":
                hold, grip = True, GRIP_CLOSE
            elif phase == "LIFT":
                goal, grip = grasp_xyz + [0, 0, LIFT_DZ], GRIP_CLOSE
            elif phase == "REOPEN":
                hold, grip = True, GRIP_OPEN
            elif phase == "GO_TRAY":
                goal, grip, table = np.r_[tray_xy, TRAY_FLOOR_Z + PREDROP_DZ], GRIP_CLOSE, "drop"
            elif phase == "RELEASE":
                hold, grip, table = True, GRIP_OPEN, "drop"
            elif phase == "RETREAT":
                goal, grip, table = np.r_[tray_xy, TRAY_FLOOR_Z + PREDROP_DZ + 0.12], GRIP_OPEN, "drop"

            dist = float(np.linalg.norm(goal - tcp_w)) if goal is not None else 0.0
            self.hud.update(phase=phase, dist=dist, goal=goal)

            # ---------------- phase transitions
            nxt = None
            if phase == "GO_PREGRASP" and dist < TOL[phase]:
                grasp_xyz = block.copy()
                psi = wrap_quarter(block_yaw - yaw)          # align fingers with the box faces
                nxt = "DESCEND"
            elif phase == "DESCEND" and dist < TOL[phase]:
                nxt = "GRASP"
            elif phase == "GRASP" and t_in > 1.0:
                nxt = "LIFT"
            elif phase == "LIFT" and dist < TOL[phase]:
                if block[2] > grasp_xyz[2] + 0.08:
                    nxt = "GO_TRAY"
                else:
                    retries += 1
                    nxt = "REOPEN" if retries <= 2 else None
                    if nxt is None:
                        result = "FAIL: grasp missed 3 times"
            elif phase == "REOPEN" and t_in > 0.6:
                psi, nxt = 0.0, "GO_PREGRASP"
            elif phase == "GO_TRAY" and np.linalg.norm(block - tcp_w) > 0.18:
                result = "FAIL: box dropped while carrying"
            elif phase == "GO_TRAY" and dist < TOL[phase]:
                nxt = "RELEASE"
            elif phase == "RELEASE" and t_in > 1.0:
                block_now = d.xpos[ids.block]
                if np.linalg.norm(block_now[:2] - tray_xy) < 0.08:
                    result = "SUCCESS: box in tray"
                    break
                nxt = "RETREAT"
            elif phase == "RETREAT" and (dist < TOL[phase] or t_in > 2.0):
                nxt = "DONE"
            if phase not in ("GRASP", "REOPEN", "RELEASE", "RETREAT") and t_in > PHASE_TIMEOUT:
                result = f"FAIL: timeout in {phase}"
            if nxt == "DONE" or result is not None:
                break
            if nxt is not None:
                phase, t_phase = nxt, d.time
                continue

            # ---------------- policy -> commands
            if hold:
                a_prev = np.zeros(6)
            elif phase in ("DESCEND", "LIFT", "RETREAT"):
                # Clean vertical arm action while base stays parked at table
                a_prev = np.zeros(6)
                target_b = np.r_[rot2(yaw).T @ (goal[:2] - bxy), goal[2]]
                target_b = np.clip(target_b, TCP_LO, TCP_HI)
                delta = target_b - tcp_cmd
                step_dist = 0.25 * CTRL_DT
                if np.linalg.norm(delta) > step_dist:
                    tcp_cmd += delta * (step_dist / np.linalg.norm(delta))
                else:
                    tcp_cmd = target_b
            else:
                obs = make_obs(bxy, yaw, q, ik.fk(q), tcp_w, goal, rects[table], obst[table], a_prev, ik)
                a = self.policy(obs)
                a_app = ACTION_SMOOTH * a_prev + (1 - ACTION_SMOOTH) * a
                a_prev = a_app
                base_cmd[2] += a_app[2] * W_BASE * CTRL_DT
                base_cmd[:2] += rot2(base_cmd[2]) @ (a_app[:2] * V_BASE) * CTRL_DT
                e = base_cmd[:2] - bxy                      # anti-windup vs. tracking lag
                n = np.linalg.norm(e)
                if n > 0.15:
                    base_cmd[:2] = bxy + e * 0.15 / n
                base_cmd[2] = yaw + np.clip(base_cmd[2] - yaw, -0.3, 0.3)
                tcp_cmd = np.clip(tcp_cmd + a_app[3:] * V_EE * CTRL_DT, TCP_LO, TCP_HI)
            q_cmd, tcp_ach = ik.solve(q_cmd, tcp_cmd, psi, iters=8)
            tcp_cmd = tcp_ach + np.clip(tcp_cmd - tcp_ach, -0.03, 0.03)
            self._physics(base_cmd, q_cmd, grip)
            contact_steps += self._robot_env_contact()

        # let the box settle, then score
        for _ in range(5):
            self._physics(base_cmd, q_cmd, GRIP_OPEN)
        block = d.xpos[ids.block]
        in_tray = (np.all(np.abs(block[:2] - tray_xy) < 0.06) and TRAY_FLOOR_Z - 0.005 < block[2] < TRAY_FLOOR_Z + 0.05)
        if result is None:
            result = "SUCCESS: box in tray" if in_tray else "FAIL: box not in tray"
        self.hud.update(result=result, phase="DONE" if result.startswith("SUCCESS") else phase)
        if self.frames is not None:
            for _ in range(30):
                self._render()
        self.hud["result"] = None
        return {
            "episode": ep, "success": result.startswith("SUCCESS"), "result": result,
            "sim_time_s": round(float(d.time), 2), "grasp_retries": retries,
            "robot_env_contact_steps": int(contact_steps),
            "box_to_tray_cm": round(float(np.linalg.norm(block[:2] - tray_xy)) * 100, 2),
            "pick_table": [round(float(v), 2) for v in L.pick_rect[:2]],
            "drop_table": [round(float(v), 2) for v in L.drop_rect[:2]],
        }


def write_video(frames, path, fps):
    tmp = path + ".tmp.mp4"
    h, w = frames[0].shape[:2]
    vw = cv2.VideoWriter(tmp, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in frames:
        vw.write(f)
    vw.release()
    r = subprocess.run(["ffmpeg", "-y", "-i", tmp, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "23", path],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if r.returncode == 0:
        os.remove(tmp)
    else:
        os.replace(tmp, path)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--episodes", type=int, default=20)
    p.add_argument("--video", type=int, default=0, help="record the first N episodes")
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--model-dir", default=os.path.join(HERE, "rl_models"))
    p.add_argument("--out", default=os.path.join(HERE, "rl_pick_and_place.mp4"))
    p.add_argument("--viewer", action="store_true")
    args = p.parse_args()

    policy = Policy(args.model_dir)
    rng = np.random.default_rng(args.seed)
    layouts = [sample_layout(rng) for _ in range(args.episodes)]

    if args.viewer:
        import mujoco.viewer
        runner = Runner(policy)
        with mujoco.viewer.launch_passive(runner.m, runner.d) as v:
            runner.viewer = v
            for i, L in enumerate(layouts, 1):
                if not v.is_running():
                    break
                print(runner.run_episode(L, i)["result"])
        return

    results, frames = [], []
    rec_runner = Runner(policy, record=True) if args.video > 0 else None
    runner = Runner(policy)
    t0 = time.time()
    for i, L in enumerate(layouts, 1):
        r = (rec_runner if i <= args.video else runner).run_episode(L, i)
        results.append(r)
        print(f"Episode {i:2d}: {r['result']:<36} sim {r['sim_time_s']:5.1f}s | retries {r['grasp_retries']} "
              f"| contact steps {r['robot_env_contact_steps']:3d} | box-tray {r['box_to_tray_cm']:5.1f} cm", flush=True)

    n_ok = sum(r["success"] for r in results)
    print(f"\nSuccess: {n_ok}/{len(results)} ({100 * n_ok / len(results):.0f}%)  |  wall {time.time() - t0:.0f}s")
    with open(os.path.join(args.model_dir, "eval_results.json"), "w") as f:
        json.dump({"success_rate": n_ok / len(results), "episodes": results}, f, indent=2)
    if rec_runner is not None and rec_runner.frames:
        write_video(rec_runner.frames, args.out, fps=1.0 / (rec_runner.render_every * rec_runner.m.opt.timestep))
        print(f"Video: {args.out}")


if __name__ == "__main__":
    main()
