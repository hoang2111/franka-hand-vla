"""
Mobile Manipulator Pick-and-Place Controller in MuJoCo.
Franka Emika Panda arm mounted on a 4-wheeled mobile base (AGV).

Operational Phases:
  1. DRIVE_TO_PICK  : Mobile base navigates from home (0,0) across the floor to Table 1 (0.68, 0).
  2. APPROACH       : Arm end-effector moves to hover above the red block.
  3. DESCEND        : Gripper lowers down around the block.
  4. GRASP          : Gripper fingers close firmly to secure the block.
  5. LIFT           : Arm lifts the block off Table 1 into the air.
  6. DRIVE_TO_PLACE : Mobile base turns 90° and drives across the room to Table 2 (0, 0.78) carrying the block.
  7. RELEASE        : Gripper opens to drop the block safely into the green tray.
  8. RETURN_HOME    : Robot drives back to (0,0) and arm returns to home configuration.
  9. DONE           : Final task verification and parking.
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import mujoco.viewer
import numpy as np


class MobileFSMState(Enum):
    DRIVE_TO_PICK = auto()
    APPROACH = auto()
    DESCEND = auto()
    GRASP = auto()
    LIFT = auto()
    DRIVE_TO_PLACE = auto()
    RELEASE = auto()
    RETURN_HOME = auto()
    DONE = auto()


def minimum_jerk_traj(q0: np.ndarray, q1: np.ndarray, tau: float) -> np.ndarray:
    """
    Computes smooth 5th-order minimum-jerk trajectory parameterization.
    tau: normalized time in [0, 1].
    s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5.
    Zero velocity and acceleration at start and finish.
    """
    tau = np.clip(tau, 0.0, 1.0)
    s = 10.0 * (tau ** 3) - 15.0 * (tau ** 4) + 6.0 * (tau ** 5)
    return (1.0 - s) * q0 + s * q1


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """
    Solves inverse kinematics for the 7-DOF Panda arm on the mobile base.
    """
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0  # evaluate relative to base origin

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        # Arm joints are nv indices 3 to 10
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq
        for j in range(7):
            d_ik.qpos[3 + j] = np.clip(
                d_ik.qpos[3 + j], model.jnt_range[3 + j, 0], model.jnt_range[3 + j, 1]
            )
        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


class MobilePandaController:
    """
    Finite State Machine for Mobile Manipulator Pick-and-Place across two tables.
    """

    def __init__(self, model: mujoco.MjModel, data: mujoco.MjData):
        self.model = model
        self.data = data

        self.site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
        self.block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
        self.tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
        self.base_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "mobile_base")

        mujoco.mj_resetDataKeyframe(model, data, 0)
        mujoco.mj_forward(model, data)

        self.q_home = data.qpos[3:10].copy()
        self.target_mat = data.site_xmat[self.site_id].reshape(3, 3).copy()

        # Mobile Base Waypoints [x, y, yaw]
        self.base_home = np.array([0.0, 0.0, 0.0])
        self.base_pick = np.array([0.68, 0.0, 0.0])
        self.base_place = np.array([0.0, 0.78, 1.57079])  # 90 degrees turned facing Table 2

        # Arm IK targets relative to base origin
        # Base top is at z = 0.18m; block on table is at z = 0.405m
        print("=== Computing Mobile Manipulator Arm Waypoints ===")
        self.q_approach, ok1 = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), self.target_mat)
        self.q_descend, ok2 = solve_arm_ik(model, np.array([0.47, 0.0, 0.395]), self.target_mat, self.q_approach)
        self.q_lift, ok3 = solve_arm_ik(model, np.array([0.47, 0.0, 0.56]), self.target_mat, self.q_descend)
        print(f"  [APPROACH] IK: {ok1} | [DESCEND] IK: {ok2} | [LIFT] IK: {ok3}")

        # State Durations (seconds)
        self.durations = {
            MobileFSMState.DRIVE_TO_PICK: 2.5,
            MobileFSMState.APPROACH: 1.2,
            MobileFSMState.DESCEND: 1.0,
            MobileFSMState.GRASP: 0.8,
            MobileFSMState.LIFT: 1.0,
            MobileFSMState.DRIVE_TO_PLACE: 3.5,
            MobileFSMState.RELEASE: 0.8,
            MobileFSMState.RETURN_HOME: 2.5,
            MobileFSMState.DONE: 1.0,
        }

        self.GRIPPER_OPEN = 255.0
        self.GRIPPER_CLOSE = 0.0

        # State tracking
        self.current_state = MobileFSMState.DRIVE_TO_PICK
        self.state_start_time = 0.0
        self.state_arm_start = self.q_home.copy()
        self.state_base_start = self.base_home.copy()
        self.state_just_entered = True

    def update(self, sim_time: float) -> tuple[np.ndarray, float, np.ndarray, bool]:
        """
        Returns:
          q_arm (7-element array): Arm joint targets
          gripper_target (float): Gripper command (0 closed, 255 open)
          q_base (3-element array): Mobile base command [x, y, yaw]
          is_done (bool): Whether the episode is complete
        """
        if self.state_just_entered:
            self.state_start_time = sim_time
            self.state_just_entered = False
            self._log_state_entry()

        time_in_state = sim_time - self.state_start_time
        duration = self.durations[self.current_state]
        tau = np.clip(time_in_state / duration, 0.0, 1.0)
        is_done = False

        if self.current_state == MobileFSMState.DRIVE_TO_PICK:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_pick, tau)
            q_arm = self.q_home
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(MobileFSMState.APPROACH, q_arm, self.base_pick)

        elif self.current_state == MobileFSMState.APPROACH:
            q_base = self.base_pick
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_approach, tau)
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(MobileFSMState.DESCEND, self.q_approach, self.base_pick)

        elif self.current_state == MobileFSMState.DESCEND:
            q_base = self.base_pick
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_descend, tau)
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(MobileFSMState.GRASP, self.q_descend, self.base_pick)

        elif self.current_state == MobileFSMState.GRASP:
            q_base = self.base_pick
            q_arm = self.q_descend
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(MobileFSMState.LIFT, self.q_descend, self.base_pick)

        elif self.current_state == MobileFSMState.LIFT:
            q_base = self.base_pick
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_lift, tau)
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(MobileFSMState.DRIVE_TO_PLACE, self.q_lift, self.base_pick)

        elif self.current_state == MobileFSMState.DRIVE_TO_PLACE:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_place, tau)
            q_arm = self.q_lift
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(MobileFSMState.RELEASE, self.q_lift, self.base_place)

        elif self.current_state == MobileFSMState.RELEASE:
            q_base = self.base_place
            q_arm = self.q_lift
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(MobileFSMState.RETURN_HOME, self.q_lift, self.base_place)

        elif self.current_state == MobileFSMState.RETURN_HOME:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_home, tau)
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_home, tau)
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(MobileFSMState.DONE, self.q_home, self.base_home)

        elif self.current_state == MobileFSMState.DONE:
            q_base = self.base_home
            q_arm = self.q_home
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                is_done = True

        return q_arm, gripper_target, q_base, is_done

    def _transition(self, next_state: MobileFSMState, current_arm: np.ndarray, current_base: np.ndarray):
        self.current_state = next_state
        self.state_arm_start = current_arm.copy()
        self.state_base_start = current_base.copy()
        self.state_just_entered = True

    def _log_state_entry(self):
        base_pos = self.data.qpos[:3]
        block_pos = self.data.xpos[self.block_id]
        print(
            f"[{self.data.time:6.3f}s] >>> FSM: {self.current_state.name:<15} | "
            f"Base: [{base_pos[0]:.2f}, {base_pos[1]:.2f}, {base_pos[2]:.2f} rad] | "
            f"Block: [{block_pos[0]:.2f}, {block_pos[1]:.2f}, {block_pos[2]:.2f}]"
        )


def run_mobile_simulation(
    xml_path: str = "mobile_panda.xml",
    render_video: bool = True,
    video_path: str = "mobile_pick_and_place.mp4",
    launch_gui: bool = False,
):
    print(f"\nLoading Mobile Manipulator from '{xml_path}'...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    controller = MobilePandaController(model, data)
    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")

    if launch_gui:
        print("\nStarting Interactive 3D Viewer (Press Space to pause/resume, Esc to exit)...")
        try:
            with mujoco.viewer.launch_passive(model, data) as viewer:
                viewer.cam.distance = 3.2
                viewer.cam.elevation = -28.0
                viewer.cam.azimuth = 135.0
                viewer.cam.lookat = np.array([0.6, 0.6, 0.3])

                dt = model.opt.timestep
                while viewer.is_running():
                    t_start = time.perf_counter()
                    q_arm, grip, q_base, is_done = controller.update(data.time)

                    data.ctrl[:7] = q_arm
                    data.ctrl[7] = grip
                    data.ctrl[8:11] = q_base

                    mujoco.mj_step(model, data)
                    viewer.sync()

                    if is_done:
                        print("\nMobile pick-and-place completed! Holding parked position...")
                        time.sleep(1.5)
                        break

                    elapsed = time.perf_counter() - t_start
                    if dt > elapsed:
                        time.sleep(dt - elapsed)
        except RuntimeError as exc:
            if "mjpython" in str(exc):
                print("\n[NOTE] On macOS, interactive GUI requires running with 'mjpython':")
                print("       .venv/bin/mjpython mobile_pick_and_place.py --viewer\n")
            else:
                raise exc

    else:
        # Offscreen simulation & MP4 video recording
        renderer = None
        video_writer = None
        fps = 30
        sim_dt = model.opt.timestep
        steps_per_frame = int(round(1.0 / (fps * sim_dt)))

        if render_video:
            width, height = 640, 480
            renderer = mujoco.Renderer(model, height, width)
            cam = mujoco.MjvCamera()
            cam.distance = 3.2
            cam.elevation = -28.0
            cam.azimuth = 135.0
            cam.lookat = np.array([0.6, 0.6, 0.3])

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            video_writer = cv2.VideoWriter(video_path, fourcc, fps, (width, height))
            print(f"Rendering mobile simulation to '{video_path}' at {fps} FPS...")

        step_count = 0
        is_done = False
        t_wall_start = time.perf_counter()

        while not is_done and data.time < 20.0:
            q_arm, grip, q_base, is_done = controller.update(data.time)

            data.ctrl[:7] = q_arm
            data.ctrl[7] = grip
            data.ctrl[8:11] = q_base

            mujoco.mj_step(model, data)

            if render_video and (step_count % steps_per_frame == 0):
                renderer.update_scene(data, camera=cam)
                pixels = renderer.render()
                frame_bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
                video_writer.write(frame_bgr)

            step_count += 1

        if render_video and video_writer is not None:
            # Trailing hold frames
            for _ in range(fps):
                renderer.update_scene(data, camera=cam)
                pixels = renderer.render()
                frame_bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
                video_writer.write(frame_bgr)
            video_writer.release()
            print(f"Video saved successfully to '{video_path}'")

        wall_duration = time.perf_counter() - t_wall_start
        print(f"\nSimulation finished: {data.time:.2f}s simulated in {wall_duration:.2f}s wall time.")

    # Verification
    final_block = data.xpos[block_id]
    tray_pos = data.xpos[tray_id]
    xy_dist = np.linalg.norm(final_block[:2] - tray_pos[:2])

    print("\n================== TASK VERIFICATION ==================")
    print(f"Final Red Block Position : [{final_block[0]:.4f}, {final_block[1]:.4f}, {final_block[2]:.4f}]")
    print(f"Green Tray Center        : [{tray_pos[0]:.4f}, {tray_pos[1]:.4f}, {tray_pos[2]:.4f}]")
    print(f"Distance to Tray Center  : {xy_dist * 100:.2f} cm (Tray radius: 6.0 cm)")

    in_tray_xy = abs(final_block[0] - tray_pos[0]) < 0.055 and abs(final_block[1] - tray_pos[1]) < 0.055
    in_tray_z = 0.40 <= final_block[2] <= 0.46

    if in_tray_xy and in_tray_z:
        print("RESULT: SUCCESS! Mobile robot drove across the room, picked up the block, and delivered it into the tray!")
    else:
        print("RESULT: FAILURE! The block is not inside the tray.")
    print("=======================================================\n")


def main():
    parser = argparse.ArgumentParser(description="Franka Panda Mobile Manipulator Simulation.")
    parser.add_argument("--scene", type=str, default="mobile_panda.xml", help="Path to XML model file.")
    parser.add_argument("--video", type=str, default="mobile_pick_and_place.mp4", help="Video output filename.")
    parser.add_argument("--no-video", action="store_true", help="Disable video rendering.")
    parser.add_argument("--viewer", action="store_true", help="Launch interactive 3D GUI viewer.")
    args = parser.parse_args()

    run_mobile_simulation(
        xml_path=args.scene,
        render_video=not args.no_video and not args.viewer,
        video_path=args.video,
        launch_gui=args.viewer,
    )


if __name__ == "__main__":
    main()
