"""
3D RGB-D SLAM Autonomous Pick-and-Place Demonstration Pipeline.
Integrates:
1. Full 3D Voxel SLAM mapping from onboard RGB-D camera streams.
2. Open-Vocabulary Natural Language Targeting ("red box" -> "green tray").
3. 3D Optical Back-Projection & 3D Spatial Target Anchoring.
4. Pure Pursuit Corridor Navigation with Rate-Limited Base Steering.
5. 7-DOF Panda Arm Inverse Kinematics with 5th-Order Minimum-Jerk Execution.
6. Multi-Panel Synchronized Video Recorder with Live 3D Perspective SLAM & Orbital Fly-Around.
7. Export of 3D Voxel Map to standard ASCII PLY point cloud format.
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import numpy as np

from slam_3d import RGBD_SLAM3D
from open_vocab_detector import OpenVocabularyTargetDetector


class MissionState(Enum):
    INITIAL_SURVEY = auto()
    SEARCH_BOX = auto()
    BOX_SPOTTED = auto()
    APPROACH_BOX = auto()
    ARM_APPROACH_BOX = auto()
    ARM_DESCEND_BOX = auto()
    ARM_GRASP_BOX = auto()
    ARM_LIFT_BOX = auto()
    TRANSIT_CARRY = auto()
    SEARCH_TRAY = auto()
    TRAY_SPOTTED = auto()
    APPROACH_TRAY = auto()
    ARM_HOVER_TRAY = auto()
    ARM_LOWER_TRAY = auto()
    ARM_RELEASE_TRAY = auto()
    ARM_RETRACT = auto()
    MISSION_SUCCESS = auto()


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """Solves inverse kinematics for the 7-DOF Panda arm on the mobile base."""
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0  # evaluate relative to base origin

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq

        for j in range(7):
            jnt_id = j + 3
            j_range = model.jnt_range[jnt_id]
            d_ik.qpos[3 + j] = np.clip(d_ik.qpos[3 + j], j_range[0], j_range[1])

        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


def run_3d_slam_pipeline(
    video_path: str = "slam_3d_pick_and_place_demo.mp4",
    ply_path: str = "slam_3d_arena_map.ply",
    max_steps: int = 4500,
):
    print("\n" + "=" * 68)
    print("  3D RGB-D SLAM & OPEN-VOCABULARY MOBILE MANIPULATION PIPELINE       ")
    print("=" * 68)

    xml_path = "search_arena.xml"
    if not os.path.exists(xml_path):
        raise FileNotFoundError(f"Model file '{xml_path}' not found.")

    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    # Disable collision on sensor mast and cam housing to prevent arm elbow jamming
    for name in ["sensor_mast", "nav_cam_housing", "nav_cam_lens"]:
        gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        if gid != -1:
            model.geom_contype[gid] = 0
            model.geom_conaffinity[gid] = 0

    mujoco.mj_resetDataKeyframe(model, data, 0)
    mujoco.mj_forward(model, data)

    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
    cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "nav_cam")

    print(f"[*] Environment Initialized.")
    print(f"[*] Red Box Location:     ({data.xpos[block_id][0]:.2f}, {data.xpos[block_id][1]:.2f})")
    print(f"[*] Green Tray Location:  ({data.xpos[tray_id][0]:.2f}, {data.xpos[tray_id][1]:.2f})")
    print(f"[*] Mobile Robot Spawn:   ({data.qpos[0]:.2f}, {data.qpos[1]:.2f})")
    print(f"[*] Initial Target Prompt: 'red box'\n")

    # Initialize 3D RGB-D SLAM Engine
    slam_3d = RGBD_SLAM3D(map_size_m=6.0, voxel_size_m=0.04, robot_radius_m=0.28)
    detector = OpenVocabularyTargetDetector(initial_prompt="red box")

    vw, vh = 400, 300
    r_nav = mujoco.Renderer(model, vh, vw)
    r_chase = mujoco.Renderer(model, vh, vw)

    out_w, out_h = vw * 3, vh + 36
    video_writer = None
    if video_path:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        video_writer = cv2.VideoWriter(video_path, fourcc, 20.0, (out_w, out_h))
        print(f"[*] Recording 3D SLAM demonstration video to: {video_path}")

    # Arm configurations
    q_retracted = np.array([0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785])
    cur_arm_ctrl = q_retracted.copy()
    cur_base_ctrl = np.array([data.qpos[0], data.qpos[1], data.qpos[2]], dtype=float)
    cur_gripper_ctrl = 255.0

    # Downward Grasp Orientation
    home_mat = np.array([
        [9.81983171e-05, 9.99999995e-01, 1.51444362e-16],
        [9.99999995e-01, -9.81983171e-05, 3.15263149e-16],
        [3.15278019e-16, 1.51413403e-16, -1.00000000e+00]
    ])

    # Initial default IK poses
    q_approach, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), home_mat)
    q_descend, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.375]), home_mat, q_approach)
    q_lift, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.58]), home_mat, q_descend)
    q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)

    # Tray IK poses
    q_tray_hover, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.52]), home_mat)
    q_tray_lower, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.420]), home_mat, q_tray_hover)

    state = MissionState.INITIAL_SURVEY
    state_timer = 0
    t_state_start = 0

    target_box_pos = None
    target_tray_pos = None

    current_path = []
    waypoint_idx = 0

    step = 0
    sim_dt = model.opt.timestep
    perception_subsample = 10

    # Transit corridor waypoints avoiding all central partitions
    transit_waypoints = [
        (0.50, -1.00, 2.3),
        (-0.50, -0.80, 3.14159),
    ]
    transit_idx = 0

    while step < max_steps:
        robot_x = data.qpos[0]
        robot_y = data.qpos[1]
        robot_yaw = data.qpos[2]

        # -------------------------------------------------------------
        # PERCEPTION & 3D RGB-D SLAM PIPELINE
        # -------------------------------------------------------------
        detection = None
        cam_pos = data.cam_xpos[cam_id]
        cam_mat = data.cam_xmat[cam_id].reshape(3, 3)

        if step % perception_subsample == 0:
            r_nav.update_scene(data, camera="nav_cam")
            r_nav.enable_depth_rendering()
            depth = r_nav.render()
            r_nav.disable_depth_rendering()
            rgb_nav = r_nav.render()

            # Integrate RGB-D Frame into 3D Voxel SLAM
            slam_3d.integrate_depth_scan(
                depth_map=depth,
                robot_x=robot_x,
                robot_y=robot_y,
                robot_yaw=robot_yaw,
                cam_pos=cam_pos,
                cam_mat=cam_mat,
                rgb_map=rgb_nav,
                fovy_deg=85.0,
                max_range=3.5,
                subsample_step=3,
            )

            # Detect active target prompt
            detection = detector.detect(rgb_nav, depth, model, data, cam_name="nav_cam")

            # Stage 1: Looking for Box
            if state in [MissionState.INITIAL_SURVEY, MissionState.SEARCH_BOX]:
                if detection is not None and "box" in detector.active_prompt:
                    latest_pos = detection["world_pos"]
                    if target_box_pos is None:
                        target_box_pos = latest_pos.copy()
                        state = MissionState.BOX_SPOTTED
                        state_timer = step
                        slam_3d.set_target("red box", target_box_pos, color=(255, 30, 30), size=0.06)
                        print(f"\n[!] >>> TARGET 'red box' SPOTTED at step {step} (t={step*sim_dt:.1f}s) <<<")
                        print(f"    Estimated 3D Location: ({latest_pos[0]:.3f}, {latest_pos[1]:.3f}, {latest_pos[2]:.3f})")
                        print(f"    Ground Truth Location: ({data.xpos[block_id][0]:.3f}, {data.xpos[block_id][1]:.3f}, {data.xpos[block_id][2]:.3f})")
                        err = np.linalg.norm(latest_pos[:2] - data.xpos[block_id][:2])
                        print(f"    Initial Optical Error: {err * 100:.2f} cm\n")
                    else:
                        target_box_pos = 0.7 * target_box_pos + 0.3 * latest_pos
                        slam_3d.set_target("red box", target_box_pos, color=(255, 30, 30), size=0.06)

            # Stage 2: Looking for Tray
            elif state in [MissionState.SEARCH_TRAY]:
                if detection is not None and "tray" in detector.active_prompt:
                    latest_pos = detection["world_pos"]
                    if target_tray_pos is None:
                        target_tray_pos = latest_pos.copy()
                    else:
                        target_tray_pos = 0.7 * target_tray_pos + 0.3 * latest_pos

                    slam_3d.set_target("green tray", target_tray_pos, color=(30, 240, 30), size=0.16)

                    # Only transition once robot has cleared corridor partitions into quadrant 2
                    if robot_x < -0.1 or transit_idx >= len(transit_waypoints):
                        state = MissionState.TRAY_SPOTTED
                        state_timer = step
                        print(f"\n[!] >>> TARGET 'green tray' LOCKED at step {step} (t={step*sim_dt:.1f}s) <<<")
                        print(f"    Estimated 3D Location: ({target_tray_pos[0]:.3f}, {target_tray_pos[1]:.3f}, {target_tray_pos[2]:.3f})")
                        print(f"    Ground Truth Location: ({data.xpos[tray_id][0]:.3f}, {data.xpos[tray_id][1]:.3f}, {data.xpos[tray_id][2]:.3f})")
                        err = np.linalg.norm(target_tray_pos[:2] - data.xpos[tray_id][:2])
                        print(f"    Optical Localization Error: {err * 100:.2f} cm\n")

        # -------------------------------------------------------------
        # FINITE STATE MACHINE (FSM)
        # -------------------------------------------------------------
        # --- STAGE 1: SEARCH & PICK RED BOX ---
        if state == MissionState.INITIAL_SURVEY:
            cur_base_ctrl[2] += 0.018  # smooth rotation
            if step > 380:
                state = MissionState.SEARCH_BOX
                print("[*] Completed 360 Initial Survey. Transitioning to State: SEARCH_BOX")

        elif state == MissionState.SEARCH_BOX:
            if not current_path or waypoint_idx >= len(current_path) or step % 180 == 0:
                frontiers = slam_3d.find_frontiers()
                best_f = slam_3d.select_best_frontier(robot_x, robot_y, robot_yaw, frontiers)
                if best_f is not None:
                    current_path = slam_3d.plan_path_astar((robot_x, robot_y), best_f["world_pos"])
                    waypoint_idx = 1 if len(current_path) > 1 else 0

            if current_path and waypoint_idx < len(current_path):
                target_wp = current_path[waypoint_idx]
                wp_dx = target_wp[0] - robot_x
                wp_dy = target_wp[1] - robot_y
                dist_to_wp = np.hypot(wp_dx, wp_dy)
                if dist_to_wp < 0.25:
                    waypoint_idx += 1
                else:
                    target_yaw = np.arctan2(wp_dy, wp_dx)
                    yaw_diff = (target_yaw - cur_base_ctrl[2] + np.pi) % (2.0 * np.pi) - np.pi
                    if abs(yaw_diff) > 0.40:
                        cur_base_ctrl[2] += np.clip(yaw_diff, -0.022, 0.022)
                    else:
                        cur_base_ctrl[2] += np.clip(yaw_diff, -0.016, 0.016)
                        cur_base_ctrl[0] += 0.0038 * (wp_dx / dist_to_wp)
                        cur_base_ctrl[1] += 0.0038 * (wp_dy / dist_to_wp)

        elif state == MissionState.BOX_SPOTTED:
            if step - state_timer > 30:
                state = MissionState.APPROACH_BOX
                print("[*] Transitioning to State: APPROACH_BOX")

        elif state == MissionState.APPROACH_BOX:
            tx, ty = target_box_pos[0], target_box_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx - standoff_dist
            target_standoff_y = ty
            target_heading = 0.0

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.40:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.35:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.022, 0.022)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.016, 0.016)
                v_step = min(0.0045, pos_err * 0.05)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.04 and abs(yaw_err) < 0.06:
                state = MissionState.ARM_APPROACH_BOX
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw
                print(f"\n[*] Reached Pick Standoff! Base locked at: ({robot_x:.3f}, {robot_y:.3f}, yaw={robot_yaw:.3f})")

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_bx = cos_y * dx_world + sin_y * dy_world
                local_by = -sin_y * dx_world + cos_y * dy_world

                q_approach, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.54]), home_mat)
                q_descend, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.375]), home_mat, q_approach)
                q_lift, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.58]), home_mat, q_descend)
                q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)
                print(f"[*] Dynamic Arm IK Solved for local offset: ({local_bx:.3f}, {local_by:.3f})")

        elif state == MissionState.ARM_APPROACH_BOX:
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_retracted + s * q_approach
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_DESCEND_BOX
                t_state_start = step
                print("[*] Transitioning to State: ARM_DESCEND_BOX")

        elif state == MissionState.ARM_DESCEND_BOX:
            tau = np.clip((step - t_state_start) / 240.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_approach + s * q_descend
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_GRASP_BOX
                t_state_start = step
                print("[*] Transitioning to State: ARM_GRASP_BOX (Closing Gripper)")

        elif state == MissionState.ARM_GRASP_BOX:
            cur_arm_ctrl = q_descend
            cur_gripper_ctrl = 0.0
            if step - t_state_start > 240:
                state = MissionState.ARM_LIFT_BOX
                t_state_start = step
                print(f"[*] Transitioning to State: ARM_LIFT_BOX | Block Pos: {data.xpos[block_id]}")

        elif state == MissionState.ARM_LIFT_BOX:
            tau = np.clip((step - t_state_start) / 280.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_descend + s * q_lift
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.TRANSIT_CARRY
                t_state_start = step
                print(f"[*] Transitioning to State: TRANSIT_CARRY | Block Pos: {data.xpos[block_id]}")

        elif state == MissionState.TRANSIT_CARRY:
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_lift + s * q_carry
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                detector.set_target_prompt("green tray")
                state = MissionState.SEARCH_TRAY
                state_timer = step
                print("\n" + "=" * 68)
                print("  STAGE 2: PAYLOAD SECURED! PROMPT SWITCHED TO: 'green tray'       ")
                print("=" * 68 + "\n")

        # --- STAGE 2: SEARCH & DELIVER TO GREEN TRAY ---
        elif state == MissionState.SEARCH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0

            if step % 80 == 0:
                print(f"[*] TRANSIT: Step {step} | Robot Pos: ({robot_x:.2f}, {robot_y:.2f}) | Yaw: {robot_yaw:.2f} rad | Waypoint: {transit_idx}")

            if transit_idx < len(transit_waypoints):
                tx, ty, tyaw = transit_waypoints[transit_idx]
                dx = tx - robot_x
                dy = ty - robot_y
                dist = np.hypot(dx, dy)
                if dist < 0.30 and transit_idx < len(transit_waypoints) - 1:
                    transit_idx += 1
                elif dist < 0.15 and transit_idx == len(transit_waypoints) - 1:
                    transit_idx += 1
                else:
                    heading = np.arctan2(dy, dx) if dist > 0.35 else tyaw
                    yaw_err = (heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
                    if abs(yaw_err) > 0.35:
                        cur_base_ctrl[2] += np.clip(yaw_err, -0.008, 0.008)
                    else:
                        cur_base_ctrl[2] += np.clip(yaw_err, -0.006, 0.006)
                        v_step = min(0.0035, dist * 0.04)
                        if dist > 0.01:
                            cur_base_ctrl[0] += v_step * (dx / dist)
                            cur_base_ctrl[1] += v_step * (dy / dist)
            else:
                cur_base_ctrl[2] += 0.008

        elif state == MissionState.TRAY_SPOTTED:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0
            if step - state_timer > 30:
                state = MissionState.APPROACH_TRAY
                print("[*] Transitioning to State: APPROACH_TRAY")

        elif state == MissionState.APPROACH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0

            if step % 80 == 0:
                print(f"[*] APPROACH TRAY: Step {step} | Robot Pos: ({robot_x:.2f}, {robot_y:.2f})")

            tx, ty = target_tray_pos[0], target_tray_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx + standoff_dist
            target_standoff_y = ty
            target_heading = np.pi  # facing West toward drop table

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.40:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.35:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.008, 0.008)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.006, 0.006)
                v_step = min(0.0035, pos_err * 0.04)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.05 and abs(yaw_err) < 0.08:
                state = MissionState.ARM_HOVER_TRAY
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw
                print(f"\n[*] Reached Tray Standoff! Base locked at: ({robot_x:.3f}, {robot_y:.3f}, yaw={robot_yaw:.3f})")

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_tx = cos_y * dx_world + sin_y * dy_world
                local_ty = -sin_y * dx_world + cos_y * dy_world

                q_tray_hover, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.52]), home_mat)
                q_tray_lower, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.420]), home_mat, q_tray_hover)
                print(f"[*] Dynamic Arm IK Solved for local tray offset: ({local_tx:.3f}, {local_ty:.3f})")

        elif state == MissionState.ARM_HOVER_TRAY:
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_carry + s * q_tray_hover
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_LOWER_TRAY
                t_state_start = step
                print("[*] Transitioning to State: ARM_LOWER_TRAY (Lowering into Tray Cavity)")

        elif state == MissionState.ARM_LOWER_TRAY:
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_hover + s * q_tray_lower
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_RELEASE_TRAY
                t_state_start = step
                print("[*] Transitioning to State: ARM_RELEASE_TRAY (Opening Fingers to Deposit Box)")

        elif state == MissionState.ARM_RELEASE_TRAY:
            cur_arm_ctrl = q_tray_lower
            cur_gripper_ctrl = 255.0
            if step - t_state_start > 180:
                state = MissionState.ARM_RETRACT
                t_state_start = step
                print(f"[*] Transitioning to State: ARM_RETRACT | Block Pos: {data.xpos[block_id]}")

        elif state == MissionState.ARM_RETRACT:
            tau = np.clip((step - t_state_start) / 200.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_lower + s * q_tray_hover
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.MISSION_SUCCESS
                state_timer = step
                print(f"[*] Transitioning to State: MISSION_SUCCESS | Block Pos: {data.xpos[block_id]}")
                print("\n" + "=" * 68)
                print("  MISSION SUCCESS: RED BOX DEPOSITED CLEANLY INTO GREEN TRAY!   ")
                print("=" * 68 + "\n")

        # -------------------------------------------------------------
        # APPLY CONTROLS & PHYSICS STEP
        # -------------------------------------------------------------
        data.ctrl[0:7] = cur_arm_ctrl
        data.ctrl[7] = cur_gripper_ctrl
        data.ctrl[8] = cur_base_ctrl[0]
        data.ctrl[9] = cur_base_ctrl[1]
        data.ctrl[10] = cur_base_ctrl[2]

        mujoco.mj_step(model, data)

        # -------------------------------------------------------------
        # 3D SLAM MULTI-PANEL VIDEO RECORDING (20 FPS)
        # -------------------------------------------------------------
        if video_writer is not None and step % 22 == 0:
            r_chase.update_scene(data, camera="chase_cam")
            rgb_chase = r_chase.render()

            r_nav.update_scene(data, camera="nav_cam")
            rgb_nav_clean = r_nav.render()
            rgb_nav_hud = detector.render_overlay(rgb_nav_clean, detection)

            active_target = target_tray_pos if "tray" in detector.active_prompt else target_box_pos

            # Render Live 3D Perspective SLAM Map Panel
            slam_3d_panel = slam_3d.render_3d_view(
                width=vw,
                height=vh,
                show_frustum=True,
                cur_cam_pos=cam_pos,
                cur_cam_mat=cam_mat,
                active_target_w=(active_target[0], active_target[1]) if active_target is not None else None,
                color_mode="rgb",
            )

            cv2.putText(rgb_chase, "EXTERNAL CHASE CAM", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(rgb_nav_hud, "ONBOARD RGB-D (OPEN-VOCAB)", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)

            panels = np.hstack([rgb_chase, rgb_nav_hud, slam_3d_panel])

            # Top Telemetry Header Bar
            header = np.full((36, out_w, 3), (20, 22, 28), dtype=np.uint8)
            cv2.line(header, (0, 35), (out_w, 35), (60, 68, 80), 1)

            status_text = f"3D SLAM | STATE: {state.name} | Steps: {step} | Prompt: '{detector.active_prompt}'"
            if active_target is not None:
                status_text += f" | Lock: ({active_target[0]:.2f}, {active_target[1]:.2f})"
            status_text += f" | 3D Voxels: {len(slam_3d.voxels):,}"

            cv2.putText(header, status_text, (18, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.46, (0, 220, 255), 1, cv2.LINE_AA)

            composite = np.vstack([header, panels])
            bgr_frame = cv2.cvtColor(composite, cv2.COLOR_RGB2BGR)
            video_writer.write(bgr_frame)

        if state == MissionState.MISSION_SUCCESS and step - state_timer > 120:
            break

        step += 1

    # -----------------------------------------------------------------
    # ORBITAL 3D FLY-AROUND OF THE COMPLETED 3D SLAM RECONSTRUCTION
    # -----------------------------------------------------------------
    if video_writer is not None:
        print("[*] Rendering 360-degree Orbital 3D Fly-Around of mapped arena...")
        r_chase.update_scene(data, camera="overview_cam")
        overview_rgb = r_chase.render()
        r_nav.update_scene(data, camera="nav_cam")
        nav_rgb = detector.render_overlay(r_nav.render(), None)

        num_orbit_frames = 100
        for i in range(num_orbit_frames):
            angle = (2.0 * np.pi) * (i / num_orbit_frames) - (np.pi / 4.0)
            orbit_cam_pos = np.array([4.2 * np.cos(angle), 4.2 * np.sin(angle), 3.2])
            orbit_target = np.array([0.0, 0.0, 0.3])

            slam_3d_orbit = slam_3d.render_3d_view(
                width=vw,
                height=vh,
                vcam_pos=orbit_cam_pos,
                vcam_target=orbit_target,
                show_frustum=False,
                color_mode="rgb",
            )

            cv2.putText(overview_rgb, "ARENA OVERVIEW", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(nav_rgb, "DELIVERY COMPLETE", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)

            panels = np.hstack([overview_rgb, nav_rgb, slam_3d_orbit])
            header = np.full((36, out_w, 3), (20, 22, 28), dtype=np.uint8)
            cv2.line(header, (0, 35), (out_w, 35), (0, 200, 100), 2)
            cv2.putText(
                header,
                f"3D RGB-D SLAM RECONSTRUCTION | 360-DEGREE ORBITAL INSPECTION | Voxels: {len(slam_3d.voxels):,}",
                (18, 24),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.46,
                (0, 255, 180),
                1,
                cv2.LINE_AA,
            )
            composite = np.vstack([header, panels])
            video_writer.write(cv2.cvtColor(composite, cv2.COLOR_RGB2BGR))

        video_writer.release()
        print(f"[*] Complete demonstration video saved cleanly ({step} steps + {num_orbit_frames} orbit frames).")

    # Export 3D PLY Point Cloud
    if ply_path:
        slam_3d.export_ply(ply_path)

    block_pos = data.xpos[block_id]
    tray_pos = data.xpos[tray_id]
    offset_to_tray = np.linalg.norm(block_pos[:2] - tray_pos[:2])
    print(f"[*] Final Payload Box Pos: ({block_pos[0]:.3f}, {block_pos[1]:.3f}, {block_pos[2]:.3f})")
    print(f"[*] Final Green Tray Pos:  ({tray_pos[0]:.3f}, {tray_pos[1]:.3f}, {tray_pos[2]:.3f})")
    print(f"[*] Offset from Tray Center: {offset_to_tray * 100:.2f} cm")

    if offset_to_tray < 0.10 and block_pos[2] < 0.45:
        print("\n[+] COMPLETE TRIUMPH: Red box is safely resting inside the green tray!")
    else:
        print("\n[-] Notice: Box placement offset is", offset_to_tray)

    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="3D RGB-D SLAM Pick and Place in MuJoCo")
    parser.add_argument("--video", type=str, default="slam_3d_pick_and_place_demo.mp4", help="Video output path")
    parser.add_argument("--ply", type=str, default="slam_3d_arena_map.ply", help="3D PLY export path")
    parser.add_argument("--steps", type=int, default=4500, help="Max simulation steps")
    args = parser.parse_args()

    run_3d_slam_pipeline(
        video_path=args.video,
        ply_path=args.ply,
        max_steps=args.steps,
    )
