"""
Evaluation Suite: 10 Randomized Scene Trials for Autonomous Pick-and-Place.
Tests the Franka Emika Panda mobile manipulation pipeline in MuJoCo across
10 distinct randomized environments with:
- Randomized robot spawn pose (X, Y, Yaw)
- Randomized payload block placement on the pick table
- Randomized delivery tray and drop table placement
- Randomized distractor crate positions
- Segment Anything Model (SAM ViT-B) open-vocabulary visual perception
- Pure pursuit navigation, dynamic arm inverse kinematics, and precision placement
"""

import argparse
import os
import sys
import time
from enum import Enum, auto
import cv2
import mujoco
import numpy as np

from frontier_slam import OccupancyGridSLAM
from open_vocab_detector import OpenVocabularyTargetDetector


class MissionState(Enum):
    INITIAL_SURVEY = auto()
    SEARCH_BOX = auto()
    BOX_SPOTTED = auto()
    APPROACH_BOX = auto()
    ARM_APPROACH_BOX = auto()
    ARM_DESCEND_BOX = auto()
    ARM_GRASP_BOX = auto()
    ARM_LIFT_BOX = auto()
    TRANSIT_CARRY = auto()
    SEARCH_TRAY = auto()
    TRAY_SPOTTED = auto()
    APPROACH_TRAY = auto()
    ARM_HOVER_TRAY = auto()
    ARM_LOWER_TRAY = auto()
    ARM_RELEASE_TRAY = auto()
    ARM_RETRACT = auto()
    MISSION_SUCCESS = auto()


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """Solves inverse kinematics for the 7-DOF Panda arm on the mobile base."""
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq

        for j in range(7):
            jnt_id = j + 3
            j_range = model.jnt_range[jnt_id]
            d_ik.qpos[3 + j] = np.clip(d_ik.qpos[3 + j], j_range[0], j_range[1])

        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


def run_single_episode(
    ep_num: int,
    total_eps: int,
    model: mujoco.MjModel,
    data: mujoco.MjData,
    detector: OpenVocabularyTargetDetector,
    video_writer: cv2.VideoWriter | None = None,
    max_steps: int = 4500,
    seed: int = 42,
) -> dict:
    """Runs a single autonomous pick-and-place episode in a randomized scene."""
    np.random.seed(seed)
    mujoco.mj_resetDataKeyframe(model, data, 0)

    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
    table_drop_gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "table_drop")
    cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "nav_cam")
    block_jnt_adr = model.jnt_qposadr[model.body_jntadr[block_id]]

    # 1. Randomize Robot Initial Spawn Pose
    rx = np.random.uniform(-0.10, 0.10)
    ry = np.random.uniform(-0.10, 0.10)
    ryaw = np.random.uniform(1.35, 1.75)
    data.qpos[0] = rx
    data.qpos[1] = ry
    data.qpos[2] = ryaw

    # 2. Randomize Pick Table & Payload Block Position
    bx = np.random.uniform(1.47, 1.58)
    by = np.random.uniform(-2.00, -1.80)
    data.qpos[block_jnt_adr : block_jnt_adr + 3] = [bx, by, 0.405]

    # 3. Randomize Drop Table & Delivery Tray Position
    tx_table = np.random.uniform(-1.66, -1.54)
    ty_table = np.random.uniform(-0.86, -0.74)
    model.geom_pos[table_drop_gid][:2] = [tx_table, ty_table]
    model.body_pos[tray_id][:2] = [tx_table + 0.20, ty_table]

    # 4. Randomize Distractor Crates
    c_yellow_gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "crate_yellow")
    c_cyan_gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "crate_cyan")
    c_orange_gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, "crate_orange")
    if c_yellow_gid != -1:
        model.geom_pos[c_yellow_gid][0] = 2.1 + np.random.uniform(-0.08, 0.08)
    if c_cyan_gid != -1:
        model.geom_pos[c_cyan_gid][1] = 1.4 + np.random.uniform(-0.08, 0.08)
    if c_orange_gid != -1:
        model.geom_pos[c_orange_gid][0] = 1.5 + np.random.uniform(-0.08, 0.08)

    mujoco.mj_forward(model, data)

    gt_block_initial = data.xpos[block_id].copy()
    gt_tray_pos = data.xpos[tray_id].copy()

    print("\n" + "-" * 65)
    print(f"  EPISODE {ep_num}/{total_eps} (Seed: {seed})")
    print(f"  Robot Spawn:  ({rx:+.2f}, {ry:+.2f}, yaw={ryaw:.2f} rad)")
    print(f"  Block Target: ({gt_block_initial[0]:.3f}, {gt_block_initial[1]:.3f}, {gt_block_initial[2]:.3f})")
    print(f"  Tray Target:  ({gt_tray_pos[0]:.3f}, {gt_tray_pos[1]:.3f}, {gt_tray_pos[2]:.3f})")
    print("-" * 65)

    # Initialize SLAM & reset detector
    slam = OccupancyGridSLAM(map_size_m=6.0, resolution_m=0.05, robot_radius_m=0.22)
    detector.set_target_prompt("red box")

    vw, vh = 400, 300
    r_nav = mujoco.Renderer(model, vh, vw)
    r_chase = mujoco.Renderer(model, vh, vw)
    out_w = vw * 3

    # Arm configurations
    q_retracted = np.array([0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785])
    cur_arm_ctrl = q_retracted.copy()
    cur_base_ctrl = np.array([data.qpos[0], data.qpos[1], data.qpos[2]], dtype=float)
    cur_gripper_ctrl = 255.0

    home_mat = np.array([
        [9.81983171e-05, 9.99999995e-01, 1.51444362e-16],
        [9.99999995e-01, -9.81983171e-05, 3.15263149e-16],
        [3.15278019e-16, 1.51413403e-16, -1.00000000e+00]
    ])

    q_approach, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), home_mat)
    q_descend, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.375]), home_mat, q_approach)
    q_lift, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.58]), home_mat, q_descend)
    q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)
    q_tray_hover, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.52]), home_mat)
    q_tray_lower, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.420]), home_mat, q_tray_hover)

    state = MissionState.INITIAL_SURVEY
    state_timer = 0
    t_state_start = 0

    target_box_pos = None
    target_tray_pos = None

    current_path = []
    waypoint_idx = 0
    transit_waypoints = [
        (0.50, -1.00, 2.3),
        (-0.50, -0.80, 3.14159),
    ]
    transit_idx = 0

    step = 0
    sim_dt = model.opt.timestep
    perception_subsample = 10

    block_spot_step = None
    block_spot_error = None
    tray_spot_step = None
    tray_spot_error = None

    t0_ep = time.time()

    while step < max_steps:
        robot_x = data.qpos[0]
        robot_y = data.qpos[1]
        robot_yaw = data.qpos[2]

        detection = None
        if step % perception_subsample == 0:
            slam.update_odometry(robot_x, robot_y)

            r_nav.update_scene(data, camera="nav_cam")
            r_nav.enable_depth_rendering()
            depth = r_nav.render()
            r_nav.disable_depth_rendering()
            rgb_nav = r_nav.render()

            cam_pos = data.cam_xpos[cam_id]
            cam_mat = data.cam_xmat[cam_id].reshape(3, 3)

            slam.integrate_depth_scan(depth, robot_x, robot_y, robot_yaw, cam_pos, cam_mat, max_range=3.2)
            detection = detector.detect(rgb_nav, depth, model, data, cam_name="nav_cam")

            # Stage 1: Spot Box with SAM
            if state in [MissionState.INITIAL_SURVEY, MissionState.SEARCH_BOX, MissionState.APPROACH_BOX]:
                if detection is not None and "box" in detector.active_prompt:
                    latest_pos = detection["world_pos"]
                    if latest_pos[0] > 0.5:
                        if target_box_pos is None:
                            target_box_pos = latest_pos.copy()
                            state = MissionState.BOX_SPOTTED
                            state_timer = step
                            block_spot_step = step
                            block_spot_error = float(np.linalg.norm(latest_pos[:2] - data.xpos[block_id][:2]))
                            print(f"  [+] SAM Spotted Red Box at step {step}: ({latest_pos[0]:.3f}, {latest_pos[1]:.3f}) | Error: {block_spot_error*100:.2f} cm")
                        else:
                            target_box_pos = 0.7 * target_box_pos + 0.3 * latest_pos
                            block_spot_error = float(np.linalg.norm(target_box_pos[:2] - data.xpos[block_id][:2]))

            # Stage 2: Spot Tray with SAM
            elif state in [MissionState.SEARCH_TRAY, MissionState.APPROACH_TRAY]:
                if detection is not None and "tray" in detector.active_prompt:
                    if robot_x < -0.1 or transit_idx >= len(transit_waypoints):
                        latest_pos = detection["world_pos"]
                        if latest_pos[0] < -0.5:
                            if target_tray_pos is None:
                                target_tray_pos = latest_pos.copy()
                                state = MissionState.TRAY_SPOTTED
                                state_timer = step
                                tray_spot_step = step
                                tray_spot_error = float(np.linalg.norm(latest_pos[:2] - data.xpos[tray_id][:2]))
                                print(f"  [+] SAM Spotted Green Tray at step {step}: ({target_tray_pos[0]:.3f}, {target_tray_pos[1]:.3f}) | Error: {tray_spot_error*100:.2f} cm")
                            else:
                                target_tray_pos = 0.6 * target_tray_pos + 0.4 * latest_pos
                                tray_spot_error = float(np.linalg.norm(target_tray_pos[:2] - data.xpos[tray_id][:2]))

        # Finite State Machine Execution
        if state == MissionState.INITIAL_SURVEY:
            cur_base_ctrl[2] += 0.018
            if step > 380:
                state = MissionState.SEARCH_BOX

        elif state == MissionState.SEARCH_BOX:
            if not current_path or waypoint_idx >= len(current_path) or step % 180 == 0:
                frontiers = slam.find_frontiers()
                best_f = slam.select_best_frontier(robot_x, robot_y, robot_yaw, frontiers)
                if best_f is not None:
                    current_path = slam.plan_path_astar((robot_x, robot_y), best_f["world_pos"])
                    waypoint_idx = 1 if len(current_path) > 1 else 0

            if current_path and waypoint_idx < len(current_path):
                target_wp = current_path[waypoint_idx]
                wp_dx = target_wp[0] - robot_x
                wp_dy = target_wp[1] - robot_y
                dist_to_wp = np.hypot(wp_dx, wp_dy)
                if dist_to_wp < 0.25:
                    waypoint_idx += 1
                else:
                    target_yaw = np.arctan2(wp_dy, wp_dx)
                    yaw_diff = (target_yaw - cur_base_ctrl[2] + np.pi) % (2.0 * np.pi) - np.pi
                    cur_base_ctrl[2] += np.clip(yaw_diff, -0.018, 0.018)
                    cur_base_ctrl[0] += 0.0035 * (wp_dx / dist_to_wp)
                    cur_base_ctrl[1] += 0.0035 * (wp_dy / dist_to_wp)

        elif state == MissionState.BOX_SPOTTED:
            if step - state_timer > 20:
                state = MissionState.APPROACH_BOX

        elif state == MissionState.APPROACH_BOX:
            tx, ty = target_box_pos[0], target_box_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx - standoff_dist
            target_standoff_y = ty
            target_heading = 0.0

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.40:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.35:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.022, 0.022)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.016, 0.016)
                v_step = min(0.0045, pos_err * 0.05)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.06 and abs(yaw_err) < 0.08:
                state = MissionState.ARM_APPROACH_BOX
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_bx = cos_y * dx_world + sin_y * dy_world
                local_by = -sin_y * dx_world + cos_y * dy_world

                q_approach, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.54]), home_mat)
                q_descend, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.375]), home_mat, q_approach)
                q_lift, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.58]), home_mat, q_descend)
                q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)

        elif state == MissionState.ARM_APPROACH_BOX:
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_retracted + s * q_approach
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_DESCEND_BOX
                t_state_start = step

        elif state == MissionState.ARM_DESCEND_BOX:
            tau = np.clip((step - t_state_start) / 240.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_approach + s * q_descend
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_GRASP_BOX
                t_state_start = step

        elif state == MissionState.ARM_GRASP_BOX:
            cur_arm_ctrl = q_descend
            cur_gripper_ctrl = 0.0
            if step - t_state_start > 240:
                state = MissionState.ARM_LIFT_BOX
                t_state_start = step

        elif state == MissionState.ARM_LIFT_BOX:
            tau = np.clip((step - t_state_start) / 280.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_descend + s * q_lift
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.TRANSIT_CARRY
                t_state_start = step

        elif state == MissionState.TRANSIT_CARRY:
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_lift + s * q_carry
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                detector.set_target_prompt("green tray")
                state = MissionState.SEARCH_TRAY
                state_timer = step

        elif state == MissionState.SEARCH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0

            if transit_idx < len(transit_waypoints):
                tx, ty, tyaw = transit_waypoints[transit_idx]
                dx = tx - robot_x
                dy = ty - robot_y
                dist = np.hypot(dx, dy)
                if dist < 0.30 and transit_idx < len(transit_waypoints) - 1:
                    transit_idx += 1
                elif dist < 0.15 and transit_idx == len(transit_waypoints) - 1:
                    transit_idx += 1
                else:
                    heading = np.arctan2(dy, dx) if dist > 0.35 else tyaw
                    yaw_err = (heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
                    cur_base_ctrl[2] += np.clip(yaw_err, -0.012, 0.012)
                    v_step = min(0.0048, dist * 0.05)
                    if dist > 0.01:
                        cur_base_ctrl[0] += v_step * (dx / dist)
                        cur_base_ctrl[1] += v_step * (dy / dist)
            else:
                cur_base_ctrl[2] += 0.010

        elif state == MissionState.TRAY_SPOTTED:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0
            if step - state_timer > 20:
                state = MissionState.APPROACH_TRAY

        elif state == MissionState.APPROACH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0
            tx, ty = target_tray_pos[0], target_tray_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx + standoff_dist
            target_standoff_y = ty
            target_heading = np.pi

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.40:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.35:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.008, 0.008)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.006, 0.006)
                v_step = min(0.0035, pos_err * 0.04)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.08 and abs(yaw_err) < 0.12:
                state = MissionState.ARM_HOVER_TRAY
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_tx = cos_y * dx_world + sin_y * dy_world
                local_ty = -sin_y * dx_world + cos_y * dy_world

                q_tray_hover, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.52]), home_mat)
                q_tray_lower, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.405]), home_mat, q_tray_hover)

        elif state == MissionState.ARM_HOVER_TRAY:
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_carry + s * q_tray_hover
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_LOWER_TRAY
                t_state_start = step

        elif state == MissionState.ARM_LOWER_TRAY:
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_hover + s * q_tray_lower
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_RELEASE_TRAY
                t_state_start = step

        elif state == MissionState.ARM_RELEASE_TRAY:
            cur_arm_ctrl = q_tray_lower
            cur_gripper_ctrl = 255.0
            if step - t_state_start > 180:
                state = MissionState.ARM_RETRACT
                t_state_start = step

        elif state == MissionState.ARM_RETRACT:
            tau = np.clip((step - t_state_start) / 200.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_lower + s * q_tray_hover
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.MISSION_SUCCESS
                state_timer = step

        # Physics step
        data.ctrl[0:7] = cur_arm_ctrl
        data.ctrl[7] = cur_gripper_ctrl
        data.ctrl[8] = cur_base_ctrl[0]
        data.ctrl[9] = cur_base_ctrl[1]
        data.ctrl[10] = cur_base_ctrl[2]
        mujoco.mj_step(model, data)

        # Video recording (at ~15 FPS, every 28 steps)
        if video_writer is not None and step % 28 == 0:
            r_chase.update_scene(data, camera="chase_cam")
            rgb_chase = r_chase.render()

            r_nav.update_scene(data, camera="nav_cam")
            rgb_nav_clean = r_nav.render()
            rgb_nav_hud = detector.render_overlay(rgb_nav_clean, detection)

            active_target = target_tray_pos if "tray" in detector.active_prompt else target_box_pos
            map_hud = slam.render_map_image(
                target_w=(active_target[0], active_target[1]) if active_target is not None else None
            )
            if map_hud.shape[0] != vh or map_hud.shape[1] != vw:
                map_hud = cv2.resize(map_hud, (vw, vh))

            panels = np.hstack([rgb_chase, rgb_nav_hud, map_hud])

            header = np.full((36, out_w, 3), (20, 22, 28), dtype=np.uint8)
            cv2.line(header, (0, 35), (out_w, 35), (60, 68, 80), 1)

            status_text = f"SCENE {ep_num}/{total_eps} | STATE: {state.name} | Steps: {step} | Prompt: '{detector.active_prompt}'"
            cv2.putText(header, status_text, (16, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (0, 220, 255), 1, cv2.LINE_AA)

            composite = np.vstack([header, panels])
            bgr_frame = cv2.cvtColor(composite, cv2.COLOR_RGB2BGR)
            video_writer.write(bgr_frame)

        if state == MissionState.MISSION_SUCCESS and step - state_timer > 60:
            break

        step += 1

    elapsed = time.time() - t0_ep
    final_block_pos = data.xpos[block_id].copy()
    final_tray_pos = data.xpos[tray_id].copy()
    placement_offset = float(np.linalg.norm(final_block_pos[:2] - final_tray_pos[:2]))
    is_success = bool(placement_offset < 0.10 and final_block_pos[2] < 0.45)

    result_status = "SUCCESS" if is_success else "FAILURE"
    print(f"  --> Episode {ep_num} Result: {result_status} | Steps: {step} ({elapsed:.1f}s)")
    print(f"      Final Block Pos: ({final_block_pos[0]:.3f}, {final_block_pos[1]:.3f}, {final_block_pos[2]:.3f})")
    print(f"      Final Tray Pos:  ({final_tray_pos[0]:.3f}, {final_tray_pos[1]:.3f}, {final_tray_pos[2]:.3f})")
    print(f"      Offset from Tray Center: {placement_offset * 100:.2f} cm")

    # Capture final keyframe image of the placed object
    r_chase.update_scene(data, camera="chase_cam")
    rgb_final = r_chase.render()
    final_img_path = f"scene_{ep_num}_final.png"
    cv2.imwrite(final_img_path, cv2.cvtColor(rgb_final, cv2.COLOR_RGB2BGR))

    return {
        "episode": ep_num,
        "seed": seed,
        "steps": step,
        "elapsed_sec": elapsed,
        "robot_spawn": (rx, ry, ryaw),
        "block_gt_initial": (gt_block_initial[0], gt_block_initial[1], gt_block_initial[2]),
        "tray_gt": (gt_tray_pos[0], gt_tray_pos[1], gt_tray_pos[2]),
        "block_spot_error_cm": (block_spot_error * 100.0) if block_spot_error is not None else -1.0,
        "tray_spot_error_cm": (tray_spot_error * 100.0) if tray_spot_error is not None else -1.0,
        "final_block_pos": (final_block_pos[0], final_block_pos[1], final_block_pos[2]),
        "final_offset_cm": placement_offset * 100.0,
        "success": is_success,
        "final_img_path": final_img_path,
    }


def evaluate_10_random_scenes(video_path: str = "evaluate_10_random_scenes.mp4", num_episodes: int = 10):
    print("\n" + "=" * 70)
    print("  AUTONOMOUS PICK-AND-PLACE EVALUATION: 10 RANDOM SCENES IN MUJOCO    ")
    print("=" * 70)

    xml_path = "search_arena.xml"
    if not os.path.exists(xml_path):
        raise FileNotFoundError(f"Model file '{xml_path}' not found.")

    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    # Disable sensor mast collision to avoid elbow blocking
    for name in ["sensor_mast", "nav_cam_housing", "nav_cam_lens"]:
        gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        if gid != -1:
            model.geom_contype[gid] = 0
            model.geom_conaffinity[gid] = 0

    # Initialize SAM foundation model detector once
    print("[*] Initializing OpenVocabularyTargetDetector with SAM ViT-B (shared across all episodes)...")
    detector = OpenVocabularyTargetDetector(initial_prompt="red box")

    vw, vh = 400, 300
    out_w, out_h = vw * 3, vh + 36
    video_writer = None
    if video_path:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        video_writer = cv2.VideoWriter(video_path, fourcc, 15.0, (out_w, out_h))
        print(f"[*] Recording 10-episode evaluation video to: {video_path}")

    results = []
    base_seed = 42

    t0_total = time.time()
    for ep in range(1, num_episodes + 1):
        seed = base_seed + ep * 17
        res = run_single_episode(
            ep_num=ep,
            total_eps=num_episodes,
            model=model,
            data=data,
            detector=detector,
            video_writer=video_writer,
            max_steps=4500,
            seed=seed,
        )
        results.append(res)

    if video_writer is not None:
        video_writer.release()
        print(f"\n[*] All episodes finished. Video saved cleanly to: {video_path}")

    total_time = time.time() - t0_total

    # Compile Evaluation Statistics
    successes = sum(1 for r in results if r["success"])
    success_rate = (successes / num_episodes) * 100.0
    avg_steps = np.mean([r["steps"] for r in results])
    avg_offset = np.mean([r["final_offset_cm"] for r in results])
    avg_block_err = np.mean([r["block_spot_error_cm"] for r in results if r["block_spot_error_cm"] >= 0])
    avg_tray_err = np.mean([r["tray_spot_error_cm"] for r in results if r["tray_spot_error_cm"] >= 0])

    print("\n" + "=" * 70)
    print("  10 RANDOM SCENES EVALUATION SUMMARY                                ")
    print("=" * 70)
    print(f"  Total Episodes Tested:    {num_episodes}")
    print(f"  Successful Deliveries:    {successes}/{num_episodes} ({success_rate:.1f}%)")
    print(f"  Average Placement Offset: {avg_offset:.2f} cm (Goal: < 10.0 cm)")
    print(f"  Average Box Optical Err:  {avg_block_err:.2f} cm")
    print(f"  Average Tray Optical Err: {avg_tray_err:.2f} cm")
    print(f"  Average Episode Steps:    {avg_steps:.0f} steps")
    print(f"  Total Evaluation Time:    {total_time:.1f} seconds")
    print("=" * 70)

    # Print Table
    print("\n| Episode | Seed | Spawn (X, Y) | Target Block | Spotted Error | Final Offset | Status |")
    print("|:---|:---|:---|:---|:---|:---|:---|")
    for r in results:
        status_str = "SUCCESS" if r["success"] else "FAIL"
        sp = r["robot_spawn"]
        bp = r["block_gt_initial"]
        print(
            f"| Scene {r['episode']:2d} | {r['seed']} | ({sp[0]:+.2f}, {sp[1]:+.2f}) | "
            f"({bp[0]:.2f}, {bp[1]:.2f}) | {r['block_spot_error_cm']:.2f} cm | "
            f"{r['final_offset_cm']:.2f} cm | {status_str} |"
        )
    print("\n")

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate 10 Random Scenes Pick and Place in MuJoCo")
    parser.add_argument("--episodes", type=int, default=10, help="Number of random scene trials")
    parser.add_argument("--video", type=str, default="evaluate_10_random_scenes.mp4", help="Video output path")
    args = parser.parse_args()

    evaluate_10_random_scenes(video_path=args.video, num_episodes=args.episodes)
