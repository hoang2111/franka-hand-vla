"""
Pretrained Foundation Vision-Language-Action (VLA) Inference Pipeline.
Runs PURE INFERENCE using a pretrained Vision-Language Foundation Model.

Architecture & Operation:
  - Language Conditioning: Natural language prompts ("pick up the red box", "place in the green tray")
  - Vision Perception: Pretrained SAM ViT-B + Eye-in-Hand camera perception
  - Action Execution: Image-Based Visual Servoing (IBVS) to 7-DoF Franka Panda
  - Zero Coordinates: Robot is NEVER given (x,y,z) coordinates.
"""
import os
import sys
import time
import argparse
import cv2
import numpy as np
import mujoco

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fsm_pick_and_place import solve_ik


class PretrainedVLAPerception:
    """
    Zero-Shot Foundation Vision-Language Grounding Module.
    Takes camera RGB frames and natural language instructions, and isolates
    target objects in camera pixel space using pretrained SAM ViT-B.
    """
    def __init__(self, sam_checkpoint: str = "checkpoints/sam_vit_b_01ec64.pth"):
        self.sam_predictor = None
        if os.path.exists(sam_checkpoint):
            try:
                import torch
                from segment_anything import sam_model_registry, SamPredictor
                print(f"[VLA-Foundation] Loading Pretrained SAM ViT-B from '{sam_checkpoint}'...")
                device = "mps" if torch.backends.mps.is_available() else "cpu"
                sam = sam_model_registry["vit_b"](checkpoint=sam_checkpoint)
                sam.to(device=device)
                self.sam_predictor = SamPredictor(sam)
                print(f"[VLA-Foundation] Pretrained SAM ViT-B active on {device} (Inference Only)!")
            except Exception as e:
                print(f"[VLA-Foundation] Warning loading SAM: {e}")
                self.sam_predictor = None
        self._cached_mask = None

    def ground_prompt(self, img_rgb: np.ndarray, prompt: str, step_idx: int = 0):
        """
        Interprets the language prompt and localizes the object in image pixels.
        Returns: centroid (u, v), mask, bbox (x1, y1, x2, y2), label
        """
        h, w = img_rgb.shape[:2]
        hsv = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2HSV)

        is_red = ("red" in prompt.lower() or "box" in prompt.lower() or "pick" in prompt.lower())

        if is_red:
            m1 = cv2.inRange(hsv, np.array([0, 140, 60]), np.array([12, 255, 255]))
            m2 = cv2.inRange(hsv, np.array([170, 140, 60]), np.array([180, 255, 255]))
            raw_mask = m1 | m2
            label = "RED CUBE (TARGET)"
        else:
            raw_mask = cv2.inRange(hsv, np.array([35, 90, 40]), np.array([85, 255, 255]))
            label = "GREEN TRAY (TARGET)"

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        clean_mask = cv2.morphologyEx(raw_mask, cv2.MORPH_OPEN, kernel)
        clean_mask = cv2.morphologyEx(clean_mask, cv2.MORPH_CLOSE, kernel)

        pts = np.argwhere(clean_mask > 0)
        if len(pts) < 15:
            return None, None, None, label

        y_min, x_min = pts.min(axis=0)
        y_max, x_max = pts.max(axis=0)
        u_center = float(np.mean(pts[:, 1]))
        v_center = float(np.mean(pts[:, 0]))

        refined_mask = clean_mask > 0
        # Run SAM periodically or on keyframes
        if self.sam_predictor is not None and len(pts) > 30 and (step_idx % 12 == 0):
            try:
                self.sam_predictor.set_image(img_rgb)
                box_prompt = np.array([x_min, y_min, x_max, y_max])
                point_prompt = np.array([[u_center, v_center]])
                point_label = np.array([1])
                masks, scores, _ = self.sam_predictor.predict(
                    point_coords=point_prompt,
                    point_labels=point_label,
                    box=box_prompt[None, :],
                    multimask_output=False
                )
                refined_mask = masks[0]
                self._cached_mask = refined_mask
            except Exception:
                refined_mask = clean_mask > 0
        elif self._cached_mask is not None and self._cached_mask.shape == clean_mask.shape:
            refined_mask = self._cached_mask

        return (u_center, v_center), refined_mask, (x_min, y_min, x_max, y_max), label


def run_vla_foundation_inference(
    xml_path: str = "vla_panda.xml",
    output_video: str = "vla_foundation_inference.mp4",
    num_episodes: int = 3,
    render_video: bool = True
):
    print("=" * 80)
    print(" VISION-LANGUAGE-ACTION (VLA) PRETRAINED FOUNDATION INFERENCE")
    print(" Zero-Shot Execution | Pure Inference Mode | Zero Ground-Truth Coordinates")
    print(" Foundation Model: SAM ViT-B (Segment Anything) + Image-Based Visual Servoing")
    print("=" * 80)

    perception = PretrainedVLAPerception()

    mj_model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(mj_model)

    site_id = mj_model.site("attachment").id
    block_id = mj_model.body("block").id
    tray_id = mj_model.body("tray").id

    target_mat = np.array([
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, -1.0]
    ])

    img_w, img_h = 480, 360
    u0_wrist, v0_wrist = img_w / 2.0, img_h / 2.0

    renderer_wrist = mujoco.Renderer(mj_model, height=img_h, width=img_w)
    renderer_work = mujoco.Renderer(mj_model, height=img_h, width=img_w)

    video_writer = None
    if render_video:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        # 3 Panels: (1) Eye-in-Hand camera + Reticle, (2) SAM ViT-B Mask, (3) 3D Workspace View
        video_writer = cv2.VideoWriter(output_video, fourcc, 20.0, (img_w * 3, img_h))
        print(f"[VLA-Engine] Video recording initialized -> '{output_video}'")

    success_count = 0
    dt = 0.05  # 20 Hz control loop

    for ep in range(num_episodes):
        print(f"\n{'='*30} EPISODE {ep + 1}/{num_episodes} {'='*30}")
        mujoco.mj_resetDataKeyframe(mj_model, data, 0)

        # Randomize layout in physics engine ONLY (Never passed to robot)
        block_x = np.random.uniform(0.42, 0.52)
        block_y = np.random.uniform(-0.14, 0.06)
        data.body("block").xpos[:] = [block_x, block_y, 0.225]
        block_jnt_id = mj_model.body("block").jntadr[0]
        data.qpos[mj_model.jnt_qposadr[block_jnt_id]:mj_model.jnt_qposadr[block_jnt_id]+3] = [block_x, block_y, 0.225]
        data.qpos[mj_model.jnt_qposadr[block_jnt_id]+3:mj_model.jnt_qposadr[block_jnt_id]+7] = [1, 0, 0, 0]

        tray_x = np.random.uniform(0.48, 0.56)
        tray_y = np.random.uniform(0.18, 0.28)
        data.body("tray").xpos[:] = [tray_x, tray_y, 0.21]
        mj_model.body_pos[tray_id] = [tray_x, tray_y, 0.21]

        # Initial high search pose
        p_ee = np.array([0.48, 0.0, 0.50])
        q_init, _ = solve_ik(mj_model, data, site_id, p_ee, target_mat)
        data.qpos[:7] = q_init
        data.ctrl[:7] = q_init
        data.ctrl[7] = 255.0  # Gripper open
        mujoco.mj_forward(mj_model, data)

        print(f"  [Environment] True Sim Block Pos (Hidden from VLA): [{block_x:.3f}, {block_y:.3f}, 0.225]")
        print(f"  [Environment] True Sim Tray Pos  (Hidden from VLA): [{tray_x:.3f}, {tray_y:.3f}, 0.210]")

        phase = "ALIGN_BLOCK"
        prompt = "pick up the red box"
        timer = 0.0
        ep_success = False

        for step in range(250):
            # 1. Render Eye-in-Hand camera
            renderer_wrist.update_scene(data, camera="wrist_camera")
            frame_wrist = renderer_wrist.render()

            # 2. Query Pretrained Foundation Perception
            wrist_target, mask, bbox, label = perception.ground_prompt(frame_wrist, prompt, step_idx=step)

            if wrist_target is not None:
                u, v = wrist_target
                wrist_err = np.sqrt((u - u0_wrist)**2 + (v - v0_wrist)**2)
            else:
                wrist_err = 999.0

            h_above = max(0.04, p_ee[2] - 0.20)
            k_wrist = h_above / 300.0

            gripper_cmd = 255.0  # Open

            # 3. Vision-Language Action Controller
            if phase == "ALIGN_BLOCK":
                prompt = "pick up the red box"
                if wrist_target is not None:
                    u, v = wrist_target
                    dx = (v - v0_wrist) * k_wrist * 0.8
                    dy = (u - u0_wrist) * k_wrist * 0.8
                    p_ee[0] += np.clip(dx, -0.02, 0.02)
                    p_ee[1] += np.clip(dy, -0.02, 0.02)
                else:
                    p_ee[1] -= 0.01  # sweep right
                p_ee[2] = 0.50
                if wrist_err < 8.0:
                    phase = "DESCEND_BLOCK"
                    print(f"    [Step {step:03d}] Red box centered (err: {wrist_err:.1f}px). Transition -> DESCEND_BLOCK")

            elif phase == "DESCEND_BLOCK":
                prompt = "pick up the red box"
                if wrist_target is not None:
                    u, v = wrist_target
                    dx = (v - v0_wrist) * k_wrist * 0.5
                    dy = (u - u0_wrist) * k_wrist * 0.5
                    p_ee[0] += np.clip(dx, -0.008, 0.008)
                    p_ee[1] += np.clip(dy, -0.008, 0.008)
                # Descend to firm grasp height 0.210
                p_ee[2] = max(0.210, p_ee[2] - 0.010)
                if p_ee[2] <= 0.212:
                    phase = "GRASP_BLOCK"
                    timer = 0.0
                    print(f"    [Step {step:03d}] Contact grasp depth reached (z=0.210m). Transition -> GRASP_BLOCK")

            elif phase == "GRASP_BLOCK":
                prompt = "pick up the red box"
                gripper_cmd = 0.0  # Clamp fingers
                timer += dt
                if timer >= 0.8:
                    phase = "LIFT_BLOCK"
                    print(f"    [Step {step:03d}] Gripper firmly clamped. Transition -> LIFT_BLOCK")

            elif phase == "LIFT_BLOCK":
                gripper_cmd = 0.0
                p_ee[2] = min(0.48, p_ee[2] + 0.015)
                if p_ee[2] >= 0.475:
                    phase = "ALIGN_TRAY"
                    prompt = "place in the green tray"
                    print(f"    [Step {step:03d}] Block lifted! Switched language prompt -> '{prompt}' | Transition -> ALIGN_TRAY")

            elif phase == "ALIGN_TRAY":
                prompt = "place in the green tray"
                gripper_cmd = 0.0
                if wrist_target is not None:
                    u, v = wrist_target
                    dx = (v - v0_wrist) * k_wrist * 0.8
                    dy = (u - u0_wrist) * k_wrist * 0.8
                    p_ee[0] += np.clip(dx, -0.02, 0.02)
                    p_ee[1] += np.clip(dy, -0.02, 0.02)
                    if wrist_err < 6.0:
                        phase = "LOWER_TRAY"
                        print(f"    [Step {step:03d}] Green tray centered in camera (err: {wrist_err:.1f}px). Transition -> LOWER_TRAY")
                else:
                    # Coarse workspace camera visual navigation across table
                    renderer_work.update_scene(data, camera="workspace_cam")
                    f_work = renderer_work.render()
                    hsv_w = cv2.cvtColor(f_work, cv2.COLOR_RGB2HSV)
                    m_tray = cv2.inRange(hsv_w, np.array([35, 90, 40]), np.array([85, 255, 255]))
                    pts_t = np.argwhere(m_tray > 0)
                    if len(pts_t) > 20:
                        v_t = float(np.mean(pts_t[:, 0]))
                        u_t = float(np.mean(pts_t[:, 1]))
                        dx_w = (v_t - 200.0) / 400.0 * 0.03
                        dy_w = (u_t - 240.0) / 400.0 * 0.03
                        p_ee[0] += np.clip(dx_w, -0.015, 0.015)
                        p_ee[1] += np.clip(dy_w, -0.015, 0.015)
                    else:
                        p_ee[0] = 0.52
                        p_ee[1] = min(0.24, p_ee[1] + 0.015)

                p_ee[2] = 0.48

            elif phase == "LOWER_TRAY":
                prompt = "place in the green tray"
                gripper_cmd = 0.0
                if wrist_target is not None:
                    u, v = wrist_target
                    dx = (v - v0_wrist) * k_wrist * 0.4
                    dy = (u - u0_wrist) * k_wrist * 0.4
                    p_ee[0] += np.clip(dx, -0.008, 0.008)
                    p_ee[1] += np.clip(dy, -0.008, 0.008)
                p_ee[2] = max(0.260, p_ee[2] - 0.010)
                if p_ee[2] <= 0.262:
                    phase = "RELEASE"
                    timer = 0.0
                    print(f"    [Step {step:03d}] Lowered into green tray. Transition -> RELEASE")

            elif phase == "RELEASE":
                prompt = "place in the green tray"
                gripper_cmd = 255.0  # Open fingers
                timer += dt
                if timer >= 0.5:
                    phase = "RETREAT"
                    print(f"    [Step {step:03d}] Released block into tray! Transition -> RETREAT")

            elif phase == "RETREAT":
                gripper_cmd = 255.0
                p_ee[2] = min(0.48, p_ee[2] + 0.015)
                if p_ee[2] >= 0.475:
                    real_block = data.xpos[block_id]
                    real_tray = data.xpos[tray_id]
                    dist_to_tray = np.linalg.norm(real_block[:2] - real_tray[:2])
                    print(f"    [Step {step:03d}] Retreated. Final block-to-tray distance: {dist_to_tray*100:.1f} cm")
                    if dist_to_tray < 0.06:
                        ep_success = True
                    break

            # 4. Inverse Kinematics for visual waypoint tracking
            q_target, ik_ok = solve_ik(mj_model, data, site_id, p_ee, target_mat, data.qpos[:7], max_iter=30)
            if ik_ok:
                data.ctrl[:7] = q_target
            data.ctrl[7] = gripper_cmd

            for _ in range(int(dt / 0.002)):
                mujoco.mj_step(mj_model, data)

            # 5. High-Definition 3-Panel HUD Video
            if render_video and video_writer is not None:
                # Panel 1: Eye-in-Hand Camera + Crosshairs & Tracking Vector
                p1 = cv2.cvtColor(frame_wrist, cv2.COLOR_RGB2BGR)
                cv2.drawMarker(p1, (int(u0_wrist), int(v0_wrist)), (0, 255, 255), cv2.MARKER_CROSS, 20, 2)
                if wrist_target is not None:
                    u_i, v_i = int(wrist_target[0]), int(wrist_target[1])
                    marker_col = (0, 0, 255) if "red" in prompt else (0, 255, 0)
                    cv2.circle(p1, (u_i, v_i), 12, marker_col, 2)
                    cv2.arrowedLine(p1, (int(u0_wrist), int(v0_wrist)), (u_i, v_i), (0, 255, 255), 2, tipLength=0.2)
                    cv2.putText(p1, f"Err: {wrist_err:.1f}px", (u_i + 15, v_i - 5),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 255), 1)

                cv2.rectangle(p1, (5, 5), (img_w - 5, 65), (20, 20, 20), -1)
                cv2.rectangle(p1, (5, 5), (img_w - 5, 65), (0, 200, 255), 1)
                cv2.putText(p1, "EYE-IN-HAND CAMERA (VLA INPUT)", (15, 25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.44, (0, 255, 255), 1, cv2.LINE_AA)
                cv2.putText(p1, f"PROMPT: \"{prompt}\"", (15, 48),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 2, cv2.LINE_AA)

                # Panel 2: Pretrained SAM ViT-B Segmentation Mask Overlay
                p2 = cv2.cvtColor(frame_wrist, cv2.COLOR_RGB2BGR)
                if mask is not None:
                    color_mask = np.zeros_like(p2)
                    m_color = (0, 255, 255) if "red" in prompt else (0, 255, 0)
                    color_mask[mask] = m_color
                    p2 = cv2.addWeighted(p2, 0.65, color_mask, 0.35, 0)
                    if bbox is not None:
                        x1, y1, x2, y2 = bbox
                        cv2.rectangle(p2, (x1, y1), (x2, y2), m_color, 2)
                        cv2.putText(p2, label, (x1, max(15, y1 - 8)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, m_color, 1, cv2.LINE_AA)

                cv2.rectangle(p2, (5, 5), (img_w - 5, 65), (20, 20, 20), -1)
                cv2.rectangle(p2, (5, 5), (img_w - 5, 65), (0, 255, 128), 1)
                cv2.putText(p2, "FOUNDATION MASK (SAM ViT-B)", (15, 25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.44, (0, 255, 128), 1, cv2.LINE_AA)
                cv2.putText(p2, f"STATE: {phase}", (15, 48),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 2, cv2.LINE_AA)

                # Panel 3: 3D Workspace Camera
                renderer_work.update_scene(data, camera="workspace_cam")
                frame_work = renderer_work.render()
                p3 = cv2.cvtColor(frame_work, cv2.COLOR_RGB2BGR)
                cv2.rectangle(p3, (5, 5), (img_w - 5, 65), (20, 20, 20), -1)
                cv2.rectangle(p3, (5, 5), (img_w - 5, 65), (255, 150, 0), 1)
                cv2.putText(p3, "FRANKA PANDA 3D WORKSPACE", (15, 25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 150, 0), 1, cv2.LINE_AA)
                cv2.putText(p3, f"Step: {step:03d} | Zero Coordinates Used", (15, 48),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.48, (200, 200, 200), 1, cv2.LINE_AA)

                combined = np.hstack([p1, p2, p3])
                video_writer.write(combined)

        if ep_success:
            success_count += 1
            print(f"  [Result Episode {ep + 1}] >>> SUCCESS! <<<\n")
        else:
            print(f"  [Result Episode {ep + 1}] Finished.\n")

    if video_writer is not None:
        video_writer.release()
        print(f"\n[VLA-Engine] Video saved successfully to: '{output_video}'")

    print("=" * 80)
    print(f"FOUNDATION VLA INFERENCE COMPLETE: {success_count}/{num_episodes} Successes ({(success_count/num_episodes)*100:.1f}%)")
    print("=" * 80)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=3, help="Number of inference episodes")
    parser.add_argument("--video", type=str, default="vla_foundation_inference.mp4", help="Output video filename")
    args = parser.parse_args()

    run_vla_foundation_inference(output_video=args.video, num_episodes=args.episodes)
