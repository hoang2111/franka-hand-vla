"""
Mobile Manipulator Eye-in-Hand Camera Tour & Exploration in MuJoCo.

Features:
  - An "Eye-in-Hand" camera mounted inside the Franka Panda gripper.
  - Autonomous exploration tour around the workshop map:
      1. DRIVE_TO_TABLE_1   : Drive across the floor to Table 1 (brown table).
      2. INSPECT_BLOCK      : Hand camera zooms in to inspect the red block.
      3. DESCEND_AND_GRASP  : Gripper clamps the block firmly.
      4. LIFT_BLOCK         : Arm raises block into the air.
      5. EXPLORE_MAP        : Robot cruises around the workshop floor, passing landmark crates,
                              while the arm pans to record a 360° panoramic view of the room.
      6. APPROACH_TRAY      : Robot navigates to Table 2 (blue table with green tray).
      7. INSPECT_TRAY       : Hand camera inspects the target green tray from above.
      8. RELEASE_BLOCK      : Gripper opens and safely deposits the block in the tray.
      9. RETURN_HOME        : Robot drives back to origin (0, 0) and parks.
  - Video Outputs:
      - 'hand_camera_view.mp4'               : Pure First-Person View (FPV) from the hand camera.
      - 'hand_camera_tour_side_by_side.mp4'  : Split-screen view (Tracking Camera + Hand Camera FPV with HUD).
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import mujoco.viewer
import numpy as np


class TourState(Enum):
    DRIVE_TO_TABLE_1 = auto()
    INSPECT_BLOCK = auto()
    DESCEND_AND_GRASP = auto()
    LIFT_BLOCK = auto()
    EXPLORE_MAP = auto()
    APPROACH_TRAY = auto()
    INSPECT_TRAY = auto()
    RELEASE_BLOCK = auto()
    RETURN_HOME = auto()
    DONE = auto()


def minimum_jerk_traj(q0: np.ndarray, q1: np.ndarray, tau: float) -> np.ndarray:
    """Computes smooth 5th-order minimum-jerk trajectory parameterization."""
    tau = np.clip(tau, 0.0, 1.0)
    s = 10.0 * (tau ** 3) - 15.0 * (tau ** 4) + 6.0 * (tau ** 5)
    return (1.0 - s) * q0 + s * q1


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """Solves inverse kinematics for the 7-DOF Panda arm on the mobile base."""
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq
        for j in range(7):
            d_ik.qpos[3 + j] = np.clip(
                d_ik.qpos[3 + j], model.jnt_range[3 + j, 0], model.jnt_range[3 + j, 1]
            )
        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


class HandCameraTourController:
    """FSM Controller coordinating mobile exploration, arm poses, and camera perspectives."""

    def __init__(self, model: mujoco.MjModel, data: mujoco.MjData):
        self.model = model
        self.data = data

        self.site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
        self.block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
        self.tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
        self.cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "hand_camera")

        mujoco.mj_resetDataKeyframe(model, data, 0)
        mujoco.mj_forward(model, data)

        self.q_home = data.qpos[3:10].copy()
        self.target_mat = data.site_xmat[self.site_id].reshape(3, 3).copy()

        # Arm IK Waypoints
        self.q_approach, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), self.target_mat)
        self.q_descend, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.395]), self.target_mat, self.q_approach)
        self.q_lift, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.56]), self.target_mat, self.q_descend)

        # Pan / Scan Arm Configurations for the Scenic Tour
        # Sweeping the arm joints so the hand camera pans across the horizon
        self.q_pan_left = np.array([0.6, -0.3, 0.2, -1.2, 0.4, 1.4, -0.4])
        self.q_pan_right = np.array([-0.6, -0.3, -0.2, -1.2, -0.4, 1.4, -0.4])

        # Mobile Base Waypoints [x, y, yaw]
        self.base_home = np.array([0.0, 0.0, 0.0])
        self.base_table1 = np.array([0.68, 0.0, 0.0])
        self.base_patrol_1 = np.array([0.40, 0.60, 1.10])    # mid-arena near yellow crate
        self.base_patrol_2 = np.array([-0.30, 0.50, 1.57])   # surveying west landmarks
        self.base_table2 = np.array([0.0, 0.78, 1.57079])    # parked at Table 2 facing green tray

        # Phase Durations (seconds)
        self.durations = {
            TourState.DRIVE_TO_TABLE_1: 2.5,
            TourState.INSPECT_BLOCK: 1.2,
            TourState.DESCEND_AND_GRASP: 1.5,
            TourState.LIFT_BLOCK: 1.0,
            TourState.EXPLORE_MAP: 4.5,
            TourState.APPROACH_TRAY: 2.0,
            TourState.INSPECT_TRAY: 1.0,
            TourState.RELEASE_BLOCK: 1.0,
            TourState.RETURN_HOME: 3.0,
            TourState.DONE: 1.0,
        }

        self.GRIPPER_OPEN = 255.0
        self.GRIPPER_CLOSE = 0.0

        # State tracking
        self.current_state = TourState.DRIVE_TO_TABLE_1
        self.state_start_time = 0.0
        self.state_arm_start = self.q_home.copy()
        self.state_base_start = self.base_home.copy()
        self.state_just_entered = True

    def update(self, sim_time: float) -> tuple[np.ndarray, float, np.ndarray, bool]:
        if self.state_just_entered:
            self.state_start_time = sim_time
            self.state_just_entered = False
            self._log_state_entry()

        time_in_state = sim_time - self.state_start_time
        duration = self.durations[self.current_state]
        tau = np.clip(time_in_state / duration, 0.0, 1.0)
        is_done = False

        if self.current_state == TourState.DRIVE_TO_TABLE_1:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_table1, tau)
            q_arm = self.q_home
            gripper = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(TourState.INSPECT_BLOCK, q_arm, self.base_table1)

        elif self.current_state == TourState.INSPECT_BLOCK:
            q_base = self.base_table1
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_approach, tau)
            gripper = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(TourState.DESCEND_AND_GRASP, self.q_approach, self.base_table1)

        elif self.current_state == TourState.DESCEND_AND_GRASP:
            q_base = self.base_table1
            # First half: descend; second half: close gripper
            if tau < 0.5:
                sub_tau = tau * 2.0
                q_arm = minimum_jerk_traj(self.state_arm_start, self.q_descend, sub_tau)
                gripper = self.GRIPPER_OPEN
            else:
                q_arm = self.q_descend
                gripper = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(TourState.LIFT_BLOCK, self.q_descend, self.base_table1)

        elif self.current_state == TourState.LIFT_BLOCK:
            q_base = self.base_table1
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_lift, tau)
            gripper = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(TourState.EXPLORE_MAP, self.q_lift, self.base_table1)

        elif self.current_state == TourState.EXPLORE_MAP:
            # Multi-segment scenic patrol: drive through arena while panning arm camera
            gripper = self.GRIPPER_CLOSE
            if tau < 0.5:
                # Segment A: curve through arena toward patrol_1; pan arm to the left
                sub_tau = tau * 2.0
                q_base = minimum_jerk_traj(self.base_table1, self.base_patrol_1, sub_tau)
                q_arm = minimum_jerk_traj(self.q_lift, self.q_pan_left, sub_tau)
            else:
                # Segment B: curve toward patrol_2; pan arm across to the right
                sub_tau = (tau - 0.5) * 2.0
                q_base = minimum_jerk_traj(self.base_patrol_1, self.base_patrol_2, sub_tau)
                q_arm = minimum_jerk_traj(self.q_pan_left, self.q_lift, sub_tau)

            if tau >= 1.0:
                self._transition(TourState.APPROACH_TRAY, self.q_lift, self.base_patrol_2)

        elif self.current_state == TourState.APPROACH_TRAY:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_table2, tau)
            q_arm = self.q_lift
            gripper = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(TourState.INSPECT_TRAY, self.q_lift, self.base_table2)

        elif self.current_state == TourState.INSPECT_TRAY:
            q_base = self.base_table2
            q_arm = self.q_lift
            gripper = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition(TourState.RELEASE_BLOCK, self.q_lift, self.base_table2)

        elif self.current_state == TourState.RELEASE_BLOCK:
            q_base = self.base_table2
            q_arm = self.q_lift
            gripper = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(TourState.RETURN_HOME, self.q_lift, self.base_table2)

        elif self.current_state == TourState.RETURN_HOME:
            q_base = minimum_jerk_traj(self.state_base_start, self.base_home, tau)
            q_arm = minimum_jerk_traj(self.state_arm_start, self.q_home, tau)
            gripper = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition(TourState.DONE, self.q_home, self.base_home)

        elif self.current_state == TourState.DONE:
            q_base = self.base_home
            q_arm = self.q_home
            gripper = self.GRIPPER_OPEN
            if tau >= 1.0:
                is_done = True

        return q_arm, gripper, q_base, is_done

    def _transition(self, next_state: TourState, arm_q: np.ndarray, base_q: np.ndarray):
        self.current_state = next_state
        self.state_arm_start = arm_q.copy()
        self.state_base_start = base_q.copy()
        self.state_just_entered = True

    def _log_state_entry(self):
        bpos = self.data.qpos[:3]
        blk = self.data.xpos[self.block_id]
        print(
            f"[{self.data.time:6.2f}s] >>> TOUR STATE: {self.current_state.name:<18} | "
            f"Base: [{bpos[0]:.2f}, {bpos[1]:.2f}, {bpos[2]:.2f} rad] | "
            f"Block: [{blk[0]:.2f}, {blk[1]:.2f}, {blk[2]:.2f}]"
        )


def run_hand_camera_tour(
    xml_path: str = "mobile_panda.xml",
    video_fpv: str = "hand_camera_view.mp4",
    video_combined: str = "hand_camera_tour_side_by_side.mp4",
    launch_gui: bool = False,
    render_video: bool = True,
):
    print(f"\nLoading Mobile Robot Scene from '{xml_path}'...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    controller = HandCameraTourController(model, data)
    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
    cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "hand_camera")

    if launch_gui:
        print("\nStarting Interactive 3D Viewer (Press Space to pause/resume, Esc to exit)...")
        try:
            with mujoco.viewer.launch_passive(model, data) as viewer:
                viewer.cam.distance = 3.5
                viewer.cam.elevation = -25.0
                viewer.cam.azimuth = 135.0
                viewer.cam.lookat = np.array([0.6, 0.6, 0.4])

                dt = model.opt.timestep
                while viewer.is_running():
                    t_start = time.perf_counter()
                    q_arm, grip, q_base, is_done = controller.update(data.time)

                    data.ctrl[:7] = q_arm
                    data.ctrl[7] = grip
                    data.ctrl[8:11] = q_base

                    mujoco.mj_step(model, data)
                    viewer.sync()

                    if is_done:
                        print("\nTour completed! Holding parked position...")
                        time.sleep(1.5)
                        break

                    elapsed = time.perf_counter() - t_start
                    if dt > elapsed:
                        time.sleep(dt - elapsed)
        except RuntimeError as exc:
            if "mjpython" in str(exc):
                print("\n[NOTE] On macOS, interactive GUI requires running with 'mjpython':")
                print("       .venv/bin/mjpython hand_camera_tour.py --viewer\n")
            else:
                raise exc

    else:
        # Offscreen Dual-Camera Rendering
        fps = 30
        sim_dt = model.opt.timestep
        steps_per_frame = int(round(1.0 / (fps * sim_dt)))

        width, height = 640, 480
        renderer_hand = mujoco.Renderer(model, height, width)
        renderer_track = mujoco.Renderer(model, height, width)

        cam_track = mujoco.MjvCamera()
        cam_track.distance = 3.5
        cam_track.elevation = -25.0
        cam_track.azimuth = 135.0
        cam_track.lookat = np.array([0.6, 0.6, 0.4])

        writer_fpv = None
        writer_combined = None

        if render_video:
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer_fpv = cv2.VideoWriter(video_fpv, fourcc, fps, (width, height))
            # Combined video is 1280 x 480 (side-by-side)
            writer_combined = cv2.VideoWriter(video_combined, fourcc, fps, (width * 2, height))
            print(f"Recording Hand Camera FPV to '{video_fpv}'...")
            print(f"Recording Split-Screen Tour to '{video_combined}'...")

        step_count = 0
        is_done = False
        t_wall_start = time.perf_counter()

        while not is_done and data.time < 22.0:
            q_arm, grip, q_base, is_done = controller.update(data.time)

            data.ctrl[:7] = q_arm
            data.ctrl[7] = grip
            data.ctrl[8:11] = q_base

            mujoco.mj_step(model, data)

            if render_video and (step_count % steps_per_frame == 0):
                # 1. Render Eye-in-Hand Camera view
                renderer_hand.update_scene(data, camera=cam_id)
                frame_hand_rgb = renderer_hand.render()
                frame_hand_bgr = cv2.cvtColor(frame_hand_rgb, cv2.COLOR_RGB2BGR)

                # 2. Render Third-Person Tracking view
                # Dynamically adjust tracking lookat to follow robot
                cam_track.lookat = np.array([data.qpos[0] * 0.5 + 0.3, data.qpos[1] * 0.5 + 0.3, 0.35])
                renderer_track.update_scene(data, camera=cam_track)
                frame_track_rgb = renderer_track.render()
                frame_track_bgr = cv2.cvtColor(frame_track_rgb, cv2.COLOR_RGB2BGR)

                # Write pure FPV frame
                writer_fpv.write(frame_hand_bgr)

                # Create HUD for combined view
                hud_track = frame_track_bgr.copy()
                hud_hand = frame_hand_bgr.copy()

                # Add labels
                cv2.putText(
                    hud_track,
                    "3RD PERSON TRACKING",
                    (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2,
                    cv2.LINE_AA,
                )
                cv2.putText(
                    hud_track,
                    f"PHASE: {controller.current_state.name}",
                    (20, 70),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 220, 255),
                    2,
                    cv2.LINE_AA,
                )
                cv2.putText(
                    hud_track,
                    f"BASE: X={data.qpos[0]:.2f}m, Y={data.qpos[1]:.2f}m",
                    (20, 100),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (200, 200, 200),
                    1,
                    cv2.LINE_AA,
                )

                cv2.putText(
                    hud_hand,
                    "EYE-IN-HAND CAMERA (FPV)",
                    (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                    cv2.LINE_AA,
                )
                cv2.putText(
                    hud_hand,
                    f"TIME: {data.time:.2f}s",
                    (20, 70),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 255, 255),
                    2,
                    cv2.LINE_AA,
                )

                # Horizontal stack for side-by-side
                split_frame = np.hstack([hud_track, hud_hand])
                writer_combined.write(split_frame)

            step_count += 1

        if render_video and writer_fpv is not None and writer_combined is not None:
            # Add trailing hold frames
            for _ in range(fps):
                writer_fpv.write(frame_hand_bgr)
                writer_combined.write(split_frame)
            writer_fpv.release()
            writer_combined.release()
            print(f"FPV video saved successfully to '{video_fpv}'")
            print(f"Combined tour video saved successfully to '{video_combined}'")

        wall_duration = time.perf_counter() - t_wall_start
        print(f"\nSimulation finished: {data.time:.2f}s simulated in {wall_duration:.2f}s wall time.")

    # Task Verification
    final_block = data.xpos[block_id]
    tray_pos = data.xpos[tray_id]
    xy_dist = np.linalg.norm(final_block[:2] - tray_pos[:2])

    print("\n================== MISSION VERIFICATION ==================")
    print(f"Final Block Position   : [{final_block[0]:.4f}, {final_block[1]:.4f}, {final_block[2]:.4f}]")
    print(f"Green Tray Center      : [{tray_pos[0]:.4f}, {tray_pos[1]:.4f}, {tray_pos[2]:.4f}]")
    print(f"Distance to Tray Center: {xy_dist * 100:.2f} cm (Tray radius: 6.0 cm)")

    if abs(final_block[0] - tray_pos[0]) < 0.055 and abs(final_block[1] - tray_pos[1]) < 0.055 and 0.40 <= final_block[2] <= 0.46:
        print("RESULT: SUCCESS! Autonomous tour completed, block delivered into tray, robot parked!")
    else:
        print("RESULT: FAILURE! Block not in tray.")
    print("==========================================================\n")


def main():
    parser = argparse.ArgumentParser(description="Franka Panda Mobile Eye-in-Hand Tour.")
    parser.add_argument("--scene", type=str, default="mobile_panda.xml", help="Path to XML model file.")
    parser.add_argument("--fpv", type=str, default="hand_camera_view.mp4", help="FPV video filename.")
    parser.add_argument("--combined", type=str, default="hand_camera_tour_side_by_side.mp4", help="Combined video filename.")
    parser.add_argument("--no-video", action="store_true", help="Disable video rendering.")
    parser.add_argument("--viewer", action="store_true", help="Launch interactive 3D GUI viewer.")
    args = parser.parse_args()

    run_hand_camera_tour(
        xml_path=args.scene,
        video_fpv=args.fpv,
        video_combined=args.combined,
        launch_gui=args.viewer,
        render_video=not args.no_video and not args.viewer,
    )


if __name__ == "__main__":
    main()
