"""
Occupancy Grid SLAM & Frontier-Based Autonomous Exploration Engine.
Maintains a 2D probability grid, performs 3D obstacle height raycasting,
and extracts unexplored frontiers to guide active visual search.
"""

from collections import deque
import cv2
import numpy as np


class OccupancyGridSLAM:
    def __init__(
        self,
        map_size_m: float = 6.0,
        resolution_m: float = 0.05,
        robot_radius_m: float = 0.28,
    ):
        self.map_size = map_size_m
        self.res = resolution_m
        self.grid_size = int(round(map_size_m / resolution_m))  # 120x120 for 6m @ 0.05m
        self.origin = -map_size_m / 2.0  # -3.0m
        self.robot_radius = robot_radius_m
        self.robot_radius_cells = int(np.ceil(robot_radius_m / resolution_m))

        # Cell States: -1 = UNKNOWN, 0 = FREE, 100 = OCCUPIED
        self.grid = np.full((self.grid_size, self.grid_size), -1, dtype=np.int8)

        # Odometry history
        self.trajectory: list[tuple[float, float]] = []

    def world_to_grid(self, wx: float, wy: float) -> tuple[int, int]:
        gx = int((wx - self.origin) / self.res)
        gy = int((wy - self.origin) / self.res)
        return gx, gy

    def grid_to_world(self, gx: int, gy: int) -> tuple[float, float]:
        wx = self.origin + (gx + 0.5) * self.res
        wy = self.origin + (gy + 0.5) * self.res
        return wx, wy

    def in_bounds(self, gx: int, gy: int) -> bool:
        return 0 <= gx < self.grid_size and 0 <= gy < self.grid_size

    def update_odometry(self, rx: float, ry: float):
        if not self.trajectory or np.hypot(rx - self.trajectory[-1][0], ry - self.trajectory[-1][1]) > 0.05:
            self.trajectory.append((rx, ry))
        # Clear footprint of the robot
        rgx, rgy = self.world_to_grid(rx, ry)
        for dx in range(-self.robot_radius_cells, self.robot_radius_cells + 1):
            for dy in range(-self.robot_radius_cells, self.robot_radius_cells + 1):
                if dx * dx + dy * dy <= self.robot_radius_cells * self.robot_radius_cells:
                    nx, ny = rgx + dx, rgy + dy
                    if self.in_bounds(nx, ny):
                        self.grid[ny, nx] = 0

    def integrate_depth_scan(
        self,
        depth_map: np.ndarray,
        robot_x: float,
        robot_y: float,
        robot_yaw: float,
        cam_pos: np.ndarray,
        cam_mat: np.ndarray,
        fovy_deg: float = 85.0,
        max_range: float = 3.2,
    ):
        """
        Projects 3D points from camera depth buffer to 2D occupancy grid.
        Filters out floor hits, raytraces free space, and marks obstacle walls.
        """
        self.update_odometry(robot_x, robot_y)
        h, w = depth_map.shape
        focal_y = (h / 2.0) / np.tan(np.deg2rad(fovy_deg / 2.0))
        focal_x = focal_y
        cx = w / 2.0
        cy = h / 2.0

        cols = np.linspace(0, w - 1, num=48, dtype=int)
        rows = np.linspace(20, h - 20, num=24, dtype=int)

        start_gx, start_gy = self.world_to_grid(robot_x, robot_y)

        for u in cols:
            min_dist = max_range
            is_obs = False

            for v in rows:
                z = depth_map[v, u]
                if z < 0.1 or z > max_range:
                    continue

                x_opt = (u - cx) * z / focal_x
                y_opt = (v - cy) * z / focal_y
                # Height above ground in world frame
                z_world = cam_pos[2] + x_opt * cam_mat[2, 0] - y_opt * cam_mat[2, 1] - z * cam_mat[2, 2]

                # Vertical obstacle (crate, pillar, partition, wall)
                if 0.05 < z_world < 1.0:
                    dist = np.hypot(x_opt, z)
                    if dist < min_dist:
                        min_dist = dist
                        is_obs = True

            # Direction of optical column in world ground plane
            dx_opt = (u - cx) * min_dist / focal_x
            ray_azimuth = -np.arctan2(dx_opt, min_dist)
            world_ray_angle = robot_yaw + ray_azimuth

            hit_wx = robot_x + min_dist * np.cos(world_ray_angle)
            hit_wy = robot_y + min_dist * np.sin(world_ray_angle)
            end_gx, end_gy = self.world_to_grid(hit_wx, hit_wy)

            # Raytrace cells between robot and hit
            line_cells = self.bresenham_line(start_gx, start_gy, end_gx, end_gy)
            for cgx, cgy in line_cells[:-1]:
                if self.in_bounds(cgx, cgy) and self.grid[cgy, cgx] != 100:
                    self.grid[cgy, cgx] = 0

            # If obstacle hit, mark endpoint as occupied
            if is_obs and line_cells:
                cgx, cgy = line_cells[-1]
                if self.in_bounds(cgx, cgy):
                    self.grid[cgy, cgx] = 100

    def bresenham_line(self, x0: int, y0: int, x1: int, y1: int) -> list[tuple[int, int]]:
        """Standard 2D Bresenham line algorithm."""
        points = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy

        cx, cy = x0, y0
        while True:
            points.append((cx, cy))
            if cx == x1 and cy == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                cx += sx
            if e2 < dx:
                err += dx
                cy += sy
        return points

    def get_inflated_costmap(self) -> np.ndarray:
        """Returns 2D grid with obstacles inflated by robot radius for collision-free A*."""
        occupied_mask = (self.grid == 100).astype(np.uint8)
        kernel_size = 2 * self.robot_radius_cells + 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        inflated = cv2.dilate(occupied_mask, kernel)
        return inflated

    def find_frontiers(self, min_cluster_size: int = 3) -> list[dict]:
        """
        Finds all frontier cells (free cells adjacent to unknown cells)
        and clusters them.
        """
        inflated_obstacles = self.get_inflated_costmap()
        frontier_mask = np.zeros_like(self.grid, dtype=np.uint8)

        # Check all cells that are FREE
        free_ys, free_xs = np.where(self.grid == 0)
        for fx, fy in zip(free_xs, free_ys):
            if inflated_obstacles[fy, fx] > 0:
                continue  # too close to obstacle

            # Check 8 neighbors for UNKNOWN (-1)
            is_frontier = False
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    if dx == 0 and dy == 0:
                        continue
                    nx, ny = fx + dx, fy + dy
                    if self.in_bounds(nx, ny) and self.grid[ny, nx] == -1:
                        is_frontier = True
                        break
                if is_frontier:
                    break
            if is_frontier:
                frontier_mask[fy, fx] = 1

        # Cluster adjacent frontier cells via connected components
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(frontier_mask)
        frontiers = []

        for label in range(1, num_labels):
            size = stats[label, cv2.CC_STAT_AREA]
            if size >= min_cluster_size:
                gcx, gcy = centroids[label]
                wcx, wcy = self.grid_to_world(int(round(gcx)), int(round(gcy)))
                frontiers.append({
                    "grid_pos": (int(round(gcx)), int(round(gcy))),
                    "world_pos": (wcx, wcy),
                    "size": int(size),
                })
        return frontiers

    def select_best_frontier(
        self,
        robot_x: float,
        robot_y: float,
        robot_yaw: float,
        frontiers: list[dict],
    ) -> dict | None:
        """
        Scores frontiers by size, distance, and heading alignment.
        """
        if not frontiers:
            return None

        best_score = -float("inf")
        best_frontier = None

        for f in frontiers:
            wx, wy = f["world_pos"]
            dist = np.hypot(wx - robot_x, wy - robot_y)
            if dist < 0.15:
                continue  # already at this frontier

            # Heading difference
            target_angle = np.arctan2(wy - robot_y, wx - robot_x)
            angle_diff = abs((target_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi)

            # Score: reward size, penalize distance and steep turns
            score = (f["size"] * 2.0) - (dist * 2.5) - (angle_diff * 1.0)
            if score > best_score:
                best_score = score
                best_frontier = f

        return best_frontier

    def plan_path_astar(
        self,
        start_w: tuple[float, float],
        goal_w: tuple[float, float],
    ) -> list[tuple[float, float]]:
        """
        Computes 2D collision-free path on the inflated costmap using A*.
        """
        import heapq

        start_g = self.world_to_grid(*start_w)
        goal_g = self.world_to_grid(*goal_w)

        if not self.in_bounds(*start_g) or not self.in_bounds(*goal_g):
            return [start_w, goal_w]

        inflated = self.get_inflated_costmap()

        # If goal is inside obstacle, find nearest free cell
        if inflated[goal_g[1], goal_g[0]] > 0:
            found = False
            for r in range(1, 10):
                for dx in range(-r, r + 1):
                    for dy in range(-r, r + 1):
                        ngx, ngy = goal_g[0] + dx, goal_g[1] + dy
                        if self.in_bounds(ngx, ngy) and inflated[ngy, ngx] == 0:
                            goal_g = (ngx, ngy)
                            found = True
                            break
                    if found:
                        break
                if found:
                    break

        open_set = []
        heapq.heappush(open_set, (0.0, start_g))
        came_from = {}
        g_score = {start_g: 0.0}

        def heuristic(a, b):
            return np.hypot(a[0] - b[0], a[1] - b[1])

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == goal_g or heuristic(current, goal_g) < 2.0:
                # Reconstruct path
                path_g = [current]
                while current in came_from:
                    current = came_from[current]
                    path_g.append(current)
                path_g.reverse()
                # Downsample and convert to world
                path_w = [self.grid_to_world(gx, gy) for gx, gy in path_g[::4]]
                if path_w[-1] != goal_w:
                    path_w.append(goal_w)
                return path_w

            for dx, dy in ((-1,0), (1,0), (0,-1), (0,1), (-1,-1), (-1,1), (1,-1), (1,1)):
                neighbor = (current[0] + dx, current[1] + dy)
                if not self.in_bounds(*neighbor):
                    continue
                if inflated[neighbor[1], neighbor[0]] > 0:
                    continue  # in obstacle

                step_cost = np.hypot(dx, dy)
                tentative_g = g_score[current] + step_cost

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score = tentative_g + heuristic(neighbor, goal_g)
                    heapq.heappush(open_set, (f_score, neighbor))

        # Fallback straight line
        return [start_w, goal_w]

    def render_map_image(self, target_w: tuple[float, float] | None = None) -> np.ndarray:
        """
        Renders a high-contrast HUD representation of the 2D SLAM map.
        - Free: Off-white
        - Unknown: Dark grey
        - Occupied: Jet black
        - Trajectory: Blue line
        - Frontiers: Cyan circles
        - Discovered Target: Pulsing Red star/circle
        """
        hud = np.full((self.grid_size, self.grid_size, 3), 45, dtype=np.uint8)
        hud[self.grid == 0] = [230, 235, 240]  # Light navigable floor
        hud[self.grid == 100] = [20, 20, 25]    # Obstacle boundary

        # Resize for crisp display
        display_size = 360
        hud_large = cv2.resize(hud, (display_size, display_size), interpolation=cv2.INTER_NEAREST)
        scale = display_size / float(self.grid_size)

        # Draw trajectory in electric blue
        if len(self.trajectory) >= 2:
            pts = []
            for tx, ty in self.trajectory:
                gx, gy = self.world_to_grid(tx, ty)
                px = int(round(gx * scale))
                py = int(round(gy * scale))
                pts.append([px, py])
            pts = np.array(pts, dtype=np.int32)
            cv2.polylines(hud_large, [pts], isClosed=False, color=(255, 120, 0), thickness=2)

        # Draw robot current pose
        if self.trajectory:
            rx, ry = self.trajectory[-1]
            gx, gy = self.world_to_grid(rx, ry)
            r_px = int(round(gx * scale))
            r_py = int(round(gy * scale))
            cv2.circle(hud_large, (r_px, r_py), 7, (0, 180, 255), -1)
            cv2.circle(hud_large, (r_px, r_py), 9, (0, 0, 0), 1)

        # Draw target if locked
        if target_w is not None:
            tgx, tgy = self.world_to_grid(*target_w)
            t_px = int(round(tgx * scale))
            t_py = int(round(tgy * scale))
            cv2.circle(hud_large, (t_px, t_py), 8, (0, 0, 255), -1)
            cv2.circle(hud_large, (t_px, t_py), 12, (0, 0, 255), 2)
            cv2.putText(
                hud_large, "TARGET", (t_px + 10, t_py + 4),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1, cv2.LINE_AA
            )

        # Flip vertically so +Y is up
        hud_large = cv2.flip(hud_large, 0)
        return hud_large
