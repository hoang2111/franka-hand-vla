"""
Multi-Stage Finite State Machine (FSM) Pick-and-Place Controller for Franka Panda in MuJoCo.

Operational Phases:
  1. APPROACH     : Move the end-effector above the red block (hover position).
  2. DESCEND      : Lower the gripper down onto the block.
  3. GRASP        : Close the gripper fingers to secure the block.
  4. LIFT         : Raise the end-effector up with the block.
  5. MOVE_TO_TRAY : Translate the end-effector horizontally to hover above the target green tray.
  6. RELEASE      : Open the gripper fingers to drop the block safely into the tray.
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import mujoco.viewer
import numpy as np


class FSMState(Enum):
    APPROACH = auto()
    DESCEND = auto()
    GRASP = auto()
    LIFT = auto()
    MOVE_TO_TRAY = auto()
    RELEASE = auto()
    DONE = auto()


def minimum_jerk_traj(q0: np.ndarray, q1: np.ndarray, tau: float) -> np.ndarray:
    """
    Computes a smooth minimum-jerk trajectory parameterization between q0 and q1.
    tau: normalized progress in [0, 1].
    s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5.
    Zero velocity and acceleration at start and finish.
    """
    tau = np.clip(tau, 0.0, 1.0)
    s = 10.0 * (tau ** 3) - 15.0 * (tau ** 4) + 6.0 * (tau ** 5)
    return (1.0 - s) * q0 + s * q1


def solve_ik(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    site_id: int,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """
    Solves inverse kinematics using Damped Least Squares (DLS) for the 7-DoF Panda arm.
    """
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    if q_init is not None:
        if len(q_init) == 7:
            d_ik.qpos[:7] = q_init
        else:
            d_ik.qpos[:] = q_init
    mujoco.mj_forward(model, d_ik)

    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        # Orientation error via cross product of frame vectors
        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[:7].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, :7], jacr[:, :7]])

        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[:7] += 0.5 * dq
        for j in range(7):
            d_ik.qpos[j] = np.clip(d_ik.qpos[j], model.jnt_range[j, 0], model.jnt_range[j, 1])
        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[:7].copy(), False


class FrankaFSMController:
    """
    Multi-stage Finite State Machine controller for pick-and-place task.
    """

    def __init__(self, model: mujoco.MjModel, data: mujoco.MjData):
        self.model = model
        self.data = data

        self.site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
        self.block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
        self.tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")

        # Initialize arm to home keyframe
        mujoco.mj_resetDataKeyframe(model, data, 0)
        mujoco.mj_forward(model, data)

        self.initial_q = data.qpos[:7].copy()
        self.target_mat = data.site_xmat[self.site_id].reshape(3, 3).copy()

        block_pos = data.xpos[self.block_id].copy()
        tray_pos = data.xpos[self.tray_id].copy()

        # Operational Phase Durations (seconds)
        self.phase_durations = {
            FSMState.APPROACH: 1.5,
            FSMState.DESCEND: 1.0,
            FSMState.GRASP: 0.8,
            FSMState.LIFT: 1.0,
            FSMState.MOVE_TO_TRAY: 1.5,
            FSMState.RELEASE: 0.8,
            FSMState.DONE: 0.5,
        }

        # Solve IK for key operational waypoints
        print("=== Computing IK Targets for Operational Phases ===")
        # 1. Approach: hover 14cm above block
        p_approach = np.array([block_pos[0], block_pos[1], 0.36])
        self.q_approach, ok1 = solve_ik(model, data, self.site_id, p_approach, self.target_mat, self.initial_q)
        print(f"  [APPROACH]     Target: {p_approach} | IK Converged: {ok1}")

        # 2. Descend: grasp height (fingertips aligned with block center)
        p_descend = np.array([block_pos[0], block_pos[1], 0.215])
        self.q_descend, ok2 = solve_ik(model, data, self.site_id, p_descend, self.target_mat, self.q_approach)
        print(f"  [DESCEND]      Target: {p_descend} | IK Converged: {ok2}")

        # 3. Lift: lift block back to 0.38m
        p_lift = np.array([block_pos[0], block_pos[1], 0.38])
        self.q_lift, ok3 = solve_ik(model, data, self.site_id, p_lift, self.target_mat, self.q_descend)
        print(f"  [LIFT]         Target: {p_lift} | IK Converged: {ok3}")

        # 4. Move to Tray: hover above tray center
        p_tray = np.array([tray_pos[0], tray_pos[1], 0.38])
        self.q_tray, ok4 = solve_ik(model, data, self.site_id, p_tray, self.target_mat, self.q_lift)
        print(f"  [MOVE_TO_TRAY] Target: {p_tray} | IK Converged: {ok4}")

        # Gripper values (actuator 8: ctrlrange 0 to 255)
        self.GRIPPER_OPEN = 255.0
        self.GRIPPER_CLOSE = 0.0

        # FSM tracking
        self.current_state = FSMState.APPROACH
        self.state_start_time = 0.0
        self.state_q_start = self.initial_q.copy()
        self.state_just_entered = True

    def update(self, sim_time: float) -> tuple[np.ndarray, float, bool]:
        """
        Updates the FSM state machine based on current simulation time.
        Returns:
          q_target (7-element array): joint position commands
          gripper_target (float): gripper command (0: closed, 255: open)
          is_done (bool): whether the entire sequence has finished
        """
        if self.state_just_entered:
            self.state_start_time = sim_time
            self.state_just_entered = False
            self._log_state_entry()

        time_in_state = sim_time - self.state_start_time
        duration = self.phase_durations[self.current_state]
        tau = np.clip(time_in_state / duration, 0.0, 1.0)

        is_done = False

        if self.current_state == FSMState.APPROACH:
            q_target = minimum_jerk_traj(self.state_q_start, self.q_approach, tau)
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition_to(FSMState.DESCEND, self.q_approach)

        elif self.current_state == FSMState.DESCEND:
            q_target = minimum_jerk_traj(self.state_q_start, self.q_descend, tau)
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition_to(FSMState.GRASP, self.q_descend)

        elif self.current_state == FSMState.GRASP:
            # Hold descend pose while closing gripper
            q_target = self.q_descend
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition_to(FSMState.LIFT, self.q_descend)

        elif self.current_state == FSMState.LIFT:
            q_target = minimum_jerk_traj(self.state_q_start, self.q_lift, tau)
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition_to(FSMState.MOVE_TO_TRAY, self.q_lift)

        elif self.current_state == FSMState.MOVE_TO_TRAY:
            q_target = minimum_jerk_traj(self.state_q_start, self.q_tray, tau)
            gripper_target = self.GRIPPER_CLOSE
            if tau >= 1.0:
                self._transition_to(FSMState.RELEASE, self.q_tray)

        elif self.current_state == FSMState.RELEASE:
            # Hold tray hover pose while opening gripper
            q_target = self.q_tray
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                self._transition_to(FSMState.DONE, self.q_tray)

        elif self.current_state == FSMState.DONE:
            q_target = self.q_tray
            gripper_target = self.GRIPPER_OPEN
            if tau >= 1.0:
                is_done = True

        return q_target, gripper_target, is_done

    def _transition_to(self, new_state: FSMState, q_current: np.ndarray):
        self.current_state = new_state
        self.state_q_start = q_current.copy()
        self.state_just_entered = True

    def _log_state_entry(self):
        ee_pos = self.data.site_xpos[self.site_id]
        block_pos = self.data.xpos[self.block_id]
        print(
            f"[{self.data.time:6.3f}s] >>> FSM TRANSITION -> {self.current_state.name:<12} | "
            f"EE pos: [{ee_pos[0]:.3f}, {ee_pos[1]:.3f}, {ee_pos[2]:.3f}] | "
            f"Block: [{block_pos[0]:.3f}, {block_pos[1]:.3f}, {block_pos[2]:.3f}]"
        )


def run_simulation(
    xml_path: str = "modified_panda.xml",
    render_video: bool = True,
    video_path: str = "pick_and_place.mp4",
    launch_gui: bool = False,
):
    print(f"\nLoading MuJoCo model from '{xml_path}'...")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    controller = FrankaFSMController(model, data)
    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")

    if launch_gui:
        print("\nStarting Interactive 3D Viewer (Press Space to pause/resume, Esc to exit)...")
        try:
            with mujoco.viewer.launch_passive(model, data) as viewer:
                # Setup camera view
                viewer.cam.distance = 1.3
                viewer.cam.elevation = -22.0
                viewer.cam.azimuth = 135.0
                viewer.cam.lookat = np.array([0.5, 0.1, 0.25])

                dt = model.opt.timestep
                while viewer.is_running():
                    step_start = time.perf_counter()

                    q_tgt, grip_tgt, is_done = controller.update(data.time)
                    data.ctrl[:7] = q_tgt
                    data.ctrl[7] = grip_tgt

                    mujoco.mj_step(model, data)
                    viewer.sync()

                    if is_done:
                        print("\nPick-and-place sequence complete! Holding final state...")
                        time.sleep(1.0)
                        break

                    elapsed = time.perf_counter() - step_start
                    if dt > elapsed:
                        time.sleep(dt - elapsed)
        except RuntimeError as exc:
            if "mjpython" in str(exc):
                print("\n[NOTE] On macOS, interactive GUI viewer requires running with 'mjpython':")
                print("       .venv/bin/mjpython fsm_pick_and_place.py --viewer\n")
            else:
                raise exc

    else:
        # Offscreen simulation / video recording
        renderer = None
        video_writer = None
        fps = 30
        sim_dt = model.opt.timestep
        steps_per_frame = int(round(1.0 / (fps * sim_dt)))

        if render_video:
            width, height = 640, 480
            renderer = mujoco.Renderer(model, height, width)
            cam = mujoco.MjvCamera()
            cam.distance = 1.3
            cam.elevation = -22.0
            cam.azimuth = 135.0
            cam.lookat = np.array([0.5, 0.1, 0.25])

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            video_writer = cv2.VideoWriter(video_path, fourcc, fps, (width, height))
            print(f"Rendering simulation video to '{video_path}' at {fps} FPS...")

        step_count = 0
        is_done = False
        start_wall_time = time.perf_counter()

        while not is_done and data.time < 12.0:
            q_tgt, grip_tgt, is_done = controller.update(data.time)
            data.ctrl[:7] = q_tgt
            data.ctrl[7] = grip_tgt

            mujoco.mj_step(model, data)

            if render_video and (step_count % steps_per_frame == 0):
                renderer.update_scene(data, camera=cam)
                pixels = renderer.render()
                frame_bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
                video_writer.write(frame_bgr)

            step_count += 1

        if render_video and video_writer is not None:
            # Write a few extra hold frames at the end
            for _ in range(fps):
                renderer.update_scene(data, camera=cam)
                pixels = renderer.render()
                frame_bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
                video_writer.write(frame_bgr)
            video_writer.release()
            print(f"Video saved successfully to '{video_path}'")

        wall_time = time.perf_counter() - start_wall_time
        print(f"\nSimulation finished: {data.time:.3f}s simulated in {wall_time:.2f}s wall time.")

    # Final Verification
    final_block_pos = data.xpos[block_id]
    tray_pos = data.xpos[tray_id]
    xy_dist = np.linalg.norm(final_block_pos[:2] - tray_pos[:2])

    print("\n================== TASK VERIFICATION ==================")
    print(f"Final Red Block Position : [{final_block_pos[0]:.4f}, {final_block_pos[1]:.4f}, {final_block_pos[2]:.4f}]")
    print(f"Green Tray Center        : [{tray_pos[0]:.4f}, {tray_pos[1]:.4f}, {tray_pos[2]:.4f}]")
    print(f"Horizontal Distance      : {xy_dist * 100:.2f} cm (Tray inner radius: 6.0 cm)")

    # Tray walls are within ±0.06m in X and Y, and block height should be above tray bottom (~0.22)
    in_tray_xy = abs(final_block_pos[0] - tray_pos[0]) < 0.055 and abs(final_block_pos[1] - tray_pos[1]) < 0.055
    in_tray_z = 0.22 <= final_block_pos[2] <= 0.26

    if in_tray_xy and in_tray_z:
        print("RESULT: SUCCESS! The red block is safely resting inside the green receptacle tray.")
    else:
        print("RESULT: FAILURE! The block is not inside the tray.")
    print("=======================================================\n")


def main():
    parser = argparse.ArgumentParser(description="Franka Panda Pick-and-Place FSM Simulation.")
    parser.add_argument("--scene", type=str, default="modified_panda.xml", help="Path to XML model file.")
    parser.add_argument("--video", type=str, default="pick_and_place.mp4", help="Video output filename.")
    parser.add_argument("--no-video", action="store_true", help="Disable video rendering.")
    parser.add_argument("--viewer", action="store_true", help="Launch interactive 3D GUI viewer.")
    args = parser.parse_args()

    run_simulation(
        xml_path=args.scene,
        render_video=not args.no_video and not args.viewer,
        video_path=args.video,
        launch_gui=args.viewer,
    )


if __name__ == "__main__":
    main()
