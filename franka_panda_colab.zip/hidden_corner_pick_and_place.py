"""
Hidden Corner Autonomous Pick-and-Place Demonstration in MuJoCo.

Scenario:
The payload red box is placed deep in the Northeast corner of the arena,
completely occluded from the starting position by central partition walls.
The robot must:
1. Execute an initial 360-degree survey at the spawn position (verifying the box is occluded).
2. Enter active corridor search and 2D SLAM exploration.
3. Navigate around partitions into the Northeast corner.
4. Discover the hidden red box using Meta's foundation model Segment Anything (SAM ViT-B).
5. Approach, grasp, and lift the block with dynamic 7-DOF arm inverse kinematics.
6. Carry the block across the arena to Quadrant 2.
7. Localize the green delivery tray with SAM, approach, and safely deposit the block.
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import numpy as np

from frontier_slam import OccupancyGridSLAM
from open_vocab_detector import OpenVocabularyTargetDetector


class MissionState(Enum):
    INITIAL_SURVEY = auto()
    SEARCH_BOX = auto()
    BOX_SPOTTED = auto()
    APPROACH_BOX = auto()
    ARM_APPROACH_BOX = auto()
    ARM_DESCEND_BOX = auto()
    ARM_GRASP_BOX = auto()
    ARM_LIFT_BOX = auto()
    TRANSIT_CARRY = auto()
    SEARCH_TRAY = auto()
    TRAY_SPOTTED = auto()
    APPROACH_TRAY = auto()
    ARM_HOVER_TRAY = auto()
    ARM_LOWER_TRAY = auto()
    ARM_RELEASE_TRAY = auto()
    ARM_RETRACT = auto()
    MISSION_SUCCESS = auto()


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """Solves inverse kinematics for the 7-DOF Panda arm relative to mobile base origin."""
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq

        for j in range(7):
            jnt_id = j + 3
            j_range = model.jnt_range[jnt_id]
            d_ik.qpos[3 + j] = np.clip(d_ik.qpos[3 + j], j_range[0], j_range[1])

        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


def run_hidden_corner_mission(
    video_path: str = "hidden_corner_pick_and_place.mp4",
    max_steps: int = 4500,
):
    print("\n" + "=" * 70)
    print("  HIDDEN CORNER AUTONOMOUS PICK-AND-PLACE DEMONSTRATION IN MUJOCO    ")
    print("=" * 70)

    xml_path = "search_arena.xml"
    if not os.path.exists(xml_path):
        raise FileNotFoundError(f"Model file '{xml_path}' not found.")

    with open(xml_path, "r") as f:
        xml_content = f.read()

    # Configure Northeast corner table, block, keyframe, and occlusion walls
    xml_content = xml_content.replace('pos="1.70 -1.90 0.19"', 'pos="2.20 2.20 0.19"')
    xml_content = xml_content.replace('pos="1.50 -1.90 0.405"', 'pos="2.00 2.20 0.405"')
    xml_content = xml_content.replace('1.50 -1.90 0.405', '2.00 2.20 0.405')
    xml_content = xml_content.replace('pos="0.5 1.5 0.30" size="0.6 0.06 0.30"', 'pos="0.8 1.5 0.35" size="0.8 0.06 0.35"')
    xml_content = xml_content.replace('pos="1.5 1.8 0.22"', 'pos="1.5 0.5 0.22"')

    model = mujoco.MjModel.from_xml_string(xml_content)
    data = mujoco.MjData(model)

    # Disable collision on sensor mast and cam housing to avoid elbow blocking
    for name in ["sensor_mast", "nav_cam_housing", "nav_cam_lens"]:
        gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        if gid != -1:
            model.geom_contype[gid] = 0
            model.geom_conaffinity[gid] = 0

    mujoco.mj_resetDataKeyframe(model, data, 0)

    # Side-tuck arm configuration: folds arm cleanly to the side to keep front camera completely unobstructed
    q_retracted = np.array([-0.90, -0.80, 0.0, -2.356, 0.0, 1.571, 0.785])
    data.qpos[3:10] = q_retracted
    data.qpos[0] = 0.0
    data.qpos[1] = 0.0
    data.qpos[2] = 1.5708  # facing North

    mujoco.mj_forward(model, data)

    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    tray_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "tray")
    cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "nav_cam")

    print(f"[*] Robot Spawn:          ({data.qpos[0]:.2f}, {data.qpos[1]:.2f}, yaw={data.qpos[2]:.2f} rad)")
    print(f"[*] Hidden Block Location: ({data.xpos[block_id][0]:.3f}, {data.xpos[block_id][1]:.3f}, {data.xpos[block_id][2]:.3f}) [Northeast Corner]")
    print(f"[*] Delivery Tray Target:  ({data.xpos[tray_id][0]:.3f}, {data.xpos[tray_id][1]:.3f}, {data.xpos[tray_id][2]:.3f}) [Quadrant 2]")
    print("[*] Occlusion Wall:        partition_north extended to [0.80, 1.50] size=[0.80, 0.06, 0.35]")
    print("[*] Status: Payload block is 100% occluded from the starting position!\n")

    # Initialize SLAM & SAM Target Detector
    slam = OccupancyGridSLAM(map_size_m=6.0, resolution_m=0.05, robot_radius_m=0.22)
    detector = OpenVocabularyTargetDetector(initial_prompt="red box")

    vw, vh = 400, 300
    r_nav = mujoco.Renderer(model, vh, vw)
    r_chase = mujoco.Renderer(model, vh, vw)
    out_w = vw * 3
    out_h = vh + 36

    video_writer = None
    if video_path:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        video_writer = cv2.VideoWriter(video_path, fourcc, 15.0, (out_w, out_h))
        print(f"[*] Recording demonstration video to: {video_path}")

    cur_arm_ctrl = q_retracted.copy()
    cur_base_ctrl = np.array([0.0, 0.0, 1.5708], dtype=float)
    cur_gripper_ctrl = 255.0

    home_mat = np.array([
        [9.81983171e-05, 9.99999995e-01, 1.51444362e-16],
        [9.99999995e-01, -9.81983171e-05, 3.15263149e-16],
        [3.15278019e-16, 1.51413403e-16, -1.00000000e+00]
    ])

    q_approach, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), home_mat)
    q_descend, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.375]), home_mat, q_approach)
    q_lift, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.58]), home_mat, q_descend)
    q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)
    q_tray_hover, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.52]), home_mat)
    q_tray_lower, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.405]), home_mat, q_tray_hover)

    state = MissionState.INITIAL_SURVEY
    state_timer = 0
    t_state_start = 0

    target_box_pos = None
    target_tray_pos = None

    # Search exploration waypoints leading into Northeast corridor
    search_waypoints = [
        (-0.45, 0.80, 1.5708),   # Northward along central passage (clears partition by 45 cm)
        (-0.45, 2.20, 1.5708),   # Clearing partition north
        (0.80, 2.20, 0.0),       # Turning East into Northeast corridor
        (1.48, 2.20, 0.0),       # Facing table in corner
    ]
    search_idx = 0

    # Return transit waypoints to deliver across the arena to Quadrant 2
    return_waypoints = [
        (0.40, 2.20, 3.14159),   # Moving Westward along North corridor
        (-0.50, 2.20, 3.14159),  # Clearing west edge of partition north (50 cm margin)
        (-0.50, 0.00, -1.5708),  # Moving Southward past partition through wide open area
        (-0.85, -0.80, 3.14159), # Arriving at delivery station facing West toward tray
    ]
    return_idx = 0

    step = 0
    perception_subsample = 12

    block_spot_step = None
    block_spot_error = None
    tray_spot_step = None
    tray_spot_error = None

    t0 = time.time()

    while step < max_steps:
        robot_x = data.qpos[0]
        robot_y = data.qpos[1]
        robot_yaw = data.qpos[2]

        detection = None
        if step % perception_subsample == 0:
            slam.update_odometry(robot_x, robot_y)

            r_nav.update_scene(data, camera="nav_cam")
            r_nav.enable_depth_rendering()
            depth = r_nav.render()
            r_nav.disable_depth_rendering()
            rgb_nav = r_nav.render()

            cam_pos = data.cam_xpos[cam_id]
            cam_mat = data.cam_xmat[cam_id].reshape(3, 3)

            slam.integrate_depth_scan(depth, robot_x, robot_y, robot_yaw, cam_pos, cam_mat, max_range=3.2)
            detection = detector.detect(rgb_nav, depth, model, data, cam_name="nav_cam")

            # Stage 1: Spot Box with SAM
            if state in [MissionState.INITIAL_SURVEY, MissionState.SEARCH_BOX, MissionState.APPROACH_BOX]:
                if detection is not None and "box" in detector.active_prompt:
                    latest_pos = detection["world_pos"]
                    if latest_pos[0] > 1.0:  # must be in Northeast pick area
                        if target_box_pos is None:
                            target_box_pos = latest_pos.copy()
                            state = MissionState.BOX_SPOTTED
                            state_timer = step
                            block_spot_step = step
                            block_spot_error = float(np.linalg.norm(latest_pos[:2] - data.xpos[block_id][:2]))
                            print(f"\n[+] SAM DISCOVERED HIDDEN RED BOX at step {step} (t={step*0.002:.1f}s)!")
                            print(f"    Estimated 3D Pos: ({latest_pos[0]:.3f}, {latest_pos[1]:.3f}, {latest_pos[2]:.3f})")
                            print(f"    Ground Truth Pos: ({data.xpos[block_id][0]:.3f}, {data.xpos[block_id][1]:.3f}, {data.xpos[block_id][2]:.3f})")
                            print(f"    Optical Error:    {block_spot_error*100:.2f} cm\n")
                        else:
                            target_box_pos = 0.7 * target_box_pos + 0.3 * latest_pos
                            block_spot_error = float(np.linalg.norm(target_box_pos[:2] - data.xpos[block_id][:2]))

            # Stage 2: Spot Tray with SAM
            elif state in [MissionState.SEARCH_TRAY, MissionState.APPROACH_TRAY]:
                if detection is not None and "tray" in detector.active_prompt:
                    if return_idx >= len(return_waypoints) or (robot_x < -0.6 and robot_y < -0.4):
                        latest_pos = detection["world_pos"]
                        if latest_pos[0] < -0.5:
                            if target_tray_pos is None:
                                target_tray_pos = latest_pos.copy()
                                state = MissionState.TRAY_SPOTTED
                                state_timer = step
                                tray_spot_step = step
                                tray_spot_error = float(np.linalg.norm(latest_pos[:2] - data.xpos[tray_id][:2]))
                                print(f"\n[+] SAM LOCALIZED GREEN TRAY at step {step} (t={step*0.002:.1f}s)!")
                                print(f"    Estimated 3D Pos: ({target_tray_pos[0]:.3f}, {target_tray_pos[1]:.3f}, {target_tray_pos[2]:.3f})")
                                print(f"    Ground Truth Pos: ({data.xpos[tray_id][0]:.3f}, {data.xpos[tray_id][1]:.3f}, {data.xpos[tray_id][2]:.3f})")
                                print(f"    Optical Error:    {tray_spot_error*100:.2f} cm\n")
                            else:
                                target_tray_pos = 0.6 * target_tray_pos + 0.4 * latest_pos
                                tray_spot_error = float(np.linalg.norm(target_tray_pos[:2] - data.xpos[tray_id][:2]))

        # Finite State Machine Execution
        if state == MissionState.INITIAL_SURVEY:
            cur_base_ctrl[2] += 0.018
            if step > 380:
                print("[*] Initial 360-degree survey complete: Red box was NOT spotted from spawn position.")
                print("[*] Transitioning to State: SEARCH_BOX (Active Corridor Exploration)")
                state = MissionState.SEARCH_BOX

        elif state == MissionState.SEARCH_BOX:
            if search_idx < len(search_waypoints):
                tx, ty, tyaw = search_waypoints[search_idx]
                dx = tx - robot_x
                dy = ty - robot_y
                dist = np.hypot(dx, dy)

                if dist < 0.25 and search_idx < len(search_waypoints) - 1:
                    search_idx += 1
                elif dist < 0.15 and search_idx == len(search_waypoints) - 1:
                    search_idx += 1
                else:
                    heading = np.arctan2(dy, dx) if dist > 0.30 else tyaw
                    yaw_err = (heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
                    cur_base_ctrl[2] += np.clip(yaw_err, -0.014, 0.014)
                    v_step = min(0.0048, dist * 0.05)
                    if dist > 0.01:
                        cur_base_ctrl[0] += v_step * (dx / dist)
                        cur_base_ctrl[1] += v_step * (dy / dist)
            else:
                cur_base_ctrl[2] += 0.010

        elif state == MissionState.BOX_SPOTTED:
            if step - state_timer > 20:
                state = MissionState.APPROACH_BOX
                print("[*] Transitioning to State: APPROACH_BOX")

        elif state == MissionState.APPROACH_BOX:
            tx, ty = target_box_pos[0], target_box_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx - standoff_dist
            target_standoff_y = ty
            target_heading = 0.0

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.35:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.30:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.018, 0.018)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.012, 0.012)
                v_step = min(0.0045, pos_err * 0.05)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.06 and abs(yaw_err) < 0.08:
                state = MissionState.ARM_APPROACH_BOX
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw
                print(f"[*] Reached Pick Standoff in Northeast Corner! Base locked at: ({robot_x:.3f}, {robot_y:.3f})")

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_bx = cos_y * dx_world + sin_y * dy_world
                local_by = -sin_y * dx_world + cos_y * dy_world

                q_approach, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.54]), home_mat)
                q_descend, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.375]), home_mat, q_approach)
                q_lift, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.58]), home_mat, q_descend)
                q_carry, _ = solve_arm_ik(model, np.array([0.38, 0.0, 0.60]), home_mat, q_lift)

        elif state == MissionState.ARM_APPROACH_BOX:
            tau = np.clip((step - t_state_start) / 200.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_retracted + s * q_approach
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_DESCEND_BOX
                t_state_start = step

        elif state == MissionState.ARM_DESCEND_BOX:
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_approach + s * q_descend
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.ARM_GRASP_BOX
                t_state_start = step

        elif state == MissionState.ARM_GRASP_BOX:
            cur_arm_ctrl = q_descend
            cur_gripper_ctrl = 0.0
            if step - t_state_start > 180:
                state = MissionState.ARM_LIFT_BOX
                t_state_start = step

        elif state == MissionState.ARM_LIFT_BOX:
            tau = np.clip((step - t_state_start) / 200.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_descend + s * q_lift
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.TRANSIT_CARRY
                t_state_start = step

        elif state == MissionState.TRANSIT_CARRY:
            tau = np.clip((step - t_state_start) / 150.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_lift + s * q_carry
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                detector.set_target_prompt("green tray")
                state = MissionState.SEARCH_TRAY
                state_timer = step
                print("[*] Block lifted! Transitioning to State: SEARCH_TRAY (Cross-Arena Delivery)")

        elif state == MissionState.SEARCH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0

            if return_idx < len(return_waypoints):
                tx, ty, tyaw = return_waypoints[return_idx]
                dx = tx - robot_x
                dy = ty - robot_y
                dist = np.hypot(dx, dy)
                if dist < 0.25 and return_idx < len(return_waypoints) - 1:
                    return_idx += 1
                elif dist < 0.12 and return_idx == len(return_waypoints) - 1:
                    return_idx += 1
                else:
                    heading = np.arctan2(dy, dx) if dist > 0.30 else tyaw
                    yaw_err = (heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
                    cur_base_ctrl[2] += np.clip(yaw_err, -0.010, 0.010)
                    v_step = min(0.0035, dist * 0.04)
                    if dist > 0.01:
                        cur_base_ctrl[0] += v_step * (dx / dist)
                        cur_base_ctrl[1] += v_step * (dy / dist)
            else:
                yaw_err = (np.pi - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
                cur_base_ctrl[2] += np.clip(yaw_err, -0.010, 0.010)

        elif state == MissionState.TRAY_SPOTTED:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0
            if step - state_timer > 20:
                state = MissionState.APPROACH_TRAY
                print("[*] Transitioning to State: APPROACH_TRAY")

        elif state == MissionState.APPROACH_TRAY:
            cur_arm_ctrl = q_carry
            cur_gripper_ctrl = 0.0
            tx, ty = target_tray_pos[0], target_tray_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx + standoff_dist
            target_standoff_y = ty
            target_heading = np.pi

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.25:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.20:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.010, 0.010)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.008, 0.008)
                v_step = min(0.0030, pos_err * 0.04)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            if pos_err < 0.06 and abs(yaw_err) < 0.10:
                state = MissionState.ARM_HOVER_TRAY
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw
                print(f"[*] Reached Tray Standoff! Base locked at: ({robot_x:.3f}, {robot_y:.3f})")

                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_tx = cos_y * dx_world + sin_y * dy_world
                local_ty = -sin_y * dx_world + cos_y * dy_world

                q_tray_hover, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.52]), home_mat)
                q_tray_lower, _ = solve_arm_ik(model, np.array([local_tx, local_ty, 0.405]), home_mat, q_tray_hover)

        elif state == MissionState.ARM_HOVER_TRAY:
            tau = np.clip((step - t_state_start) / 200.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_carry + s * q_tray_hover
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_LOWER_TRAY
                t_state_start = step

        elif state == MissionState.ARM_LOWER_TRAY:
            tau = np.clip((step - t_state_start) / 160.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_hover + s * q_tray_lower
            cur_gripper_ctrl = 0.0
            if tau >= 1.0:
                state = MissionState.ARM_RELEASE_TRAY
                t_state_start = step

        elif state == MissionState.ARM_RELEASE_TRAY:
            cur_arm_ctrl = q_tray_lower
            cur_gripper_ctrl = 255.0
            if step - t_state_start > 160:
                state = MissionState.ARM_RETRACT
                t_state_start = step

        elif state == MissionState.ARM_RETRACT:
            tau = np.clip((step - t_state_start) / 160.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_tray_lower + s * q_tray_hover
            cur_gripper_ctrl = 255.0
            if tau >= 1.0:
                state = MissionState.MISSION_SUCCESS
                state_timer = step

        # Apply physics controls
        data.ctrl[0:7] = cur_arm_ctrl
        data.ctrl[7] = cur_gripper_ctrl
        data.ctrl[8] = cur_base_ctrl[0]
        data.ctrl[9] = cur_base_ctrl[1]
        data.ctrl[10] = cur_base_ctrl[2]
        mujoco.mj_step(model, data)

        # Video recording (15 FPS, every 30 steps)
        if video_writer is not None and step % 30 == 0:
            r_chase.update_scene(data, camera="chase_cam")
            rgb_chase = r_chase.render()

            r_nav.update_scene(data, camera="nav_cam")
            rgb_nav_clean = r_nav.render()
            rgb_nav_hud = detector.render_overlay(rgb_nav_clean, detection)

            active_target = target_tray_pos if "tray" in detector.active_prompt else target_box_pos
            map_hud = slam.render_map_image(
                target_w=(active_target[0], active_target[1]) if active_target is not None else None
            )
            if map_hud.shape[0] != vh or map_hud.shape[1] != vw:
                map_hud = cv2.resize(map_hud, (vw, vh))

            panels = np.hstack([rgb_chase, rgb_nav_hud, map_hud])

            header = np.full((36, out_w, 3), (20, 22, 28), dtype=np.uint8)
            cv2.line(header, (0, 35), (out_w, 35), (60, 68, 80), 1)

            status_text = f"HIDDEN CORNER MISSION | STATE: {state.name} | Steps: {step} | Prompt: '{detector.active_prompt}'"
            cv2.putText(header, status_text, (16, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (0, 220, 255), 1, cv2.LINE_AA)

            composite = np.vstack([header, panels])
            bgr_frame = cv2.cvtColor(composite, cv2.COLOR_RGB2BGR)
            video_writer.write(bgr_frame)

        if state == MissionState.MISSION_SUCCESS and step - state_timer > 60:
            break

        step += 1

    if video_writer is not None:
        video_writer.release()
        print(f"\n[*] Video successfully saved to: {video_path}")

    elapsed = time.time() - t0
    final_block_pos = data.xpos[block_id].copy()
    final_tray_pos = data.xpos[tray_id].copy()
    placement_offset = float(np.linalg.norm(final_block_pos[:2] - final_tray_pos[:2]))
    is_success = bool(placement_offset < 0.10 and final_block_pos[2] < 0.45)

    result_status = "SUCCESS" if is_success else "FAILURE"
    print("\n" + "=" * 70)
    print("  MISSION SUMMARY: HIDDEN CORNER SEARCH & PICK-AND-PLACE")
    print("=" * 70)
    print(f"  Result:                   {result_status}")
    print(f"  Total Steps:              {step} steps ({elapsed:.1f} seconds)")
    b_err_str = f"{block_spot_error*100:.2f} cm" if block_spot_error is not None else "N/A"
    t_err_str = f"{tray_spot_error*100:.2f} cm" if tray_spot_error is not None else "N/A"
    print(f"  Red Box Discovered:       Step {block_spot_step} (Optical Err: {b_err_str})")
    print(f"  Green Tray Localized:     Step {tray_spot_step} (Optical Err: {t_err_str})")
    print(f"  Final Block Position:     ({final_block_pos[0]:.3f}, {final_block_pos[1]:.3f}, {final_block_pos[2]:.3f})")
    print(f"  Final Tray Position:      ({final_tray_pos[0]:.3f}, {final_tray_pos[1]:.3f}, {final_tray_pos[2]:.3f})")
    print(f"  Offset from Tray Center:  {placement_offset * 100:.2f} cm (Goal: < 10.0 cm)")
    print("=" * 70 + "\n")

    # Capture final high-resolution keyframe
    r_chase.update_scene(data, camera="chase_cam")
    rgb_final = r_chase.render()
    final_img_path = "hidden_corner_final.png"
    cv2.imwrite(final_img_path, cv2.cvtColor(rgb_final, cv2.COLOR_RGB2BGR))
    print(f"[*] Final keyframe image saved to: {final_img_path}")

    return {
        "success": is_success,
        "steps": step,
        "elapsed": elapsed,
        "block_spot_step": block_spot_step,
        "block_spot_error_cm": block_spot_error * 100 if block_spot_error else -1,
        "tray_spot_step": tray_spot_step,
        "tray_spot_error_cm": tray_spot_error * 100 if tray_spot_error else -1,
        "offset_cm": placement_offset * 100,
        "final_block_pos": final_block_pos,
        "video_path": video_path,
        "final_img_path": final_img_path,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Hidden Corner Pick and Place in MuJoCo")
    parser.add_argument("--video", type=str, default="hidden_corner_pick_and_place.mp4")
    parser.add_argument("--max_steps", type=int, default=4500)
    args = parser.parse_args()

    run_hidden_corner_mission(video_path=args.video, max_steps=args.max_steps)
