"""
Fast training script for VLA policy using collected expert data.
Runs on Apple Silicon MPS or CPU to produce a pre-trained checkpoint.
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from vla_model import VLAPolicy

def train():
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    print(f"Using device: {device}")

    # Load dataset
    print("Loading dataset from vla_data/...")
    images = np.load("vla_data/images.npy")
    lang_ids = np.load("vla_data/lang_ids.npy")
    actions = np.load("vla_data/actions.npy")
    ee_poses = np.load("vla_data/ee_poses.npy")

    N = len(images)
    print(f"Dataset loaded: {N} samples.")

    # Convert to PyTorch tensors
    # Permute images to (N, 3, 128, 128) and normalize to [0, 1]
    img_t = torch.from_numpy(images).permute(0, 3, 1, 2).float() / 255.0
    lang_t = torch.from_numpy(lang_ids).long()
    act_t = torch.from_numpy(actions).float()
    ee_t = torch.from_numpy(ee_poses).float()

    dataset = TensorDataset(img_t, lang_t, ee_t, act_t)
    dataloader = DataLoader(dataset, batch_size=128, shuffle=True)

    # Initialize VLA model
    model = VLAPolicy(embed_dim=128, num_heads=4, action_dim=4, proprio_dim=3).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    loss_fn = nn.SmoothL1Loss()

    print("Pre-training VLA policy for 20 epochs...")
    t0 = time.time()
    for epoch in range(1, 21):
        model.train()
        total_loss = 0.0
        for batch_img, batch_lang, batch_ee, batch_act in dataloader:
            batch_img = batch_img.to(device)
            batch_lang = batch_lang.to(device)
            batch_ee = batch_ee.to(device)
            batch_act = batch_act.to(device)

            pred_act = model(batch_img, batch_lang, batch_ee)
            loss = loss_fn(pred_act, batch_act)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(batch_img)

        avg_loss = total_loss / N
        if epoch % 5 == 0 or epoch == 1:
            print(f"Epoch {epoch:2d}/20 | Loss: {avg_loss:.5f} | Elapsed: {time.time()-t0:.1f}s")

    os.makedirs("checkpoints", exist_ok=True)
    checkpoint_path = "checkpoints/vla_policy.pt"
    torch.save(model.state_dict(), checkpoint_path)
    print(f"\nPre-trained VLA checkpoint saved to '{checkpoint_path}'! Ready for inference-only execution.")

if __name__ == "__main__":
    train()
