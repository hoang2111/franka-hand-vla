"""
Open-Vocabulary Natural Language Object Detection & 3D Optical Back-Projection.
Uses Meta's Segment Anything Model (SAM) to perform promptable, pixel-precise
foundation model segmentation on onboard RGB-D camera streams,
and back-projects segmented objects to metric 3D room coordinates.
"""

import os
import cv2
import mujoco
import numpy as np
import torch

try:
    from segment_anything import sam_model_registry, SamPredictor
except ImportError:
    sam_model_registry = None
    SamPredictor = None


class OpenVocabularyTargetDetector:
    """
    Open-vocabulary detector that parses natural language target prompts,
    segments corresponding candidates in the onboard RGB-D camera stream
    using Meta's Segment Anything Model (SAM ViT-B), and back-projects them
    to 3D world room coordinates.
    Operates strictly in RGB space with neural foundation models (zero HSV usage).
    """

    def __init__(
        self,
        initial_prompt: str = "red box",
        checkpoint_path: str = "checkpoints/sam_vit_b_01ec64.pth",
        model_type: str = "vit_b",
        device: str = None,
    ):
        self.active_prompt = initial_prompt.lower()
        self.min_pixel_count = 6

        # Device selection: CUDA -> Apple Silicon MPS -> CPU
        if device is None:
            if torch.cuda.is_available():
                self.device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = "mps"
            else:
                self.device = "cpu"
        else:
            self.device = device

        print(f"[*] Initializing OpenVocabularyTargetDetector with SAM ({model_type}) on device: {self.device}")

        # Resolve checkpoint path relative to workspace or root
        if not os.path.exists(checkpoint_path):
            base_dir = os.path.dirname(os.path.abspath(__file__))
            alt_path = os.path.join(base_dir, checkpoint_path)
            if os.path.exists(alt_path):
                checkpoint_path = alt_path
            else:
                raise FileNotFoundError(
                    f"SAM checkpoint not found at: {checkpoint_path}. "
                    "Expected 'checkpoints/sam_vit_b_01ec64.pth'."
                )

        if sam_model_registry is None:
            raise ImportError(
                "The 'segment_anything' library is not installed in the environment."
            )

        # Load SAM foundation model
        sam = sam_model_registry[model_type](checkpoint=checkpoint_path)
        sam.to(device=self.device)
        self.predictor = SamPredictor(sam)
        print("[*] SAM ViT-B model loaded successfully into OpenVocabularyTargetDetector.")

        # Cache for inference acceleration
        self.sam_stride = 5
        self._last_image_hash = None
        self._last_detection = None
        self._last_mask = None
        self._last_sam_score = 0.0
        self._detection_counter = 0

    def set_target_prompt(self, prompt: str):
        """Switches the active natural language detection target."""
        if prompt.lower() != self.active_prompt:
            self.active_prompt = prompt.lower()
            self._last_detection = None
            self._last_mask = None
            self._last_sam_score = 0.0
            print(f"[*] OpenVocabularyTargetDetector prompt switched to: '{self.active_prompt}'")

    def _extract_prompt_spatial_proposal(self, rgb: np.ndarray) -> tuple[np.ndarray | None, np.ndarray | None]:
        """
        Extracts spatial candidate bounding boxes and centroid points for the active
        language prompt directly in RGB color space (without HSV).
        """
        r = rgb[:, :, 0].astype(float)
        g = rgb[:, :, 1].astype(float)
        b = rgb[:, :, 2].astype(float)

        p = self.active_prompt

        # RGB semantic contrast rules via color opponency (strictly in RGB space, no HSV)
        if "red" in p or "box" in p or "block" in p:
            # High pure red contrast relative to green and blue (rejects orange/tan)
            cand_mask = (r - np.maximum(g, b)) > 140.0
        elif "green" in p or "tray" in p or "container" in p:
            # High pure green contrast relative to red and blue
            cand_mask = (g - np.maximum(r, b)) > 80.0
        elif "yellow" in p or "crate" in p:
            # High red and green, low blue
            cand_mask = (np.minimum(r, g) - b) > 80.0
        elif "cyan" in p or "blue" in p:
            # High blue or cyan contrast
            cand_mask = (b - np.maximum(r, g)) > 80.0
        else:
            # General high-contrast foreground proposal in RGB space
            intensity = (r + g + b) / 3.0
            cand_mask = intensity > 190.0

        # Morphological clean up only for larger blobs to avoid eroding distant targets
        ys_raw, xs_raw = np.where(cand_mask)
        if len(xs_raw) < self.min_pixel_count:
            return None

        if len(xs_raw) > 30:
            cand_uint8 = (cand_mask.astype(np.uint8)) * 255
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
            cleaned = cv2.morphologyEx(cand_uint8, cv2.MORPH_OPEN, kernel)
            ys, xs = np.where(cleaned > 0)
            if len(xs) < self.min_pixel_count:
                ys, xs = ys_raw, xs_raw
            else:
                cand_mask = cleaned > 0
        else:
            ys, xs = ys_raw, xs_raw

        x_min, x_max = int(np.min(xs)), int(np.max(xs))
        y_min, y_max = int(np.min(ys)), int(np.max(ys))
        u_c, v_c = int(np.median(xs)), int(np.median(ys))

        h, w = rgb.shape[:2]
        # Pad bounding box slightly to provide context for SAM
        box_prompt = np.array([
            max(0, x_min - 4),
            max(0, y_min - 4),
            min(w, x_max + 4),
            min(h, y_max + 4),
        ])
        point_prompt = np.array([[u_c, v_c]])

        return box_prompt, point_prompt, cand_mask

    def detect(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        model: mujoco.MjModel,
        data: mujoco.MjData,
        cam_name: str = "nav_cam",
    ) -> dict | None:
        """
        Scans RGB-D frame for the active text prompt target using SAM.
        If candidate is found, prompts SAM to predict the exact segmentation mask,
        samples metric depth across object pixels, and calculates 3D room coordinates
        via optical ray back-projection.
        """
        self._detection_counter += 1

        # 1. Extract spatial candidate prompt in RGB space
        proposal = self._extract_prompt_spatial_proposal(rgb)
        if proposal is None:
            return None
        box_prompt, point_prompt, cand_mask = proposal

        # 2. Compute SAM image embeddings and predict segmentation mask
        need_sam_refresh = (
            self._last_detection is None
            or self._last_mask is None
            or (self._detection_counter % self.sam_stride == 0)
        )

        if need_sam_refresh:
            self.predictor.set_image(rgb)
            masks, scores, _ = self.predictor.predict(
                point_coords=point_prompt,
                point_labels=np.array([1]),
                box=box_prompt[None, :],
                multimask_output=False,
            )
            best_mask = masks[0]
            sam_score = float(scores[0])
            self._last_mask = best_mask
            self._last_sam_score = sam_score
        else:
            best_mask = cand_mask
            sam_score = self._last_sam_score

        # 3. Calculate 2D centroid and tight bounding box from current frame
        if best_mask is not None and np.any(best_mask):
            ys, xs = np.where(best_mask > 0)
            pixel_count = len(xs)
            if pixel_count < self.min_pixel_count:
                return None
            x_min, x_max = int(np.min(xs)), int(np.max(xs))
            y_min, y_max = int(np.min(ys)), int(np.max(ys))
            u_center = float(np.median(xs))
            v_center = float(np.median(ys))
            mask_depths = depth[best_mask]
        else:
            return None

        # 4. Query metric depth directly on target pixels
        valid_depths = mask_depths[~np.isnan(mask_depths) & (mask_depths > 0.1)]
        if len(valid_depths) == 0:
            return None
        z_metric = float(np.median(valid_depths))

        # Reject out-of-range sensor readings
        if z_metric > 4.5 or z_metric < 0.15:
            return None

        # 5. Optical 3D Back-Projection from Camera Frame to World Room Coordinates
        cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, cam_name)
        h, w = depth.shape
        fovy = model.cam_fovy[cam_id]
        fy = (h / 2.0) / np.tan(np.deg2rad(fovy / 2.0))
        fx = fy
        cx = w / 2.0
        cy = h / 2.0

        x_opt = (u_center - cx) * z_metric / fx
        y_opt = (v_center - cy) * z_metric / fy
        z_opt = z_metric

        cam_pos = data.cam_xpos[cam_id]
        cam_mat = data.cam_xmat[cam_id].reshape(3, 3)

        # MuJoCo camera convention: optical X = col 0, optical Y = -col 1, optical Z = -col 2
        p_world = cam_pos + x_opt * cam_mat[:, 0] - y_opt * cam_mat[:, 1] - z_opt * cam_mat[:, 2]

        detection = {
            "detected": True,
            "prompt": self.active_prompt,
            "pixel_center": (u_center, v_center),
            "bbox": (x_min, y_min, x_max, y_max),
            "pixel_count": pixel_count,
            "depth_m": z_metric,
            "world_pos": p_world,
            "confidence": sam_score,
            "mask": best_mask,
        }

        self._last_detection = detection
        return detection

    def render_overlay(self, rgb: np.ndarray, detection: dict | None) -> np.ndarray:
        """
        Draws high-visibility targeting HUD on RGB camera frames with prompt info,
        SAM translucent mask segmentation, and target bounding box crosshairs.
        """
        annotated = rgb.copy()
        h, w = annotated.shape[:2]

        # Draw HUD banner showing active language prompt and SAM model
        prompt_str = f"PROMPT: '{self.active_prompt.upper()}' | SAM ViT-B"
        cv2.rectangle(annotated, (5, 5), (w - 5, 28), (20, 25, 30), -1)
        cv2.putText(
            annotated,
            prompt_str,
            (10, 22),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.42,
            (0, 230, 255),
            1,
            cv2.LINE_AA,
        )

        if detection is not None and detection.get("detected", False):
            x0, y0, x1, y1 = detection["bbox"]
            uc, vc = int(round(detection["pixel_center"][0])), int(round(detection["pixel_center"][1]))
            dist_m = detection["depth_m"]
            conf = detection["confidence"]
            mask = detection.get("mask", None)

            # Choose high-visibility HUD colors
            is_tray = "tray" in self.active_prompt
            box_color = (0, 240, 60) if is_tray else (240, 50, 50)
            overlay_color = (30, 220, 100) if is_tray else (255, 60, 60)

            # Draw translucent SAM segmentation mask if present
            if mask is not None:
                color_mask = np.zeros_like(annotated)
                color_mask[mask] = overlay_color
                blended = cv2.addWeighted(annotated, 0.55, color_mask, 0.45, 0)
                annotated[mask] = blended[mask]

                # Draw contour boundary around SAM mask
                mask_uint8 = (mask.astype(np.uint8)) * 255
                contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(annotated, contours, -1, box_color, 2)

            # Draw 2D bounding box
            cv2.rectangle(annotated, (x0, y0), (x1, y1), box_color, 2)

            # Draw target crosshairs
            cv2.drawMarker(annotated, (uc, vc), box_color, cv2.MARKER_CROSS, 14, 1, cv2.LINE_AA)

            # Target telemetry text: distance and SAM IoU confidence
            label = f"{dist_m:.2f}m | SAM: {conf*100:.0f}%"
            cv2.putText(
                annotated,
                label,
                (x0, max(12, y0 - 6)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.38,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )

        return annotated
