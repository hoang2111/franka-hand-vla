"""
ROS 2 Camera Publisher + SAM Segmentation Subscriber — pipeline runner.

Starts both nodes in one process and spins them until the camera stream ends:
  camera_publisher  --(/camera/image_raw, sensor_msgs/Image)-->  sam_segmenter
The subscriber segments the red box with SAM and writes an annotated video.

Usage:
  .venv/bin/python3 run_sam_ros2_pipeline.py                      # live MuJoCo hand camera
  .venv/bin/python3 run_sam_ros2_pipeline.py --source hand_camera_view.mp4
  .venv/bin/python3 run_sam_ros2_pipeline.py --camera hand_camera --stride 2
"""

import argparse
import os
import subprocess
import sys
import time

import cv2
import torch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.join(BASE_DIR, "ros2_vision")
if PKG_DIR not in sys.path:
    sys.path.insert(0, PKG_DIR)

from ros2_vision.camera_publisher import CameraPublisher
from ros2_vision.sam_segmenter import SAMSegmentationSubscriber
from ros2_vision.ros2_compat import ros2_init, ros2_shutdown, ros2_spin_once, HAS_REAL_ROS2


def main():
    p = argparse.ArgumentParser(description="ROS 2 camera publisher + SAM red-box segmentation.")
    p.add_argument("--source", default="sim", help="'sim' for live MuJoCo camera, or a video file path")
    p.add_argument("--camera", default="hand_camera_down", help="MuJoCo camera name (sim mode)")
    p.add_argument("--checkpoint", default="checkpoints/sam_vit_b_01ec64.pth")
    p.add_argument("--output", default="sam_segmented_red_box.mp4")
    p.add_argument("--stride", type=int, default=2, help="Publish every Nth camera frame")
    p.add_argument("--fps", type=float, default=30.0, help="Camera frame rate")
    args = p.parse_args()

    out_fps = args.fps / max(1, args.stride)
    temp_video = "temp_raw_" + args.output
    device = "MPS" if torch.backends.mps.is_available() else ("CUDA" if torch.cuda.is_available() else "CPU")
    print("=" * 66)
    print(" ROS 2 Eye-in-Hand Vision Pipeline: camera_publisher -> sam_segmenter")
    print("=" * 66)
    print(f" ROS 2 backend : {'rclpy' if HAS_REAL_ROS2 else 'in-process fallback (rclpy not installed)'}")
    print(f" Source        : {args.source}" + (f" (camera '{args.camera}')" if args.source == "sim" else ""))
    print(f" SAM device    : {device}   | output: {args.output} @ {out_fps:.1f} FPS")
    print("=" * 66)

    ros2_init()
    subscriber = SAMSegmentationSubscriber(
        checkpoint_path=args.checkpoint,
        output_video_path=temp_video,
        topic_name="/camera/image_raw",
        output_fps=out_fps,
    )
    publisher = CameraPublisher(
        source=args.source,
        topic_name="/camera/image_raw",
        fps=args.fps,
        camera_name=args.camera,
        xml_path=os.path.join(BASE_DIR, "mobile_panda.xml"),
        stride=args.stride,
    )

    t0 = time.time()
    try:
        if HAS_REAL_ROS2:
            import rclpy
            from rclpy.executors import SingleThreadedExecutor
            ex = SingleThreadedExecutor()
            ex.add_node(publisher)
            ex.add_node(subscriber)
            while publisher.is_active:
                ex.spin_once(timeout_sec=0.05)
            # drain any frames still queued for the subscriber
            for _ in range(20):
                ex.spin_once(timeout_sec=0.05)
        else:
            # Fallback bus delivers each published message to the subscriber
            # callback synchronously, so spinning the publisher drives both.
            while publisher.is_active:
                ros2_spin_once(publisher, timeout_sec=0.0)
    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        publisher.release()
        subscriber.release()
        publisher.destroy_node()
        subscriber.destroy_node()
        ros2_shutdown()

    elapsed = time.time() - t0
    print(f"\nPublished {publisher.frame_count} frames | SAM-segmented {subscriber.segmented_count} "
          f"| {elapsed:.0f}s total")

    # Transcode to H.264 for broad player compatibility
    if os.path.exists(temp_video):
        res = subprocess.run(
            ["ffmpeg", "-y", "-i", temp_video, "-c:v", "libx264", "-pix_fmt", "yuv420p", args.output],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if res.returncode == 0:
            os.remove(temp_video)
        else:
            os.replace(temp_video, args.output)
        print(f"Video: {args.output} ({os.path.getsize(args.output):,} bytes)")


if __name__ == "__main__":
    main()
