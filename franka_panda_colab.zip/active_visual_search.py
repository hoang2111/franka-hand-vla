"""
Active Visual Search (ObjectNav) Autonomous Mobile Manipulator Pipeline.
Combines 2D Occupancy Grid SLAM, Frontier Exploration, Semantic Vision Detection,
Depth 3D Optical Back-Projection, and Smooth Mobile Arm Manipulation.
"""

import argparse
from enum import Enum, auto
import os
import sys
import time
import cv2
import mujoco
import numpy as np

from frontier_slam import OccupancyGridSLAM
from semantic_detector import SemanticTargetDetector


class SearchState(Enum):
    INITIAL_SURVEY = auto()
    EXPLORE = auto()
    TARGET_SPOTTED = auto()
    APPROACH = auto()
    ARM_APPROACH = auto()
    ARM_DESCEND = auto()
    ARM_GRASP = auto()
    ARM_LIFT = auto()
    MISSION_SUCCESS = auto()


def solve_arm_ik(
    model: mujoco.MjModel,
    target_pos: np.ndarray,
    target_mat: np.ndarray,
    q_init: np.ndarray = None,
    max_iter: int = 500,
    tol: float = 1e-4,
) -> tuple[np.ndarray, bool]:
    """Solves inverse kinematics for the 7-DOF Panda arm on the mobile base."""
    d_ik = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, d_ik, 0)
    d_ik.qpos[:3] = 0.0

    q_home = np.array([0.0, 0.0, 0.0, -1.57079, 0.0, 1.57079, -0.7853])
    if q_init is not None:
        d_ik.qpos[3:10] = q_init
    else:
        d_ik.qpos[3:10] = q_home
    mujoco.mj_forward(model, d_ik)

    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")
    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))

    for _ in range(max_iter):
        pos_err = target_pos - d_ik.site_xpos[site_id]
        cur_mat = d_ik.site_xmat[site_id].reshape(3, 3)

        rot_err = 0.5 * (
            np.cross(cur_mat[:, 0], target_mat[:, 0])
            + np.cross(cur_mat[:, 1], target_mat[:, 1])
            + np.cross(cur_mat[:, 2], target_mat[:, 2])
        )

        err = np.concatenate([pos_err, rot_err])
        if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol:
            return d_ik.qpos[3:10].copy(), True

        mujoco.mj_jacSite(model, d_ik, jacp, jacr, site_id)
        J = np.vstack([jacp[:, 3:10], jacr[:, 3:10]])
        damping = 1e-4 * np.eye(6)
        dq = J.T @ np.linalg.solve(J @ J.T + damping, err)

        d_ik.qpos[3:10] += 0.5 * dq
        for j in range(7):
            d_ik.qpos[3 + j] = np.clip(
                d_ik.qpos[3 + j], model.jnt_range[3 + j, 0], model.jnt_range[3 + j, 1]
            )
        mujoco.mj_forward(model, d_ik)

    return d_ik.qpos[3:10].copy(), False


def run_active_visual_search(
    video_path: str = "objectnav_search_demo.mp4",
    max_steps: int = 3500,
    show_viewer: bool = False,
):
    print("=================================================================")
    print("  ACTIVE VISUAL SEARCH (OBJECTNAV) WITH FRONTIER SLAM & VISION   ")
    print("=================================================================")

    xml_path = os.path.join(os.path.dirname(__file__), "search_arena.xml")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, data, 0)
    mujoco.mj_forward(model, data)

    block_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "block")
    initial_block_pos = data.xpos[block_id].copy()

    print(f"[*] Environment Initialized.")
    print(f"[*] Payload Box Location (Hidden): ({initial_block_pos[0]:.2f}, {initial_block_pos[1]:.2f})")
    print(f"[*] Mobile Robot Initialized at:   (0.00, 0.00)")
    print(f"[*] Zero Prior Knowledge: The robot does NOT know the box location!\n")

    # Subsystems
    slam = OccupancyGridSLAM(map_size_m=6.0, resolution_m=0.05, robot_radius_m=0.28)
    detector = SemanticTargetDetector(min_pixel_count=12)

    cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "nav_cam")
    site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "attachment")

    # Renderers
    vw, vh = 480, 360
    r_chase = mujoco.Renderer(model, vh, vw)
    r_nav = mujoco.Renderer(model, vh, vw)

    video_writer = None
    if video_path:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        out_w = vw * 3
        out_h = vh
        video_writer = cv2.VideoWriter(video_path, fourcc, 20.0, (out_w, out_h))
        print(f"[*] Recording demonstration video to: {video_path}")

    # Retracted Arm configuration for unobstructed navigation camera view
    q_retracted = np.array([0.0, -0.785, 0.0, -2.356, 0.0, 1.571, 0.785])
    cur_arm_ctrl = q_retracted.copy()
    cur_base_ctrl = np.array([data.qpos[0], data.qpos[1], data.qpos[2]], dtype=float)
    cur_gripper_ctrl = 255.0

    # Downward Grasp Orientation
    home_mat = np.array([
        [9.81983171e-05, 9.99999995e-01, 1.51444362e-16],
        [9.99999995e-01, -9.81983171e-05, 3.15263149e-16],
        [3.15278019e-16, 1.51413403e-16, -1.00000000e+00]
    ])

    q_approach, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.54]), home_mat)
    q_descend, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.385]), home_mat, q_approach)
    q_lift, _ = solve_arm_ik(model, np.array([0.47, 0.0, 0.58]), home_mat, q_descend)

    state = SearchState.INITIAL_SURVEY
    state_timer = 0
    target_locked_pos = None
    current_path = []
    waypoint_idx = 0

    t_state_start = 0
    step = 0
    sim_dt = model.opt.timestep  # 0.002s
    perception_subsample = 10

    while step < max_steps:
        robot_x = float(data.qpos[0])
        robot_y = float(data.qpos[1])
        robot_yaw = float(data.qpos[2])

        # Run perception loop at 50 Hz
        if step % perception_subsample == 0:
            cam_pos = data.cam_xpos[cam_id].copy()
            cam_mat = data.cam_xmat[cam_id].reshape(3, 3).copy()

            # 1. Capture Nav Cam RGB & Depth
            r_nav.enable_depth_rendering()
            r_nav.update_scene(data, camera="nav_cam")
            depth = r_nav.render().copy()
            r_nav.disable_depth_rendering()
            r_nav.update_scene(data, camera="nav_cam")
            rgb_nav = r_nav.render().copy()

            # 2. Update SLAM Grid with 3D raycasting
            slam.integrate_depth_scan(
                depth, robot_x, robot_y, robot_yaw, cam_pos, cam_mat, max_range=3.2
            )

            # 3. Active Semantic Search for Target Box
            detection = detector.detect(rgb_nav, depth, model, data, cam_name="nav_cam")

            if detection is not None:
                latest_pos = detection["world_pos"]
                if target_locked_pos is None:
                    target_locked_pos = latest_pos.copy()
                    state = SearchState.TARGET_SPOTTED
                    state_timer = step
                    print(f"\n[!] >>> TARGET SPOTTED at step {step} (t={step*sim_dt:.1f}s) <<<")
                    print(f"    Estimated 3D Location: ({latest_pos[0]:.3f}, {latest_pos[1]:.3f}, {latest_pos[2]:.3f})")
                    print(f"    Ground Truth Location: ({initial_block_pos[0]:.3f}, {initial_block_pos[1]:.3f}, {initial_block_pos[2]:.3f})")
                    err = np.linalg.norm(latest_pos[:2] - initial_block_pos[:2])
                    print(f"    Initial Optical Error: {err * 100:.2f} cm\n")
                else:
                    target_locked_pos = 0.7 * target_locked_pos + 0.3 * latest_pos
            else:
                detection = None

        # -------------------------------------------------------------
        # FINITE STATE MACHINE (FSM)
        # -------------------------------------------------------------
        if state == SearchState.INITIAL_SURVEY:
            # Complete 360-degree survey scan at spawn origin
            cur_base_ctrl[2] += 0.018  # smooth rotation
            if step > 380:
                state = SearchState.EXPLORE
                print("[*] Completed 360 Initial Survey. Transitioning to State: EXPLORE")

        elif state == SearchState.EXPLORE:
            # Re-plan path when waypoint list is exhausted or periodically
            if not current_path or waypoint_idx >= len(current_path) or step % 180 == 0:
                frontiers = slam.find_frontiers()
                best_f = slam.select_best_frontier(robot_x, robot_y, robot_yaw, frontiers)
                if best_f is not None:
                    current_path = slam.plan_path_astar((robot_x, robot_y), best_f["world_pos"])
                    waypoint_idx = 1 if len(current_path) > 1 else 0

            # Follow collision-free path
            if current_path and waypoint_idx < len(current_path):
                target_wp = current_path[waypoint_idx]
                wp_dx = target_wp[0] - robot_x
                wp_dy = target_wp[1] - robot_y
                dist_to_wp = np.hypot(wp_dx, wp_dy)

                if dist_to_wp < 0.25:
                    waypoint_idx += 1
                else:
                    target_yaw = np.arctan2(wp_dy, wp_dx)
                    yaw_diff = (target_yaw - cur_base_ctrl[2] + np.pi) % (2.0 * np.pi) - np.pi

                    if abs(yaw_diff) > 0.40:
                        cur_base_ctrl[2] += np.clip(yaw_diff, -0.022, 0.022)
                    else:
                        cur_base_ctrl[2] += np.clip(yaw_diff, -0.016, 0.016)
                        v_step = 0.0038
                        cur_base_ctrl[0] += v_step * (wp_dx / dist_to_wp)
                        cur_base_ctrl[1] += v_step * (wp_dy / dist_to_wp)

        elif state == SearchState.TARGET_SPOTTED:
            # Freeze exploration and lock onto target
            if step - state_timer > 30:
                state = SearchState.APPROACH
                print("[*] Transitioning to State: APPROACH")

        elif state == SearchState.APPROACH:
            # Navigate to standoff waypoint 0.47m directly in front of target table
            tx, ty = target_locked_pos[0], target_locked_pos[1]
            standoff_dist = 0.47
            target_standoff_x = tx - standoff_dist
            target_standoff_y = ty
            target_heading = 0.0

            dx = target_standoff_x - robot_x
            dy = target_standoff_y - robot_y
            pos_err = np.hypot(dx, dy)
            yaw_err = (target_heading - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi

            if pos_err > 0.40:
                waypoint_angle = np.arctan2(dy, dx)
                nav_yaw_err = (waypoint_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi
            else:
                nav_yaw_err = yaw_err

            if abs(nav_yaw_err) > 0.35:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.022, 0.022)
            else:
                cur_base_ctrl[2] += np.clip(nav_yaw_err, -0.016, 0.016)
                v_step = min(0.0045, pos_err * 0.05)
                if pos_err > 0.01:
                    cur_base_ctrl[0] += v_step * (dx / pos_err)
                    cur_base_ctrl[1] += v_step * (dy / pos_err)

            # Reached standoff position
            if pos_err < 0.04 and abs(yaw_err) < 0.06:
                state = SearchState.ARM_APPROACH
                state_timer = step
                t_state_start = step
                cur_base_ctrl[0] = robot_x
                cur_base_ctrl[1] = robot_y
                cur_base_ctrl[2] = robot_yaw
                print("\n[*] Reached Standoff Position! Transitioning to State: ARM_APPROACH")
                print(f"    Base locked firmly at: ({robot_x:.3f}, {robot_y:.3f}, yaw={robot_yaw:.3f})")

                # Dynamically solve IK based on exact relative block position
                dx_world = tx - robot_x
                dy_world = ty - robot_y
                cos_y, sin_y = np.cos(robot_yaw), np.sin(robot_yaw)
                local_bx = cos_y * dx_world + sin_y * dy_world
                local_by = -sin_y * dx_world + cos_y * dy_world

                q_approach, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.54]), home_mat)
                q_descend, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.385]), home_mat, q_approach)
                q_lift, _ = solve_arm_ik(model, np.array([local_bx, local_by, 0.58]), home_mat, q_descend)
                print(f"[*] Dynamic Arm IK Solved for local offset: ({local_bx:.3f}, {local_by:.3f})")

        elif state == SearchState.ARM_APPROACH:
            # Smoothly extend arm from retracted position to hover over payload
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_retracted + s * q_approach
            cur_gripper_ctrl = 255.0

            if tau >= 1.0:
                state = SearchState.ARM_DESCEND
                t_state_start = step
                print("[*] Transitioning to State: ARM_DESCEND")

        elif state == SearchState.ARM_DESCEND:
            # Lower gripper down to enclose the payload
            tau = np.clip((step - t_state_start) / 180.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_approach + s * q_descend
            cur_gripper_ctrl = 255.0

            if tau >= 1.0:
                state = SearchState.ARM_GRASP
                t_state_start = step
                print("[*] Transitioning to State: ARM_GRASP (Closing Gripper Fingers)")

        elif state == SearchState.ARM_GRASP:
            # Squeeze fingers closed around the payload
            cur_gripper_ctrl = 0.0
            if step - t_state_start > 160:
                state = SearchState.ARM_LIFT
                t_state_start = step
                print("[*] Transitioning to State: ARM_LIFT (Minimum-Jerk Lift)")

        elif state == SearchState.ARM_LIFT:
            # Smooth minimum-jerk lift raises payload into the air
            tau = np.clip((step - t_state_start) / 250.0, 0.0, 1.0)
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)
            cur_arm_ctrl = (1.0 - s) * q_descend + s * q_lift
            cur_gripper_ctrl = 0.0

            if tau >= 1.0:
                state = SearchState.MISSION_SUCCESS
                state_timer = step
                print("\n=================================================================")
                print("  MISSION SUCCESS: OBJECT SPOTTED, LOCALIZED, AND SECURED!       ")
                print("=================================================================\n")

        # -------------------------------------------------------------
        # APPLY CONTROLS & PHYSICS STEP
        # -------------------------------------------------------------
        data.ctrl[0:7] = cur_arm_ctrl
        data.ctrl[7] = cur_gripper_ctrl
        data.ctrl[8] = cur_base_ctrl[0]
        data.ctrl[9] = cur_base_ctrl[1]
        data.ctrl[10] = cur_base_ctrl[2]

        mujoco.mj_step(model, data)

        # -------------------------------------------------------------
        # VIDEO RENDERING & COMPOSITION (at 20 FPS)
        # -------------------------------------------------------------
        if video_writer is not None and step % 25 == 0:
            r_chase.update_scene(data, camera="chase_cam")
            rgb_chase = r_chase.render()

            r_nav.update_scene(data, camera="nav_cam")
            rgb_nav_clean = r_nav.render()
            rgb_nav_hud = detector.render_overlay(rgb_nav_clean, detection)

            map_hud = slam.render_map_image(
                target_w=(target_locked_pos[0], target_locked_pos[1]) if target_locked_pos is not None else None
            )
            map_panel = np.full((vh, vw, 3), 35, dtype=np.uint8)
            map_resized = cv2.resize(map_hud, (vh, vh))
            x_offset = (vw - vh) // 2
            map_panel[:, x_offset : x_offset + vh] = map_resized

            cv2.putText(rgb_chase, "EXTERNAL CHASE VIEW", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(rgb_nav_hud, "ONBOARD NAV CAMERA", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(map_panel, "2D OCCUPANCY SLAM & FRONTIERS", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)

            composite = np.hstack([rgb_chase, rgb_nav_hud, map_panel])

            status_text = f"STATE: {state.name} | Steps: {step} | Robot: ({robot_x:.2f}, {robot_y:.2f})"
            if target_locked_pos is not None:
                status_text += f" | Lock: ({target_locked_pos[0]:.2f}, {target_locked_pos[1]:.2f})"
            cv2.rectangle(composite, (0, 0), (out_w, 32), (20, 20, 25), -1)
            cv2.line(composite, (0, 32), (out_w, 32), (60, 60, 70), 1)
            cv2.putText(composite, status_text, (20, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 220, 255), 1, cv2.LINE_AA)

            bgr_frame = cv2.cvtColor(composite, cv2.COLOR_RGB2BGR)
            video_writer.write(bgr_frame)

        if state == SearchState.MISSION_SUCCESS and step - state_timer > 200:
            break

        step += 1

    if video_writer is not None:
        video_writer.release()
        print(f"[*] Video saved cleanly ({step} steps processed).")

    block_pos = data.xpos[block_id]
    print(f"[*] Final Payload Box Height: z = {block_pos[2]:.3f}m")
    if block_pos[2] > 0.45:
        print("[+] SUCCESS: Box is securely grasped and lifted into the air!")
    else:
        print("[-] Notice: Box height is", block_pos[2])

    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Active Visual Search (ObjectNav) in MuJoCo")
    parser.add_argument("--video", type=str, default="objectnav_search_demo.mp4", help="Path to output video file")
    parser.add_argument("--steps", type=int, default=3200, help="Max simulation steps")
    parser.add_argument("--viewer", action="store_true", help="Launch interactive passive viewer")
    args = parser.parse_args()

    run_active_visual_search(
        video_path=args.video,
        max_steps=args.steps,
        show_viewer=args.viewer,
    )
