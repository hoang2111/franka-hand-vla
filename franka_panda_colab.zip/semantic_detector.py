"""
Semantic Object Detection & 3D Optical Back-Projection Engine.
Monitors onboard camera streams, detects target payload objects via semantic color/SAM cues,
and projects 2D image coordinates into metric 3D room coordinates using depth buffer data.
"""

import cv2
import mujoco
import numpy as np


class SemanticTargetDetector:
    def __init__(self, min_pixel_count: int = 12):
        self.min_pixel_count = min_pixel_count

    def detect(
        self,
        rgb: np.ndarray,
        depth: np.ndarray,
        model: mujoco.MjModel,
        data: mujoco.MjData,
        cam_name: str = "nav_cam",
    ) -> dict | None:
        """
        Scans RGB frame for red target box. If found, back-projects to 3D world space.
        """
        # Convert RGB to HSV for illumination-invariant detection
        hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)

        # Red wraps around 0 and 180 in HSV
        lower_red1 = np.array([0, 140, 60], dtype=np.uint8)
        upper_red1 = np.array([10, 255, 255], dtype=np.uint8)
        lower_red2 = np.array([170, 140, 60], dtype=np.uint8)
        upper_red2 = np.array([180, 255, 255], dtype=np.uint8)

        mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
        red_mask = cv2.bitwise_or(mask1, mask2)

        # Morphological opening to suppress single-pixel sensor noise
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        clean_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)

        ys, xs = np.where(clean_mask > 0)
        pixel_count = len(xs)
        if pixel_count < self.min_pixel_count:
            return None

        # Calculate bounding box and centroid
        x_min, x_max = int(np.min(xs)), int(np.max(xs))
        y_min, y_max = int(np.min(ys)), int(np.max(ys))
        u_center = float(np.median(xs))
        v_center = float(np.median(ys))

        # Query metric depth at the centroid
        patch_depth = depth[y_min : y_max + 1, x_min : x_max + 1]
        valid_depths = patch_depth[~np.isnan(patch_depth) & (patch_depth > 0.1)]
        if len(valid_depths) == 0:
            return None
        z_metric = float(np.median(valid_depths))

        if z_metric > 4.5 or z_metric < 0.15:
            return None  # out of realistic sensor range

        # 3D Back-Projection from Camera to World Coordinates
        cam_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, cam_name)
        h, w = depth.shape
        fovy = model.cam_fovy[cam_id]
        fy = (h / 2.0) / np.tan(np.deg2rad(fovy / 2.0))
        fx = fy
        cx = w / 2.0
        cy = h / 2.0

        x_opt = (u_center - cx) * z_metric / fx
        y_opt = (v_center - cy) * z_metric / fy
        z_opt = z_metric

        cam_pos = data.cam_xpos[cam_id]
        cam_mat = data.cam_xmat[cam_id].reshape(3, 3)

        # MuJoCo camera convention: optical X = col 0, optical Y = -col 1, optical Z = -col 2
        p_world = cam_pos + x_opt * cam_mat[:, 0] - y_opt * cam_mat[:, 1] - z_opt * cam_mat[:, 2]

        confidence = float(min(1.0, pixel_count / 40.0))

        return {
            "detected": True,
            "pixel_center": (u_center, v_center),
            "bbox": (x_min, y_min, x_max, y_max),
            "pixel_count": pixel_count,
            "depth_m": z_metric,
            "world_pos": p_world,
            "confidence": confidence,
        }

    def render_overlay(self, rgb: np.ndarray, detection: dict | None) -> np.ndarray:
        """
        Draws high-visibility targeting HUD on RGB camera frames.
        """
        annotated = rgb.copy()
        h, w, _ = annotated.shape

        if detection is not None and detection.get("detected", False):
            x_min, y_min, x_max, y_max = detection["bbox"]
            u, v = int(round(detection["pixel_center"][0])), int(round(detection["pixel_center"][1]))
            dist = detection["depth_m"]
            conf = detection["confidence"] * 100.0

            # Green targeting box with crosshair
            cv2.rectangle(annotated, (x_min - 2, y_min - 2), (x_max + 2, y_max + 2), (0, 255, 0), 2)
            cv2.line(annotated, (u - 6, v), (u + 6, v), (0, 255, 0), 1)
            cv2.line(annotated, (u, v - 6), (u, v + 6), (0, 255, 0), 1)

            # HUD Pill Banner
            cv2.rectangle(annotated, (10, 10), (250, 60), (0, 0, 0), -1)
            cv2.rectangle(annotated, (10, 10), (250, 60), (0, 255, 0), 1)
            cv2.putText(
                annotated, "TARGET LOCKED: RED BOX", (18, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1, cv2.LINE_AA
            )
            cv2.putText(
                annotated, f"Dist: {dist:.2f}m | Conf: {conf:.0f}%", (18, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (220, 220, 220), 1, cv2.LINE_AA
            )
        else:
            # Active Scanning Banner
            cv2.rectangle(annotated, (10, 10), (220, 45), (0, 0, 0), -1)
            cv2.rectangle(annotated, (10, 10), (220, 45), (0, 180, 255), 1)
            cv2.putText(
                annotated, "SEARCHING: Scanning Area...", (18, 32),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 180, 255), 1, cv2.LINE_AA
            )

        return annotated
