"""
3D RGB-D Voxel SLAM & Autonomous Spatial Reconstruction Engine.
Features:
1. Real-time 3D voxel hash mapping from onboard RGB-D depth and color streams.
2. 3D perspective / isometric visualizer with camera frustum, trajectory ribbon, and target markers.
3. Automatic 2D costmap and frontier projection for collision-free A* navigation.
4. Standard 3D PLY point cloud export.
"""

from collections import deque
import cv2
import numpy as np


class RGBD_SLAM3D:
    """
    3D RGB-D SLAM system that maintains a 3D metric voxel map of the environment,
    tracks the 3D trajectory of the robot, projects obstacles to a 2D costmap for navigation,
    and renders live 3D perspective visualizations.
    """

    def __init__(
        self,
        map_size_m: float = 6.0,
        voxel_size_m: float = 0.04,
        robot_radius_m: float = 0.28,
        max_height_m: float = 1.4,
    ):
        self.map_size = map_size_m
        self.voxel_size = voxel_size_m
        self.robot_radius = robot_radius_m
        self.max_height = max_height_m
        self.origin = -map_size_m / 2.0  # -3.0m

        # 3D Voxel Hash Map: (vx, vy, vz) -> [r, g, b, count, z_world]
        self.voxels: dict[tuple[int, int, int], np.ndarray] = {}

        # 2D Projected Occupancy Grid for A* and Frontiers: -1=UNKNOWN, 0=FREE, 100=OCCUPIED
        self.grid_res = 0.05
        self.grid_size = int(round(map_size_m / self.grid_res))
        self.grid_2d = np.full((self.grid_size, self.grid_size), -1, dtype=np.int8)

        # 3D Trajectory History: list of (x, y, z, yaw)
        self.trajectory_3d: list[tuple[float, float, float, float]] = []

        # 3D Targets: dict of name -> dict(pos=(x,y,z), color=(r,g,b), bbox=size)
        self.targets: dict[str, dict] = {}

    def world_to_grid_2d(self, wx: float, wy: float) -> tuple[int, int]:
        gx = int((wx - self.origin) / self.grid_res)
        gy = int((wy - self.origin) / self.grid_res)
        return gx, gy

    def grid_to_world_2d(self, gx: int, gy: int) -> tuple[float, float]:
        wx = self.origin + (gx + 0.5) * self.grid_res
        wy = self.origin + (gy + 0.5) * self.grid_res
        return wx, wy

    def in_bounds_2d(self, gx: int, gy: int) -> bool:
        return 0 <= gx < self.grid_size and 0 <= gy < self.grid_size

    def update_odometry(self, rx: float, ry: float, rz: float = 0.10, ryaw: float = 0.0):
        if (
            not self.trajectory_3d
            or np.hypot(rx - self.trajectory_3d[-1][0], ry - self.trajectory_3d[-1][1]) > 0.04
            or abs(ryaw - self.trajectory_3d[-1][3]) > 0.08
        ):
            self.trajectory_3d.append((rx, ry, rz, ryaw))

        # Clear footprint of robot in 2D costmap
        rgx, rgy = self.world_to_grid_2d(rx, ry)
        rad_cells = int(np.ceil(self.robot_radius / self.grid_res))
        for dx in range(-rad_cells, rad_cells + 1):
            for dy in range(-rad_cells, rad_cells + 1):
                if dx * dx + dy * dy <= rad_cells * rad_cells:
                    nx, ny = rgx + dx, rgy + dy
                    if self.in_bounds_2d(nx, ny):
                        self.grid_2d[ny, nx] = 0

    def set_target(self, name: str, pos: np.ndarray, color: tuple[int, int, int] = (255, 0, 0), size: float = 0.08):
        self.targets[name] = {
            "pos": np.array(pos, dtype=float),
            "color": color,
            "size": size,
        }

    def integrate_depth_scan(
        self,
        depth_map: np.ndarray,
        robot_x: float,
        robot_y: float,
        robot_yaw: float,
        cam_pos: np.ndarray,
        cam_mat: np.ndarray,
        rgb_map: np.ndarray = None,
        fovy_deg: float = 85.0,
        max_range: float = 3.5,
        subsample_step: int = 3,
    ):
        """
        Integrates an RGB-D depth and color frame into the 3D voxel SLAM map.
        Updates 3D point cloud and projects vertical obstacles into the 2D grid.
        """
        self.update_odometry(robot_x, robot_y, rz=cam_pos[2] - 0.74, ryaw=robot_yaw)

        h, w = depth_map.shape
        fy = (h / 2.0) / np.tan(np.deg2rad(fovy_deg / 2.0))
        fx = fy
        cx = w / 2.0
        cy = h / 2.0

        # Subsample pixel grid
        us, vs = np.meshgrid(
            np.arange(0, w, subsample_step),
            np.arange(0, h, subsample_step),
        )

        z_vals = depth_map[vs, us]
        valid = (z_vals > 0.22) & (z_vals < max_range) & (~np.isnan(z_vals))

        if not np.any(valid):
            return

        u_val = us[valid]
        v_val = vs[valid]
        z_val = z_vals[valid]

        if rgb_map is not None:
            colors = rgb_map[v_val, u_val]
        else:
            colors = np.full((len(z_val), 3), 180, dtype=np.uint8)

        # Optical Ray Back-Projection (Camera Frame)
        x_opt = (u_val - cx) * z_val / fx
        y_opt = (v_val - cy) * z_val / fy

        # MuJoCo Camera Convention: optical X = col 0, optical Y = -col 1, optical Z = -col 2
        pts_cam = np.vstack([x_opt, -y_opt, -z_val])
        pts_world = cam_pos[:, None] + cam_mat @ pts_cam

        # Filter points inside the robot base footprint
        dist_to_robot = np.hypot(pts_world[0] - robot_x, pts_world[1] - robot_y)
        not_robot_body = dist_to_robot > (self.robot_radius + 0.05)

        pw = pts_world[:, not_robot_body]
        cols = colors[not_robot_body]

        if pw.shape[1] == 0:
            return

        # 3D Voxel Discretization
        v_coords = np.floor(pw / self.voxel_size).astype(int)

        start_gx, start_gy = self.world_to_grid_2d(robot_x, robot_y)

        # Raytrace free space in 2D
        cols_to_raytrace = np.unique(u_val[::4])
        for u in cols_to_raytrace:
            v_idx = np.where(u_val == u)[0]
            if len(v_idx) > 0:
                mid_idx = v_idx[len(v_idx) // 2]
                rx, ry = pw[0, mid_idx], pw[1, mid_idx]
                end_gx, end_gy = self.world_to_grid_2d(rx, ry)
                self._bresenham_free_2d(start_gx, start_gy, end_gx, end_gy)

        # Update 3D Voxel Hash Map & 2D Obstacle Costmap
        for i in range(pw.shape[1]):
            k = (int(v_coords[0, i]), int(v_coords[1, i]), int(v_coords[2, i]))
            zw = pw[2, i]

            if k not in self.voxels:
                # Store [R, G, B, count, Z]
                self.voxels[k] = np.array([cols[i, 0], cols[i, 1], cols[i, 2], 1.0, zw], dtype=float)
            else:
                entry = self.voxels[k]
                entry[0:3] = 0.85 * entry[0:3] + 0.15 * cols[i]
                entry[3] += 1.0

            # 2D Obstacle Projection: vertical structures between 5cm and 1.1m
            if 0.05 < zw < 1.10:
                gx, gy = self.world_to_grid_2d(pw[0, i], pw[1, i])
                if self.in_bounds_2d(gx, gy):
                    self.grid_2d[gy, gx] = 100

    def _bresenham_free_2d(self, x0: int, y0: int, x1: int, y1: int):
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy

        cx, cy = x0, y0
        while True:
            if cx == x1 and cy == y1:
                break
            if self.in_bounds_2d(cx, cy):
                if self.grid_2d[cy, cx] != 100:
                    self.grid_2d[cy, cx] = 0
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                cx += sx
            if e2 < dx:
                err += dx
                cy += sy

    def find_frontiers(self, min_cluster_size: int = 4) -> list[dict]:
        """Finds unexplored frontiers on the boundary of free and unknown space."""
        frontier_mask = np.zeros_like(self.grid_2d, dtype=np.uint8)
        for y in range(1, self.grid_size - 1):
            for x in range(1, self.grid_size - 1):
                if self.grid_2d[y, x] == 0:  # Free cell
                    neighbors = [
                        self.grid_2d[y + 1, x],
                        self.grid_2d[y - 1, x],
                        self.grid_2d[y, x + 1],
                        self.grid_2d[y - 1, x],
                    ]
                    if -1 in neighbors:  # Adjacent to unknown space
                        frontier_mask[y, x] = 255

        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            frontier_mask, connectivity=8
        )

        frontiers = []
        for i in range(1, num_labels):
            size = stats[i, cv2.CC_STAT_AREA]
            if size >= min_cluster_size:
                gcx, gcy = centroids[i]
                wcx, wcy = self.grid_to_world_2d(int(round(gcx)), int(round(gcy)))
                frontiers.append({
                    "grid_pos": (int(round(gcx)), int(round(gcy))),
                    "world_pos": (wcx, wcy),
                    "size": int(size),
                })
        return frontiers

    def select_best_frontier(
        self,
        robot_x: float,
        robot_y: float,
        robot_yaw: float,
        frontiers: list[dict],
    ) -> dict | None:
        """Selects optimal exploration frontier using distance, size, and heading."""
        if not frontiers:
            return None

        best_score = -float("inf")
        best_frontier = None

        for f in frontiers:
            wx, wy = f["world_pos"]
            dist = np.hypot(wx - robot_x, wy - robot_y)
            if dist < 0.20:
                continue

            target_angle = np.arctan2(wy - robot_y, wx - robot_x)
            angle_diff = abs((target_angle - robot_yaw + np.pi) % (2.0 * np.pi) - np.pi)

            score = (f["size"] * 2.5) - (dist * 2.8) - (angle_diff * 1.2)
            if score > best_score:
                best_score = score
                best_frontier = f

        return best_frontier

    def plan_path_astar(
        self,
        start_w: tuple[float, float],
        goal_w: tuple[float, float],
    ) -> list[tuple[float, float]]:
        """Plans 2D collision-free path on the inflated costmap using A*."""
        sx, sy = self.world_to_grid_2d(start_w[0], start_w[1])
        gx, gy = self.world_to_grid_2d(goal_w[0], goal_w[1])

        # Inflate obstacles
        kernel_radius = int(np.ceil(self.robot_radius / self.grid_res))
        kernel_size = 2 * kernel_radius + 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        obs_mask = (self.grid_2d == 100).astype(np.uint8)
        inflated_obs = cv2.dilate(obs_mask, kernel)

        import heapq
        open_set = []
        heapq.heappush(open_set, (0.0, (sx, sy)))
        came_from = {}
        g_score = {(sx, sy): 0.0}

        def heuristic(a, b):
            return np.hypot(a[0] - b[0], a[1] - b[1])

        found = False
        while open_set:
            _, current = heapq.heappop(open_set)
            if np.hypot(current[0] - gx, current[1] - gy) <= 2:
                gx, gy = current
                found = True
                break

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if not self.in_bounds_2d(neighbor[0], neighbor[1]):
                    continue
                if inflated_obs[neighbor[1], neighbor[0]] > 0:
                    continue

                step_cost = 1.414 if (dx != 0 and dy != 0) else 1.0
                tentative_g = g_score[current] + step_cost
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + 1.2 * heuristic(neighbor, (gx, gy))
                    heapq.heappush(open_set, (f, neighbor))

        if not found and (gx, gy) not in came_from:
            return [start_w, goal_w]

        curr = (gx, gy)
        grid_path = [curr]
        while curr in came_from:
            curr = came_from[curr]
            grid_path.append(curr)
        grid_path.reverse()

        subsampled = grid_path[::3]
        if grid_path[-1] not in subsampled:
            subsampled.append(grid_path[-1])

        world_path = [self.grid_to_world_2d(p[0], p[1]) for p in subsampled]
        return world_path

    def render_3d_view(
        self,
        width: int = 480,
        height: int = 360,
        vcam_pos: np.ndarray = None,
        vcam_target: np.ndarray = None,
        show_frustum: bool = True,
        cur_cam_pos: np.ndarray = None,
        cur_cam_mat: np.ndarray = None,
        active_target_w: tuple[float, float] = None,
        color_mode: str = "rgb",  # "rgb" or "elevation"
    ) -> np.ndarray:
        """
        Renders a stunning 3D perspective / isometric visualization of the 3D voxel map.
        Includes 3D floor grid, perimeter bounds, 3D robot trajectory ribbon,
        3D camera frustum pyramid, and 3D target lock pins.
        """
        canvas = np.full((height, width, 3), (16, 18, 22), dtype=np.uint8)

        # Virtual observation camera configuration
        if vcam_pos is None:
            vcam_pos = np.array([3.4, -4.4, 3.8])
        if vcam_target is None:
            vcam_target = np.array([0.0, 0.0, 0.25])

        forward = vcam_target - vcam_pos
        forward /= np.linalg.norm(forward)
        right = np.cross(forward, np.array([0, 0, 1]))
        right /= np.linalg.norm(right)
        up = np.cross(right, forward)

        # Perspective camera rotation matrix
        R_cam = np.vstack([right, -up, forward])
        focal = float(width * 0.85)
        cx3d, cy3d = width / 2.0, height / 2.0

        def project(pts: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
            rel = pts - vcam_pos
            pts_c = rel @ R_cam.T
            zc = pts_c[:, 2]
            valid = zc > 0.1
            u = cx3d + focal * pts_c[:, 0] / np.maximum(zc, 0.01)
            v = cy3d + focal * pts_c[:, 1] / np.maximum(zc, 0.01)
            return u, v, zc, valid

        # 1. Draw 3D Ground Grid Lines
        for x in np.linspace(-3.0, 3.0, 13):
            line_pts = np.array([[x, -3.0, 0.0], [x, 3.0, 0.0]])
            u, v, zc, val = project(line_pts)
            if np.all(val):
                cv2.line(canvas, (int(u[0]), int(v[0])), (int(u[1]), int(v[1])), (32, 36, 44), 1, cv2.LINE_AA)

        for y in np.linspace(-3.0, 3.0, 13):
            line_pts = np.array([[-3.0, y, 0.0], [3.0, y, 0.0]])
            u, v, zc, val = project(line_pts)
            if np.all(val):
                cv2.line(canvas, (int(u[0]), int(v[0])), (int(u[1]), int(v[1])), (32, 36, 44), 1, cv2.LINE_AA)

        # 2. Draw 3D Perimeter Arena Boundary Wireframe
        corners = np.array([
            [-3.0, -3.0, 0.0], [3.0, -3.0, 0.0], [3.0, 3.0, 0.0], [-3.0, 3.0, 0.0],
            [-3.0, -3.0, 0.7], [3.0, -3.0, 0.7], [3.0, 3.0, 0.7], [-3.0, 3.0, 0.7],
        ])
        cu, cv, czc, cval = project(corners)
        edges = [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)]
        for i, j in edges:
            if cval[i] and cval[j]:
                cv2.line(canvas, (int(cu[i]), int(cv[i])), (int(cu[j]), int(cv[j])), (60, 70, 85), 1, cv2.LINE_AA)

        # 3. Draw 3D Trajectory Ribbon
        if len(self.trajectory_3d) > 1:
            t_pts = np.array([[p[0], p[1], p[2]] for p in self.trajectory_3d])
            tu, tv, tzc, tval = project(t_pts)
            for k in range(len(tu) - 1):
                if tval[k] and tval[k + 1]:
                    cv2.line(
                        canvas,
                        (int(tu[k]), int(tv[k])),
                        (int(tu[k + 1]), int(tv[k + 1])),
                        (255, 140, 0),  # Glowing orange trajectory
                        2,
                        cv2.LINE_AA,
                    )

        # 4. Draw 3D Voxels / Points
        if len(self.voxels) > 0:
            keys = np.array(list(self.voxels.keys()))
            pts_3d = (keys + 0.5) * self.voxel_size
            voxel_data = np.array(list(self.voxels.values()))

            vu, vv, vzc, vval = project(pts_3d)
            valid_idx = np.where(vval)[0]

            if len(valid_idx) > 0:
                # Sort by depth descending (Painter's algorithm)
                depth_order = np.argsort(-vzc[valid_idx])
                sorted_idx = valid_idx[depth_order]

                u_s = vu[sorted_idx].astype(int)
                v_s = vv[sorted_idx].astype(int)

                if color_mode == "rgb":
                    colors_s = voxel_data[sorted_idx, 0:3].astype(np.uint8)
                    for i in range(len(u_s)):
                        ui, vi = u_s[i], v_s[i]
                        if 0 <= ui < width and 0 <= vi < height:
                            # Direct RGB pixel assignment
                            canvas[vi, ui] = (int(colors_s[i, 0]), int(colors_s[i, 1]), int(colors_s[i, 2]))
                else:
                    # Height heatmap (deep blue floor -> cyan -> yellow -> magenta)
                    z_world = pts_3d[sorted_idx, 2]
                    norm_z = np.clip(z_world / 0.8, 0.0, 1.0)
                    heat_r = (255 * norm_z).astype(np.uint8)
                    heat_g = (255 * np.sin(np.pi * norm_z)).astype(np.uint8)
                    heat_b = (255 * (1.0 - norm_z)).astype(np.uint8)
                    for i in range(len(u_s)):
                        ui, vi = u_s[i], v_s[i]
                        if 0 <= ui < width and 0 <= vi < height:
                            canvas[vi, ui] = (int(heat_r[i]), int(heat_g[i]), int(heat_b[i]))

        # 5. Draw 3D Camera Frustum Pyramid (Showing live camera scan cone in 3D)
        if show_frustum and cur_cam_pos is not None and cur_cam_mat is not None:
            frust_range = 1.6
            f_tan = np.tan(np.deg2rad(42.5))
            f_w = frust_range * f_tan * (width / height)
            f_h = frust_range * f_tan

            # 4 corners in camera frame
            c_corners_cam = np.array([
                [-f_w, -f_h, frust_range],
                [f_w, -f_h, frust_range],
                [f_w, f_h, frust_range],
                [-f_w, f_h, frust_range],
            ])
            # Transform to world
            c_corners_w = cur_cam_pos[:, None] + cur_cam_mat @ np.vstack([
                c_corners_cam[:, 0],
                -c_corners_cam[:, 1],
                -c_corners_cam[:, 2],
            ])

            frust_pts = np.vstack([cur_cam_pos[None, :], c_corners_w.T])
            fu, fv, fzc, fval = project(frust_pts)

            if np.all(fval):
                apex = (int(fu[0]), int(fv[0]))
                c0 = (int(fu[1]), int(fv[1]))
                c1 = (int(fu[2]), int(fv[2]))
                c2 = (int(fu[3]), int(fv[3]))
                c3 = (int(fu[4]), int(fv[4]))

                # Frustum pyramid edges in bright cyan (RGB: 0, 220, 255)
                cv2.line(canvas, apex, c0, (0, 220, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, apex, c1, (0, 220, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, apex, c2, (0, 220, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, apex, c3, (0, 220, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, c0, c1, (0, 200, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, c1, c2, (0, 200, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, c2, c3, (0, 200, 255), 1, cv2.LINE_AA)
                cv2.line(canvas, c3, c0, (0, 200, 255), 1, cv2.LINE_AA)

        # 6. Draw 3D Target Marker Pins & Bounding Boxes
        for tname, tinfo in self.targets.items():
            tpos = tinfo["pos"]
            # 3D Pin from floor to object
            pin_pts = np.array([[tpos[0], tpos[1], 0.0], [tpos[0], tpos[1], tpos[2] + 0.15]])
            pu, pv, pzc, pval = project(pin_pts)
            if np.all(pval):
                base_pt = (int(pu[0]), int(pv[0]))
                top_pt = (int(pu[1]), int(pv[1]))
                rgb_col = (int(tinfo["color"][0]), int(tinfo["color"][1]), int(tinfo["color"][2]))

                cv2.line(canvas, base_pt, top_pt, rgb_col, 2, cv2.LINE_AA)
                cv2.circle(canvas, base_pt, 4, (120, 120, 120), 1, cv2.LINE_AA)
                cv2.circle(canvas, top_pt, 6, rgb_col, -1, cv2.LINE_AA)
                cv2.putText(
                    canvas,
                    tname.upper(),
                    (top_pt[0] + 8, top_pt[1] + 4),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.38,
                    rgb_col,
                    1,
                    cv2.LINE_AA,
                )

        # 7. Draw HUD Legend & Statistics
        cv2.putText(canvas, "3D RGB-D SLAM MAP", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(
            canvas,
            f"Voxels: {len(self.voxels):,}",
            (12, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.36,
            (0, 220, 255),
            1,
            cv2.LINE_AA,
        )
        if len(self.trajectory_3d) > 0:
            rx, ry, rz, ryaw = self.trajectory_3d[-1]
            cv2.putText(
                canvas,
                f"Pose: ({rx:.2f}, {ry:.2f}) Yaw: {ryaw:.2f}",
                (12, height - 12),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.34,
                (200, 200, 200),
                1,
                cv2.LINE_AA,
            )

        return canvas

    def export_ply(self, filename: str):
        """Exports the 3D voxel SLAM map as a standard ASCII PLY point cloud file."""
        if not self.voxels:
            print("[-] No voxels to export.")
            return

        keys = np.array(list(self.voxels.keys()))
        pts = (keys + 0.5) * self.voxel_size
        data = np.array(list(self.voxels.values()))
        cols = data[:, 0:3].astype(np.uint8)

        n = len(pts)
        with open(filename, "w") as f:
            f.write("ply\n")
            f.write("format ascii 1.0\n")
            f.write(f"element vertex {n}\n")
            f.write("property float x\n")
            f.write("property float y\n")
            f.write("property float z\n")
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
            f.write("end_header\n")
            for i in range(n):
                f.write(
                    f"{pts[i, 0]:.4f} {pts[i, 1]:.4f} {pts[i, 2]:.4f} {cols[i, 0]} {cols[i, 1]} {cols[i, 2]}\n"
                )
        print(f"[+] Exported {n:,} 3D SLAM voxels to: {filename}")
