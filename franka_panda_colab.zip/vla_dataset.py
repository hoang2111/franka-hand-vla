1"""
Dataset generator for Vision-Language-Action (VLA) robot task.
Collects expert demonstrations across randomized tabletop positions.
"""
import os
import time
import numpy as np
import cv2
import mujoco

from fsm_pick_and_place import solve_ik, minimum_jerk_traj

def generate_expert_demonstrations(
    num_episodes: int = 60,
    xml_path: str = "vla_panda.xml",
    cam_name: str = "workspace_cam",
    img_size: int = 128,
    dt: float = 0.05,  # 20 Hz control loop
):
    """
    Collects expert demonstrations for VLA training.
    Saves:
      - images: (N, img_size, img_size, 3) uint8
      - language_ids: (N,) int64 (0: "pick up the red box", 1: "place in the green tray")
      - actions: (N, 4) float32 (dx, dy, dz, gripper_cmd: -1=close, +1=open)
      - ee_positions: (N, 3) float32
    """
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)
    renderer = mujoco.Renderer(model, height=img_size, width=img_size)

    site_id = model.site("attachment").id
    block_body_id = model.body("block").id
    tray_body_id = model.body("tray").id

    # Downward grasping orientation
    target_mat = np.array([
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, -1.0]
    ])

    images = []
    lang_ids = []
    actions = []
    ee_poses = []

    print(f"Generating {num_episodes} expert demonstrations for VLA training...")
    t0 = time.time()

    for ep in range(num_episodes):
        # Reset to home keyframe
        mujoco.mj_resetDataKeyframe(model, data, 0)

        # Randomize block position on the table
        # Table is at pos [0.5, 0, 0.1], size [0.3, 0.4, 0.1], top surface at z = 0.20
        block_x = np.random.uniform(0.40, 0.54)
        block_y = np.random.uniform(-0.16, 0.10)
        block_z = 0.22  # on table
        data.body("block").xpos[:] = [block_x, block_y, block_z]
        # Set block joint qpos (freejoint: 3 pos + 4 quat)
        block_jnt_id = model.body("block").jntadr[0]
        data.qpos[model.jnt_qposadr[block_jnt_id]:model.jnt_qposadr[block_jnt_id]+3] = [block_x, block_y, block_z]
        data.qpos[model.jnt_qposadr[block_jnt_id]+3:model.jnt_qposadr[block_jnt_id]+7] = [1, 0, 0, 0]

        # Randomize tray position (keep safe separation from block)
        tray_x = np.random.uniform(0.46, 0.58)
        tray_y = np.random.uniform(0.16, 0.28)
        tray_z = 0.21
        data.body("tray").xpos[:] = [tray_x, tray_y, tray_z]
        tray_body = model.body("tray")
        model.body_pos[tray_body_id] = [tray_x, tray_y, tray_z]

        mujoco.mj_forward(model, data)

        # Define 5 key waypoints for this episode:
        # W0: Home / Initial
        p_home = data.site_xpos[site_id].copy()
        # W1: Hover above block
        p_approach = np.array([block_x, block_y, 0.38])
        # W2: Descend to block
        p_descend = np.array([block_x, block_y, 0.245])
        # W3: Lift above block
        p_lift = np.array([block_x, block_y, 0.38])
        # W4: Hover above tray
        p_tray = np.array([tray_x, tray_y, 0.38])
        # W5: Descend to tray
        p_drop = np.array([tray_x, tray_y, 0.28])

        # Solve IK for waypoints
        q_home = data.qpos[:7].copy()
        q_app, _ = solve_ik(model, data, site_id, p_approach, target_mat, q_home)
        q_desc, _ = solve_ik(model, data, site_id, p_descend, target_mat, q_app)
        q_lift, _ = solve_ik(model, data, site_id, p_lift, target_mat, q_desc)
        q_tray, _ = solve_ik(model, data, site_id, p_tray, target_mat, q_lift)
        q_drop, _ = solve_ik(model, data, site_id, p_drop, target_mat, q_tray)

        # Episode stages:
        # Stage 1: Approach (instruction = "pick up the red box", lang_id=0, gripper=open=1.0)
        # Stage 2: Descend (instruction = "pick up the red box", lang_id=0, gripper=open=1.0)
        # Stage 3: Grasp   (instruction = "pick up the red box", lang_id=0, gripper=close=-1.0)
        # Stage 4: Lift    (instruction = "place in the green tray", lang_id=1, gripper=close=-1.0)
        # Stage 5: MoveTray(instruction = "place in the green tray", lang_id=1, gripper=close=-1.0)
        # Stage 6: Release (instruction = "place in the green tray", lang_id=1, gripper=open=1.0)

        stages = [
            # (q_start, q_end, duration_s, lang_id, gripper_val, grip_ctrl)
            (q_home, q_app,  1.2, 0,  1.0, 255.0),  # Approach
            (q_app,  q_desc, 0.8, 0,  1.0, 255.0),  # Descend
            (q_desc, q_desc, 0.6, 0, -1.0,   0.0),  # Grasp
            (q_desc, q_lift, 0.8, 1, -1.0,   0.0),  # Lift
            (q_lift, q_tray, 1.2, 1, -1.0,   0.0),  # Move to tray
            (q_tray, q_drop, 0.6, 1, -1.0,   0.0),  # Lower to tray
            (q_drop, q_drop, 0.5, 1,  1.0, 255.0),  # Release
        ]

        # Reset robot to home
        data.qpos[:7] = q_home
        data.ctrl[:7] = q_home
        data.ctrl[7] = 255.0
        mujoco.mj_forward(model, data)

        for q_from, q_to, duration, lang_id, grip_val, grip_ctrl in stages:
            n_steps = max(1, int(duration / dt))
            for s in range(n_steps):
                tau = float(s) / float(n_steps)
                q_target = minimum_jerk_traj(q_from, q_to, tau)
                data.ctrl[:7] = q_target
                data.ctrl[7] = grip_ctrl

                # Step physics
                for _ in range(int(dt / 0.002)):
                    mujoco.mj_step(model, data)

                # Render current observation
                renderer.update_scene(data, camera=cam_name)
                frame = renderer.render()

                current_ee = data.site_xpos[site_id].copy()

                # Next target end effector position
                tau_next = min(1.0, float(s + 1) / float(n_steps))
                q_next = minimum_jerk_traj(q_from, q_to, tau_next)

                # Forward kinematics for next target
                d_tmp = mujoco.MjData(model)
                d_tmp.qpos[:] = data.qpos[:]
                d_tmp.qpos[:7] = q_next
                mujoco.mj_forward(model, d_tmp)
                next_ee = d_tmp.site_xpos[site_id].copy()

                delta_ee = next_ee - current_ee

                # Action: [dx, dy, dz, gripper_action]
                action = np.array([delta_ee[0], delta_ee[1], delta_ee[2], grip_val], dtype=np.float32)

                images.append(frame)
                lang_ids.append(lang_id)
                actions.append(action)
                ee_poses.append(current_ee.astype(np.float32))

        if (ep + 1) % 15 == 0 or (ep + 1) == num_episodes:
            print(f"  Episode {ep + 1}/{num_episodes} generated | Collected {len(images)} samples | Elapsed: {time.time()-t0:.1f}s")

    data_dir = "vla_data"
    os.makedirs(data_dir, exist_ok=True)
    images_np = np.array(images, dtype=np.uint8)
    lang_ids_np = np.array(lang_ids, dtype=np.int64)
    actions_np = np.array(actions, dtype=np.float32)
    ee_poses_np = np.array(ee_poses, dtype=np.float32)

    np.save(os.path.join(data_dir, "images.npy"), images_np)
    np.save(os.path.join(data_dir, "lang_ids.npy"), lang_ids_np)
    np.save(os.path.join(data_dir, "actions.npy"), actions_np)
    np.save(os.path.join(data_dir, "ee_poses.npy"), ee_poses_np)

    print(f"\nDone! Dataset saved to '{data_dir}/':")
    print(f"  Images:      {images_np.shape} ({images_np.nbytes / 1e6:.1f} MB)")
    print(f"  Lang IDs:    {lang_ids_np.shape} (Task 0: {np.sum(lang_ids_np==0)}, Task 1: {np.sum(lang_ids_np==1)})")
    print(f"  Actions:     {actions_np.shape}")
    print(f"  Total time:  {time.time() - t0:.2f}s")
    return images_np, lang_ids_np, actions_np

if __name__ == "__main__":
    generate_expert_demonstrations(num_episodes=70)
