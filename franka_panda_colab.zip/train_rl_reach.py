"""
Train the goal-conditioned mobile reaching policy with PPO (Stable-Baselines3).

    .venv/bin/python3 train_rl_reach.py --steps 8000000 --envs 8

Outputs (in rl_models/):
    reach_policy.zip        trained PPO policy
    vecnormalize.pkl        observation normalisation statistics (needed at deploy)
    training_log.csv        timesteps, success rate, collision rate, mean return
    checkpoints/            periodic snapshots
"""

import argparse
import csv
import os
import time

import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, CallbackList
from stable_baselines3.common.vec_env import SubprocVecEnv, VecMonitor, VecNormalize

from rl_reach_env import MobileReachEnv

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "rl_models")


def make_env(rank: int, seed: int):
    def _init():
        return MobileReachEnv(seed=seed + 1000 * rank)
    return _init


class ProgressLogger(BaseCallback):
    """Prints and logs success / collision rates over the most recent episodes."""

    def __init__(self, path: str, window: int = 500):
        super().__init__()
        self.path = path
        self.window = window
        self.succ, self.coll, self.ret = [], [], []
        self.t0 = time.time()
        self.last_print = 0

    def _on_training_start(self):
        with open(self.path, "w", newline="") as f:
            csv.writer(f).writerow(["timesteps", "success_rate", "collision_rate", "mean_return", "episodes", "wall_s"])

    def _on_step(self) -> bool:
        for info, done in zip(self.locals["infos"], self.locals["dones"]):
            if done and "episode" in info:
                self.succ.append(float(info.get("is_success", False)))
                self.coll.append(float(info.get("collision", False)))
                self.ret.append(info["episode"]["r"])
        return True

    def _on_rollout_end(self):
        if not self.succ:
            return
        s = np.mean(self.succ[-self.window:])
        c = np.mean(self.coll[-self.window:])
        r = np.mean(self.ret[-self.window:])
        wall = time.time() - self.t0
        with open(self.path, "a", newline="") as f:
            csv.writer(f).writerow([self.num_timesteps, f"{s:.4f}", f"{c:.4f}", f"{r:.3f}", len(self.succ), f"{wall:.0f}"])
        if self.num_timesteps - self.last_print >= 200_000:
            self.last_print = self.num_timesteps
            fps = self.num_timesteps / max(wall, 1e-6)
            print(f"[{wall/60:5.1f} min] steps {self.num_timesteps/1e6:5.2f}M | success {s*100:5.1f}% "
                  f"| collision {c*100:5.1f}% | return {r:6.2f} | {fps:,.0f} steps/s", flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--steps", type=int, default=8_000_000)
    p.add_argument("--envs", type=int, default=8)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--resume", action="store_true", help="continue from rl_models/reach_policy.zip")
    args = p.parse_args()
    os.makedirs(os.path.join(OUT, "checkpoints"), exist_ok=True)

    venv = SubprocVecEnv([make_env(i, args.seed) for i in range(args.envs)])
    venv = VecMonitor(venv, info_keywords=("is_success", "collision"))

    if args.resume:
        venv = VecNormalize.load(os.path.join(OUT, "vecnormalize.pkl"), venv)
        model = PPO.load(os.path.join(OUT, "reach_policy.zip"), env=venv, device="cpu")
    else:
        venv = VecNormalize(venv, norm_obs=True, norm_reward=True, clip_obs=10.0, gamma=0.99)
        model = PPO(
            "MlpPolicy", venv,
            n_steps=1024, batch_size=4096, n_epochs=10,
            learning_rate=3e-4, gamma=0.99, gae_lambda=0.95, clip_range=0.2,
            ent_coef=0.0, vf_coef=0.5, max_grad_norm=0.5,
            policy_kwargs=dict(net_arch=dict(pi=[256, 256], vf=[256, 256]), log_std_init=-0.5),
            seed=args.seed, device="cpu", verbose=0,
        )

    callbacks = CallbackList([
        ProgressLogger(os.path.join(OUT, "training_log.csv")),
        CheckpointCallback(save_freq=max(1, 1_000_000 // args.envs), save_path=os.path.join(OUT, "checkpoints"),
                           name_prefix="reach", save_vecnormalize=True),
    ])
    print(f"Training PPO for {args.steps:,} steps on {args.envs} parallel envs...", flush=True)
    model.learn(total_timesteps=args.steps, callback=callbacks, reset_num_timesteps=not args.resume)
    model.save(os.path.join(OUT, "reach_policy.zip"))
    venv.save(os.path.join(OUT, "vecnormalize.pkl"))
    venv.close()
    print("Saved rl_models/reach_policy.zip and rl_models/vecnormalize.pkl")


if __name__ == "__main__":
    main()
