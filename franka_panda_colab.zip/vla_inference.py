"""
Vision-Language-Action (VLA) Inference Controller.
Runs PURE INFERENCE with a pre-trained VLA policy on Franka Panda in MuJoCo.

Zero coordinates are fed to the model:
  Inputs:  Live RGB Camera Image + Natural Language Instruction Prompt
  Outputs: Robot Motor Actions [dx, dy, dz, gripper_cmd]
"""
import os
import sys
import time
import argparse
import cv2
import numpy as np
import torch
import mujoco

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vla_model import VLAPolicy
from fsm_pick_and_place import solve_ik


def run_vla_inference(
    checkpoint_path: str = "checkpoints/vla_policy.pt",
    xml_path: str = "vla_panda.xml",
    output_video: str = "vla_inference.mp4",
    num_episodes: int = 3,
    render_video: bool = True,
    device: str = "cpu"
):
    print("=" * 70)
    print(" VISION-LANGUAGE-ACTION (VLA) INFERENCE ENGINE")
    print(" Pure Inference Mode | Zero Training | Multimodal Language-Conditioned Control")
    print("=" * 70)

    # 1. Load Pre-Trained VLA Model
    print(f"\n[1/3] Loading pre-trained VLA policy from: '{checkpoint_path}'...")
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint '{checkpoint_path}' not found! Please ensure weights exist.")

    model = VLAPolicy(embed_dim=128, num_heads=4, action_dim=4, proprio_dim=3)
    state_dict = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()
    print("  -> VLA Model loaded successfully in eval/inference mode!")

    # 2. Load MuJoCo Environment
    print(f"\n[2/3] Loading robot simulation from: '{xml_path}'...")
    mj_model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(mj_model)

    renderer_obs = mujoco.Renderer(mj_model, height=360, width=480)
    renderer_side = mujoco.Renderer(mj_model, height=360, width=480)

    site_id = mj_model.site("attachment").id
    block_id = mj_model.body("block").id
    tray_id = mj_model.body("tray").id

    target_mat = np.array([
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, -1.0]
    ])

    video_writer = None
    if render_video:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        # 3 panels side-by-side: Camera + HUD (480x360), Attention Heatmap (480x360), 3D Side View (480x360)
        video_writer = cv2.VideoWriter(output_video, fourcc, 20.0, (480 * 3, 360))
        print(f"  -> Recording video to: '{output_video}'")

    print(f"\n[3/3] Running {num_episodes} closed-loop VLA inference episodes...")
    dt = 0.05  # 20 Hz control loop
    success_count = 0

    for ep in range(num_episodes):
        print(f"\n--- Episode {ep + 1}/{num_episodes} ---")
        # Reset to home keyframe
        mujoco.mj_resetDataKeyframe(mj_model, data, 0)

        # Randomize block and tray locations on table
        # NOTE: These positions are ONLY set in the physics simulator.
        # The VLA policy NEVER receives these coordinates!
        block_x = np.random.uniform(0.42, 0.52)
        block_y = np.random.uniform(-0.14, 0.08)
        block_z = 0.225
        data.body("block").xpos[:] = [block_x, block_y, block_z]
        block_jnt_id = mj_model.body("block").jntadr[0]
        data.qpos[mj_model.jnt_qposadr[block_jnt_id]:mj_model.jnt_qposadr[block_jnt_id]+3] = [block_x, block_y, block_z]
        data.qpos[mj_model.jnt_qposadr[block_jnt_id]+3:mj_model.jnt_qposadr[block_jnt_id]+7] = [1, 0, 0, 0]

        tray_x = np.random.uniform(0.48, 0.58)
        tray_y = np.random.uniform(0.18, 0.28)
        tray_z = 0.21
        data.body("tray").xpos[:] = [tray_x, tray_y, tray_z]
        mj_model.body_pos[tray_id] = [tray_x, tray_y, tray_z]

        mujoco.mj_forward(mj_model, data)

        print(f"  True Sim Block Pos (Hidden from VLA): [{block_x:.3f}, {block_y:.3f}, {block_z:.3f}]")
        print(f"  True Sim Tray Pos  (Hidden from VLA): [{tray_x:.3f}, {tray_y:.3f}, {tray_z:.3f}]")

        current_ee_target = data.site_xpos[site_id].copy()
        current_prompt = "pick up the red box"
        grasped = False
        lifted = False
        episode_success = False

        # Max 200 control steps (10 seconds)
        for step in range(160):
            # 1. Capture visual observation from workspace camera
            renderer_obs.update_scene(data, camera="workspace_cam")
            obs_rgb = renderer_obs.render()

            # 2. Query VLA Model (Inference Only)
            current_ee_real = data.site_xpos[site_id].copy()
            action, attn_map = model.predict_action(
                obs_rgb,
                prompt=current_prompt,
                ee_pos=current_ee_real,
                device=device
            )
            dx, dy, dz, grip_cmd = action[0], action[1], action[2], action[3]

            # 3. Apply predicted end-effector action
            current_ee_target += np.array([dx, dy, dz])
            # Bound workspace target within safe envelope
            current_ee_target[0] = np.clip(current_ee_target[0], 0.30, 0.65)
            current_ee_target[1] = np.clip(current_ee_target[1], -0.25, 0.35)
            current_ee_target[2] = np.clip(current_ee_target[2], 0.22, 0.45)

            # Gripper control: grip_cmd < 0 => close (ctrl=0), grip_cmd > 0 => open (ctrl=255)
            gripper_ctrl = 0.0 if grip_cmd < 0 else 255.0

            # Solve IK for updated target position
            q_target, ik_ok = solve_ik(
                mj_model, data, site_id, current_ee_target, target_mat, data.qpos[:7], max_iter=30
            )
            if ik_ok:
                data.ctrl[:7] = q_target
            data.ctrl[7] = gripper_ctrl

            # Step MuJoCo physics
            for _ in range(int(dt / 0.002)):
                mujoco.mj_step(mj_model, data)

            # Monitor task status
            block_real_pos = data.xpos[block_id]
            ee_real_pos = data.site_xpos[site_id]
            dist_ee_block = np.linalg.norm(ee_real_pos - block_real_pos)

            # Check if block is grasped and lifted
            if block_real_pos[2] > 0.28 and not lifted:
                lifted = True
                current_prompt = "place in the green tray"
                print(f"    [Step {step:3d}] Red box secured and lifted! Switched language prompt -> '{current_prompt}'")

            # Check if block placed inside green tray
            tray_real_pos = data.xpos[tray_id]
            dist_block_tray = np.linalg.norm(block_real_pos[:2] - tray_real_pos[:2])
            if dist_block_tray < 0.07 and block_real_pos[2] < 0.25 and grip_cmd > 0:
                episode_success = True
                print(f"    [Step {step:3d}] SUCCESS! Red box safely placed inside the green tray!")
                break

            # 4. Render Video Visualization
            if render_video and video_writer is not None:
                # Panel 1: Live Observation with HUD
                panel1 = cv2.cvtColor(obs_rgb, cv2.COLOR_RGB2BGR)
                # Draw sleek HUD banner
                cv2.rectangle(panel1, (10, 10), (470, 70), (20, 20, 20), -1)
                cv2.rectangle(panel1, (10, 10), (470, 70), (0, 200, 255), 2)
                cv2.putText(panel1, "VLA INFERENCE (ZERO-COORDINATE)", (20, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1, cv2.LINE_AA)
                cv2.putText(panel1, f"PROMPT: \"{current_prompt}\"", (20, 55),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)

                grip_status = "CLOSED" if grip_cmd < 0 else "OPEN"
                grip_color = (0, 0, 255) if grip_cmd < 0 else (0, 255, 0)
                cv2.putText(panel1, f"GRIPPER: {grip_status}", (320, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, grip_color, 1, cv2.LINE_AA)

                # Panel 2: VLA Cross-Attention Heatmap
                attn_uint8 = np.uint8(255 * attn_map)
                heatmap = cv2.applyColorMap(attn_uint8, cv2.COLORMAP_JET)
                panel2 = cv2.addWeighted(panel1, 0.45, heatmap, 0.55, 0)
                cv2.putText(panel2, "VLA SPATIAL ATTENTION", (20, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(panel2, f"Target Focus: {current_prompt.split()[-1].upper()}", (20, 55),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1, cv2.LINE_AA)

                # Panel 3: 3D Side/Workspace Overview
                renderer_side.update_scene(data, camera="side_cam")
                side_rgb = renderer_side.render()
                panel3 = cv2.cvtColor(side_rgb, cv2.COLOR_RGB2BGR)
                cv2.putText(panel3, "FRANKA PANDA EXECUTION", (20, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.putText(panel3, f"Step: {step:03d} | Control: 20 Hz", (20, 55),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1, cv2.LINE_AA)

                # Combine panels horizontally
                combined_frame = np.hstack([panel1, panel2, panel3])
                video_writer.write(combined_frame)

        if episode_success:
            success_count += 1
            print(f"  -> Episode {ep + 1} Result: SUCCESS")
        else:
            print(f"  -> Episode {ep + 1} Result: FINISHED")

    if video_writer is not None:
        video_writer.release()
        print(f"\nVideo saved successfully to '{output_video}'")

    print("\n" + "=" * 70)
    print(f"VLA Inference Finished! Success Rate: {success_count}/{num_episodes} ({(success_count/num_episodes)*100:.1f}%)")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=3, help="Number of inference episodes")
    parser.add_argument("--video", type=str, default="vla_inference.mp4", help="Output video filename")
    parser.add_argument("--device", type=str, default="cpu", help="Device (cpu or mps)")
    args = parser.parse_args()

    run_vla_inference(output_video=args.video, num_episodes=args.episodes, device=args.device)
