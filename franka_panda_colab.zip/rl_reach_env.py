"""
Randomized mobile pick-and-place: RL environment and shared utilities.

Hybrid design
-------------
The RL policy is *goal-conditioned*: given any 3D target for the hand (the TCP
site "attachment" between the fingertips), it outputs

    [vx, vy, wz]  velocities for the holonomic base (base frame)
    [dx, dy, dz]  hand velocity relative to the base (base frame)

A damped-least-squares IK layer (ArmIK) turns the hand command into the 7 arm
joint targets and keeps the gripper pointing straight down. Grasping and
releasing are scripted by the task FSM in rl_pick_and_place.py, which feeds the
policy a sequence of targets: above box -> box -> lift -> above tray.

The policy has to learn to drive across the map to wherever the box/tray
spawned, face the table, avoid crashing the chassis or arm into tables, crates
and pillars, and finish with ~1.5 cm precision.

Training is kinematic (state is integrated directly, collisions are detected
with mj_collision) because that is ~100x faster than full contact dynamics.
The trained policy is then executed in full MuJoCo physics.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import gymnasium as gym
import mujoco
import numpy as np
from gymnasium import spaces

HERE = os.path.dirname(os.path.abspath(__file__))
XML_PATH = os.path.join(HERE, "mobile_panda.xml")

# ---------------------------------------------------------------- control
CTRL_DT = 0.1          # policy rate: 10 Hz
V_BASE = 0.5           # m/s    max base speed
W_BASE = 1.0           # rad/s  max base yaw rate
V_EE = 0.25            # m/s    max hand speed relative to the base
ACTION_SMOOTH = 0.5    # a_applied = s * a_prev + (1 - s) * a   (train and deploy)

# ---------------------------------------------------------------- scene
TABLE_TOP = 0.38
BLOCK_REST_Z = 0.40    # block centre when resting on a table
TRAY_Z = 0.39          # tray body origin height
TRAY_FLOOR_Z = 0.40    # top surface of the tray bottom
GRASP_DZ = -0.01       # TCP target relative to block centre when grasping
PREGRASP_DZ = 0.15
LIFT_DZ = 0.20
PREDROP_DZ = 0.15      # above tray floor

PICK_HALF = np.array([0.30, 0.40])   # native half-extents of table_pick
DROP_HALF = np.array([0.40, 0.30])   # native half-extents of table_drop
ARENA = 2.3            # table centres sampled in [-ARENA, ARENA]^2
BOUNDS = 3.2           # base must stay inside [-BOUNDS, BOUNDS]^2
TABLE_CLEARANCE = 0.95 # free corridor around each table (room for the base)
BASE_HALF = np.array([0.31, 0.275])  # chassis + bumpers + wheels footprint

TCP_LO = np.array([0.15, -0.60, 0.10])   # hand workspace box in base frame
TCP_HI = np.array([0.82, 0.60, 1.00])
SUCCESS_TOL = 0.015
MAX_STEPS = 300

# Fixed landmarks in mobile_panda.xml: (cx, cy, hx, hy)
STATIC_OBSTACLES = np.array([
    [2.0, 2.0, 0.25, 0.25],     # crate_yellow
    [-1.5, 1.5, 0.30, 0.30],    # crate_cyan
    [-1.5, -1.5, 0.20, 0.30],   # crate_orange
    [3.0, 3.0, 0.15, 0.15],     # pillars
    [-3.0, 3.0, 0.15, 0.15],
    [3.0, -3.0, 0.15, 0.15],
    [-3.0, -3.0, 0.15, 0.15],
])

OBS_DIM = 35


# ---------------------------------------------------------------- geometry helpers
def rot2(yaw: float) -> np.ndarray:
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s], [s, c]])


def rotz3(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def wrap(a: float) -> float:
    return (a + np.pi) % (2 * np.pi) - np.pi


def wrap_quarter(a: float) -> float:
    """Wrap to [-pi/4, pi/4): a cube looks the same every 90 degrees."""
    return (a + np.pi / 4) % (np.pi / 2) - np.pi / 4


def obb_overlap(c1, yaw1, h1, c2, yaw2, h2) -> bool:
    """Separating-axis test for two 2D oriented boxes."""
    R1, R2 = rot2(yaw1), rot2(yaw2)
    d = np.asarray(c2, float) - np.asarray(c1, float)
    for ax in (R1[:, 0], R1[:, 1], R2[:, 0], R2[:, 1]):
        r1 = h1[0] * abs(R1[:, 0] @ ax) + h1[1] * abs(R1[:, 1] @ ax)
        r2 = h2[0] * abs(R2[:, 0] @ ax) + h2[1] * abs(R2[:, 1] @ ax)
        if abs(d @ ax) > r1 + r2:
            return False
    return True


def closest_point_aabb(p: np.ndarray, rect: np.ndarray) -> np.ndarray:
    return np.clip(p, rect[:2] - rect[2:], rect[:2] + rect[2:])


def _aabb_overlap(a, b, margin: float) -> bool:
    return abs(a[0] - b[0]) < a[2] + b[2] + margin and abs(a[1] - b[1]) < a[3] + b[3] + margin


# ---------------------------------------------------------------- scene layout
@dataclass
class Layout:
    pick_rect: np.ndarray   # world AABB (cx, cy, hx, hy) of the pick table
    pick_rot: bool          # table rotated 90 degrees
    drop_rect: np.ndarray
    drop_rot: bool
    block_xy: np.ndarray
    block_yaw: float
    tray_xy: np.ndarray

    def obstacles(self) -> np.ndarray:
        return np.vstack([STATIC_OBSTACLES, self.pick_rect, self.drop_rect])


def sample_layout(rng: np.random.Generator, keep_clear=((0.0, 0.0),), clear_radius: float = 0.75) -> Layout:
    """Random table placement (avoiding landmarks), box and tray jittered on top."""
    placed = [o for o in STATIC_OBSTACLES]

    def place_table(half):
        for _ in range(1000):
            rot = bool(rng.random() < 0.5)
            h = half[::-1] if rot else half
            rect = np.r_[rng.uniform(-ARENA, ARENA, 2), h]
            if any(_aabb_overlap(rect, o, TABLE_CLEARANCE) for o in placed):
                continue
            if any(np.linalg.norm(closest_point_aabb(np.asarray(p), rect) - p) < clear_radius for p in keep_clear):
                continue
            placed.append(rect)
            return rect, rot
        raise RuntimeError("could not place table")

    pick_rect, pick_rot = place_table(PICK_HALF)
    drop_rect, drop_rot = place_table(DROP_HALF)
    lim_b = np.minimum(0.12, pick_rect[2:] - 0.10)
    lim_t = np.minimum(0.12, drop_rect[2:] - 0.10)
    return Layout(
        pick_rect=pick_rect, pick_rot=pick_rot, drop_rect=drop_rect, drop_rot=drop_rot,
        block_xy=pick_rect[:2] + rng.uniform(-lim_b, lim_b),
        block_yaw=float(rng.uniform(0, np.pi / 2)),
        tray_xy=drop_rect[:2] + rng.uniform(-lim_t, lim_t),
    )


class SceneIds:
    """Cached MuJoCo ids for the objects we move or inspect."""

    def __init__(self, m: mujoco.MjModel):
        g = lambda n: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, n)
        b = lambda n: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_BODY, n)
        self.table_pick = g("table_pick")
        self.table_drop = g("table_drop")
        self.tray = b("tray")
        self.block = b("block")
        self.base = b("mobile_base")
        self.site = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_SITE, "attachment")
        self.light_pick = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_LIGHT, "station1_light")
        self.light_drop = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_LIGHT, "station2_light")
        jnt = m.body_jntadr[self.block]
        self.block_qadr = m.jnt_qposadr[jnt]
        self.block_vadr = m.jnt_dofadr[jnt]
        self.robot_geom = m.body_rootid[m.geom_bodyid] == self.base
        self.ignore_geom = m.geom_bodyid == self.block


def apply_layout(m: mujoco.MjModel, ids: SceneIds, L: Layout) -> None:
    q90 = np.array([np.cos(np.pi / 4), 0, 0, np.sin(np.pi / 4)])
    q0 = np.array([1.0, 0, 0, 0])
    m.geom_pos[ids.table_pick] = [L.pick_rect[0], L.pick_rect[1], TABLE_TOP / 2]
    m.geom_quat[ids.table_pick] = q90 if L.pick_rot else q0
    m.geom_pos[ids.table_drop] = [L.drop_rect[0], L.drop_rect[1], TABLE_TOP / 2]
    m.geom_quat[ids.table_drop] = q90 if L.drop_rot else q0
    m.body_pos[ids.tray] = [L.tray_xy[0], L.tray_xy[1], TRAY_Z]
    if ids.light_pick >= 0:
        m.light_pos[ids.light_pick] = [L.pick_rect[0], L.pick_rect[1], 3.0]
    if ids.light_drop >= 0:
        m.light_pos[ids.light_drop] = [L.drop_rect[0], L.drop_rect[1], 3.0]


def place_block(d: mujoco.MjData, ids: SceneIds, L: Layout, z: float = 0.405) -> None:
    a = ids.block_qadr
    d.qpos[a:a + 3] = [L.block_xy[0], L.block_xy[1], z]
    d.qpos[a + 3:a + 7] = [np.cos(L.block_yaw / 2), 0, 0, np.sin(L.block_yaw / 2)]
    d.qvel[ids.block_vadr:ids.block_vadr + 6] = 0


def base_pose_free(xy, yaw, obstacles, margin: float = 0.02) -> bool:
    if np.any(np.abs(xy) > BOUNDS - 0.35):
        return False
    h = BASE_HALF + margin
    return not any(obb_overlap(xy, yaw, h, o[:2], 0.0, o[2:]) for o in obstacles)


def standoff_pose(rng, obj_xy, rect, obstacles):
    """A base pose next to `rect` from which the arm can reach `obj_xy`."""
    c, h = rect[:2], rect[2:]
    sides = []
    for axis in (0, 1):
        for sgn in (1.0, -1.0):
            edge_dist = h[axis] - sgn * (obj_xy[axis] - c[axis])
            if edge_dist <= 0.32:
                sides.append((axis, sgn))
    rng.shuffle(sides)
    for axis, sgn in sides:
        n = np.zeros(2)
        n[axis] = sgn
        base = np.array(obj_xy, float)
        base[axis] = c[axis] + sgn * h[axis] + sgn * (BASE_HALF[0] + rng.uniform(0.04, 0.14))
        base[1 - axis] += rng.uniform(-0.1, 0.1)
        yaw = float(np.arctan2(-n[1], -n[0]) + rng.uniform(-0.2, 0.2))
        if base_pose_free(base, yaw, obstacles):
            return base, yaw
    return None


# ---------------------------------------------------------------- IK
class ArmIK:
    """Damped-least-squares IK for the 7 arm joints, solved in the base frame."""

    def __init__(self, m: mujoco.MjModel):
        self.m = m
        self.d = mujoco.MjData(m)
        mujoco.mj_resetDataKeyframe(m, self.d, 0)
        self.d.qpos[:3] = 0.0
        mujoco.mj_kinematics(m, self.d)
        self.site = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_SITE, "attachment")
        self.R0 = self.d.site_xmat[self.site].reshape(3, 3).copy()   # gripper pointing down
        self.q_home = self.d.qpos[3:10].copy()
        self.lo = m.jnt_range[3:10, 0] + 0.02
        self.hi = m.jnt_range[3:10, 1] - 0.02
        self.jp = np.zeros((3, m.nv))
        self.jr = np.zeros((3, m.nv))
        self.I7 = np.eye(7)

    def fk(self, q: np.ndarray) -> np.ndarray:
        self.d.qpos[3:10] = q
        mujoco.mj_kinematics(self.m, self.d)
        return self.d.site_xpos[self.site].copy()

    def solve(self, q, target, psi: float = 0.0, iters: int = 3, null_gain: float = 0.05):
        """Move q toward placing the TCP at `target` (base frame), gripper down, rotated psi about z."""
        Rd = rotz3(psi) @ self.R0
        q = np.array(q, float)
        for _ in range(iters):
            self.d.qpos[3:10] = q
            mujoco.mj_kinematics(self.m, self.d)
            mujoco.mj_comPos(self.m, self.d)
            C = self.d.site_xmat[self.site].reshape(3, 3)
            ep = target - self.d.site_xpos[self.site]
            er = 0.5 * (np.cross(C[:, 0], Rd[:, 0]) + np.cross(C[:, 1], Rd[:, 1]) + np.cross(C[:, 2], Rd[:, 2]))
            mujoco.mj_jacSite(self.m, self.d, self.jp, self.jr, self.site)
            J = np.vstack([self.jp[:, 3:10], self.jr[:, 3:10]])
            Jp = J.T @ np.linalg.inv(J @ J.T + 1e-4 * np.eye(6))
            dq = Jp @ np.r_[ep, er] + (self.I7 - Jp @ J) @ (null_gain * (self.q_home - q))
            n = np.linalg.norm(dq)
            if n > 0.35:
                dq *= 0.35 / n
            q = np.clip(q + dq, self.lo, self.hi)
        return q, self.fk(q)


# ---------------------------------------------------------------- observation (shared train/deploy)
def make_obs(bxy, yaw, q, tcp_base, tcp_w, goal, target_rect, obstacles, a_prev, ik: ArmIK) -> np.ndarray:
    R = rot2(yaw)
    Rt = R.T
    g = goal - tcp_w
    g_b = np.r_[Rt @ g[:2], g[2]]
    goal_b = Rt @ (goal[:2] - bxy)
    tc_b = Rt @ (target_rect[:2] - bxy)
    tv = closest_point_aabb(bxy, target_rect) - bxy
    best_d, best_v = 1e9, np.zeros(2)
    for o in obstacles:
        v = closest_point_aabb(bxy, o) - bxy
        dd = np.linalg.norm(v)
        if dd < best_d:
            best_d, best_v = dd, v
    qn = 2.0 * (q - ik.lo) / (ik.hi - ik.lo) - 1.0
    obs = np.concatenate([
        g_b,                                   # 3  hand -> goal (base frame)
        goal_b,                                # 2  base -> goal xy (base frame)
        tcp_base - np.array([0.5, 0.0, 0.5]),  # 3  hand in base frame
        qn,                                    # 7  arm joints
        bxy / 3.0, [np.cos(yaw), np.sin(yaw)], # 4  base pose on the map
        tc_b,                                  # 2  target table centre
        Rt @ tv, [np.linalg.norm(tv)],         # 3  closest point of target table
        Rt @ best_v, [min(best_d, 3.0)],       # 3  closest other obstacle
        [goal[2]], [np.linalg.norm(g)],        # 2
        a_prev,                                # 6
    ])
    return obs.astype(np.float32)


# ---------------------------------------------------------------- environment
class MobileReachEnv(gym.Env):
    """Goal-conditioned reaching for the mobile manipulator on a randomized map."""

    metadata = {"render_modes": []}

    def __init__(self, seed: int | None = None, max_steps: int = MAX_STEPS):
        super().__init__()
        self.m = mujoco.MjModel.from_xml_path(XML_PATH)
        self.d = mujoco.MjData(self.m)
        self.ids = SceneIds(self.m)
        self.ik = ArmIK(self.m)
        self.rng = np.random.default_rng(seed)
        self.max_steps = max_steps
        self.action_space = spaces.Box(-1.0, 1.0, (6,), np.float32)
        self.observation_space = spaces.Box(-np.inf, np.inf, (OBS_DIM,), np.float32)
        mujoco.mj_resetDataKeyframe(self.m, self.d, 0)

    # ---- task sampling
    def _objects(self):
        L = self.layout
        return {
            "block": (L.block_xy, BLOCK_REST_Z, L.pick_rect),
            "tray": (L.tray_xy, TRAY_FLOOR_Z, L.drop_rect),
        }

    def _sample_task(self) -> bool:
        rng, L, ik = self.rng, self.layout, self.ik
        obstacles = L.obstacles()
        objs = self._objects()
        self.psi = float(rng.uniform(-np.pi / 4, np.pi / 4)) if rng.random() < 0.5 else 0.0
        u = rng.random()

        if u < 0.70:  # start somewhere on the map (or near the target table)
            name = "block" if rng.random() < 0.5 else "tray"
            xy, z0, rect = objs[name]
            self.goal = np.r_[xy, z0 + rng.choice([0.12, 0.15, 0.20, 0.25])]
            self.target_rect = rect
            for _ in range(100):
                if u < 0.45:
                    bxy = rng.uniform(-2.8, 2.8, 2)
                else:
                    bxy = rect[:2] + rng.uniform(-1.6, 1.6, 2)
                yaw = rng.uniform(-np.pi, np.pi)
                if base_pose_free(bxy, yaw, obstacles, margin=0.08):
                    break
            else:
                return False
            q = np.clip(ik.q_home + rng.normal(0, 0.15, 7), ik.lo, ik.hi)
        else:  # "chained" start: hand already above an object, as after a previous FSM phase
            src = "block" if rng.random() < 0.6 else "tray"
            xy, z0, rect = objs[src]
            pose = standoff_pose(rng, xy, rect, obstacles)
            if pose is None:
                return False
            bxy, yaw = pose
            k = rng.random()
            if src == "block" and k < 0.4:        # descend onto the box
                h0 = rng.uniform(0.08, 0.22)
                self.goal = np.r_[xy, z0 + GRASP_DZ]
                self.target_rect = rect
            elif src == "block" and k < 0.6:      # lift the box
                h0 = GRASP_DZ
                self.goal = np.r_[xy, z0 + rng.uniform(0.15, 0.25)]
                self.target_rect = rect
            else:                                 # carry to the other object
                h0 = rng.uniform(0.10, 0.25)
                other = "tray" if src == "block" else "block"
                oxy, oz0, orect = objs[other]
                self.goal = np.r_[oxy, oz0 + rng.choice([0.12, 0.15, 0.20])]
                self.target_rect = orect
            start_b = np.r_[rot2(yaw).T @ (xy - bxy), z0 + h0]
            if np.any(start_b < TCP_LO) or np.any(start_b > TCP_HI):
                return False
            q, tcp = ik.solve(ik.q_home, start_b, self.psi, iters=150)
            if np.linalg.norm(tcp - start_b) > 0.005:
                return False

        self.bxy, self.yaw, self.q = np.array(bxy, float), float(yaw), q
        self.tcp_base = ik.fk(q)
        self.tcp_cmd = self.tcp_base.copy()
        self.obstacles_obs = np.array([o for o in obstacles if not np.allclose(o, self.target_rect)])
        return True

    # ---- simulation helpers
    def _sync(self):
        d = self.d
        d.qpos[0:2] = self.bxy
        d.qpos[2] = self.yaw
        d.qpos[3:10] = self.q
        mujoco.mj_kinematics(self.m, d)
        mujoco.mj_collision(self.m, d)

    def _collides(self) -> bool:
        ids = self.ids
        for i in range(self.d.ncon):
            c = self.d.contact[i]
            g1, g2 = c.geom1, c.geom2
            if ids.ignore_geom[g1] or ids.ignore_geom[g2]:
                continue
            if ids.robot_geom[g1] or ids.robot_geom[g2]:
                return True
        return False

    def _obs(self):
        return make_obs(self.bxy, self.yaw, self.q, self.tcp_base, self.d.site_xpos[self.ids.site].copy(),
                        self.goal, self.target_rect, self.obstacles_obs, self.a_prev, self.ik)

    # ---- gym API
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        for _ in range(200):
            self.layout = sample_layout(self.rng, keep_clear=())
            if not self._sample_task():
                continue
            apply_layout(self.m, self.ids, self.layout)
            mujoco.mj_resetDataKeyframe(self.m, self.d, 0)
            place_block(self.d, self.ids, self.layout, z=BLOCK_REST_Z)
            self._sync()
            if not self._collides():
                break
        self.a_prev = np.zeros(6)
        self.steps = 0
        self.d_prev = float(np.linalg.norm(self.goal - self.d.site_xpos[self.ids.site]))
        return self._obs(), {}

    def step(self, action):
        a = np.clip(np.asarray(action, float), -1.0, 1.0)
        a_app = ACTION_SMOOTH * self.a_prev + (1 - ACTION_SMOOTH) * a
        self.a_prev = a_app

        self.yaw = wrap(self.yaw + a_app[2] * W_BASE * CTRL_DT)
        self.bxy = self.bxy + rot2(self.yaw) @ (a_app[:2] * V_BASE) * CTRL_DT

        self.tcp_cmd = np.clip(self.tcp_cmd + a_app[3:] * V_EE * CTRL_DT, TCP_LO, TCP_HI)
        self.q, self.tcp_base = self.ik.solve(self.q, self.tcp_cmd, self.psi)
        self.tcp_cmd = self.tcp_base + np.clip(self.tcp_cmd - self.tcp_base, -0.03, 0.03)

        self._sync()
        self.steps += 1
        tcp_w = self.d.site_xpos[self.ids.site]
        dist = float(np.linalg.norm(self.goal - tcp_w))

        reward = 10.0 * (self.d_prev - dist) - 0.01 - 0.005 * float(a @ a)
        self.d_prev = dist
        collided = self._collides()
        out = bool(np.any(np.abs(self.bxy) > BOUNDS))
        success = dist < SUCCESS_TOL
        terminated = collided or out or success
        if collided or out:
            reward -= 10.0
        elif success:
            reward += 10.0
        truncated = self.steps >= self.max_steps and not terminated
        info = {"is_success": bool(success and not collided), "collision": collided, "dist": dist}
        return self._obs(), float(reward), terminated, truncated, info
